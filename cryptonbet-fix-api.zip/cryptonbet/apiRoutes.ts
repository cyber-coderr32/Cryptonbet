import express from "express";
import { GoogleGenAI } from "@google/genai";

// Registers every /api/* route on the given Express app. Shared between
// server.ts (persistent Node host, e.g. Cloud Run / Render) and
// api/[...path].ts (Vercel serverless function), so both entry points stay
// in sync with a single source of truth for the backend routes.
export function registerApiRoutes(app: express.Express) {
  // API-Sports Configuration
  const APISPORTS_KEY = process.env.APISPORTS_KEY || 'be77ef991eaa21978a8112c3db8cfa43';

  const SPORT_CONFIG: Record<string, { host: string, endpoint: string, alt?: string }> = {
    'football': { host: 'football.api-sports.io', endpoint: 'fixtures', alt: 'api-football.com' },
    'basketball': { host: 'basketball.api-sports.io', endpoint: 'games', alt: 'api-basketball.com' },
    'f1': { host: 'formula-1.api-sports.io', endpoint: 'races', alt: 'api-formula-1.com' },
    'handball': { host: 'handball.api-sports.io', endpoint: 'games', alt: 'api-handball.com' },
    'hockey': { host: 'hockey.api-sports.io', endpoint: 'games', alt: 'api-hockey.com' },
    'mma': { host: 'mma.api-sports.io', endpoint: 'fights' },
    'nfl': { host: 'american-football.api-sports.io', endpoint: 'games', alt: 'api-american-football.com' },
    'rugby': { host: 'rugby.api-sports.io', endpoint: 'games', alt: 'api-rugby.com' },
    'volleyball': { host: 'volleyball.api-sports.io', endpoint: 'games', alt: 'api-volleyball.com' },
    'tennis': { host: 'api-tennis.com', endpoint: 'games' }
  };

  const handleProxyRequest = async (res: express.Response, sport: string, extraEndpoint?: string, extraQuery?: string) => {
    const config = SPORT_CONFIG[sport] || SPORT_CONFIG['football'];
    
    // Football is exclusively v3. Others are usually v1, sometimes v2.
    const versions = sport === 'football' ? ['v3'] : ['v1', 'v2', 'v3'];
    const possibleHosts: string[] = [];
    
    if (config.host) possibleHosts.push(config.host);
    if (config.alt) possibleHosts.push(config.alt);
    
    // Extra fallbacks for specific sports
    if (sport === 'basketball') possibleHosts.push('nba.api-sports.io');
    
    let lastError = null;
    const triedHosts = new Set<string>();

    for (const baseHost of possibleHosts) {
      // First try versions
      for (const v of versions) {
        // Build the full host (e.g. v1.tennis.api-sports.io or v1.api-tennis.com)
        const host = baseHost.startsWith('v') ? baseHost : `${v}.${baseHost}`;
        
        // Skip if we already tried this exact host
        if (triedHosts.has(host)) continue;
        triedHosts.add(host);

        const endpoint = extraEndpoint || config.endpoint;
        let query = extraQuery;
        if (query === undefined || query === null) {
          if (sport === 'f1' && endpoint === 'races') {
            // Free plans don't like next=5, use season or last
            query = 'season=2024';
          } else if (sport === 'football' && (endpoint === 'fixtures' || endpoint === 'games')) {
            query = 'live=all';
          } else if (sport === 'mma' && endpoint === 'fights') {
            // MMA needs season=2024 for free plan
            query = 'season=2024';
          } else if (endpoint === 'fixtures' || endpoint === 'games' || endpoint === 'fights') {
            // Default to today's date for most sports
            const today = new Date().toISOString().split('T')[0];
            query = `date=${today}`;
          } else {
            query = '';
          }
        }
        const apiUrl = `https://${host}/${endpoint}${query ? `?${query}` : ''}`;
        
        try {
          console.log(`Proxy attempt (${v}) for ${sport}: ${apiUrl}`);
          const controller = new AbortController();
          const timeoutId = setTimeout(() => controller.abort(), 10000); // 10s timeout

          const response = await fetch(apiUrl, {
            method: 'GET',
            headers: {
              'x-apisports-key': APISPORTS_KEY,
              'Accept': 'application/json',
              'User-Agent': 'CryptonBet/1.0'
            },
            signal: controller.signal
          });
          
          clearTimeout(timeoutId);
          
          if (response.ok) {
            const data = await response.json();
            
            // API-Sports logic error detection
            const hasErrors = data.errors && (Object.keys(data.errors).length > 0 || (typeof data.errors === 'string' && data.errors.length > 0));
            const hasLimitError = data.requests && typeof data.requests === 'string' && data.requests.toLowerCase().includes('limit');
            const hasRateLimitError = data.rateLimit && typeof data.rateLimit === 'string';
            
            if (hasErrors || hasLimitError || hasRateLimitError) {
              const errorPayload = data.errors || { requests: data.requests, rateLimit: data.rateLimit };
              const errorStr = JSON.stringify(errorPayload).toLowerCase();
              const isPlanRestricted = errorStr.includes('plan') || errorStr.includes('access');
              const isMinuteLimit = errorStr.includes('minute') || errorStr.includes('rate');
              const isGlobalLimit = errorStr.includes('limit') || errorStr.includes('requests') || (errorStr.includes('plan') && !errorStr.includes('date'));

              // Log only real logic errors, not known plan/quota limitations
              if (!isPlanRestricted && !isMinuteLimit && !isGlobalLimit) {
                console.warn(`API-Sports logic error for ${apiUrl}:`, JSON.stringify(errorPayload));
              } else {
                console.info(`API-Sports limit reached for ${apiUrl}: ${errorStr.substring(0, 100)}...`);
              }
              
              // If it's a quota or plan error, flag it for the frontend
              if (isPlanRestricted || isMinuteLimit || isGlobalLimit) {
                return res.json({ 
                  ...data, 
                  _isQuotaExceeded: isGlobalLimit, 
                  _isPlanRestricted: isPlanRestricted,
                  _isRateLimited: isMinuteLimit,
                  errors: errorPayload 
                });
              }

              // If it's a "does not exist" error or endpoint error, continue searching other hosts
              if (errorStr.includes('endpoint') || errorStr.includes('exist')) {
                continue;
              }
            }
            return res.json(data);
          }
          
          if (response.status === 404) continue;
          
          const errText = await response.text().catch(() => "Unknown Error");
          console.warn(`API Error ${response.status} for ${apiUrl}: ${errText}`);
          continue;
        } catch (error) {
          lastError = error;
          console.warn(`Fetch failure for ${apiUrl}: ${(error as Error).message}`);
          continue;
        }
      }

      // If all versions failed, try the base host directly if it wasn't tried
      // But only if it's not an api-sports.io host (they require v1/v2/v3 subdomains)
      if (!triedHosts.has(baseHost) && !baseHost.endsWith('api-sports.io')) {
        triedHosts.add(baseHost);
        const endpoint = extraEndpoint || config.endpoint;
        let query = extraQuery || '';
        const apiUrl = `https://${baseHost}/${endpoint}${query ? `?${query}` : ''}`;
        
        try {
           console.log(`Proxy attempt (direct) for ${sport}: ${apiUrl}`);
           const response = await fetch(apiUrl, {
             headers: { 'x-apisports-key': APISPORTS_KEY, 'Accept': 'application/json', 'User-Agent': 'CryptonBet/1.0' }
           });
           if (response.ok) {
             const data = await response.json();
             if (!(data.errors && Object.keys(data.errors).length > 0)) {
               return res.json(data);
             }
           }
        } catch (e) {
           console.warn(`Direct fetch failure for ${baseHost}: ${(e as Error).message}`);
        }
      }
    }
    
    res.status(200).json({ 
      errors: [lastError ? (lastError as Error).message : "All attempts failed"], 
      response: [],
      debug: { sport, lastError: String(lastError) }
    });
  };

  // Gemini Configuration & Endpoint
  const GEMINI_API_KEY = process.env.GEMINI_API_KEY || process.env.API_KEY;

  // Plisio API Backend Gateway Proxy
  const PLISIO_SECRET_KEY = process.env.PLISIO_SECRET_KEY || process.env.PLISIO_API_KEY;

  app.get("/api/plisio/status", (req, res) => {
    res.json({
      configured: !!PLISIO_SECRET_KEY,
      message: PLISIO_SECRET_KEY ? "Plisio Secret Key configurada no servidor backend." : "PLISIO_SECRET_KEY não definida no servidor (.env)."
    });
  });

  app.get("/api/plisio/currencies", async (req, res) => {
    try {
      const sourceCurrency = (req.query.sourceCurrency as string) || "USD";
      let url = `https://plisio.net/api/v1/currencies/${sourceCurrency}`;
      if (PLISIO_SECRET_KEY) {
        url += `?api_key=${encodeURIComponent(PLISIO_SECRET_KEY)}`;
      }
      const response = await fetch(url);
      const data = await response.json();
      return res.json(data);
    } catch (err: any) {
      return res.status(500).json({ status: "error", message: err.message || "Erro de servidor ao buscar moedas Plisio." });
    }
  });

  app.post("/api/plisio/invoice/new", async (req, res) => {
    try {
      const { amount, currency, orderNumber, orderName, email } = req.body;
      const curr = currency || 'USDT_TRX';

      if (!PLISIO_SECRET_KEY) {
        const txnId = 'PLISIO_DEP_' + Date.now();
        const simulatedWallet = curr.includes('TRX') 
          ? 'T' + Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15)
          : '0x' + Math.random().toString(16).substring(2, 42);

        return res.json({
          status: 'success',
          data: {
            txn_id: txnId,
            invoice_url: `https://plisio.net/invoice/${txnId}`,
            amount: Number(amount).toFixed(2),
            currency: curr,
            wallet_hash: simulatedWallet,
            expire_at_utc: Math.floor(Date.now() / 1000) + 3600,
          },
          isSimulated: true
        });
      }

      const queryParams = new URLSearchParams({
        api_key: PLISIO_SECRET_KEY,
        currency: curr,
        amount: String(amount),
        order_number: String(orderNumber),
        order_name: String(orderName),
        source_currency: 'USD',
      });
      if (email) queryParams.append('email', String(email));

      const response = await fetch(`https://plisio.net/api/v1/invoices/new?${queryParams.toString()}`);
      const data = await response.json();
      return res.json(data);
    } catch (err: any) {
      return res.status(500).json({ status: "error", message: err.message || "Erro ao criar fatura no Plisio." });
    }
  });

  app.post("/api/plisio/payout/insert", async (req, res) => {
    try {
      const { amount, currency, toWallet } = req.body;
      const curr = currency || 'USDT_TRX';

      if (!PLISIO_SECRET_KEY) {
        const payoutId = 'PLISIO_OUT_' + Date.now();
        return res.json({
          status: 'success',
          data: {
            id: payoutId,
            amount: Number(amount).toFixed(2),
            currency: curr,
            status: 'pending',
            tx_url: `https://tronscan.org/#/transaction/simulated_${payoutId}`
          },
          isSimulated: true
        });
      }

      const queryParams = new URLSearchParams({
        api_key: PLISIO_SECRET_KEY,
        currency: curr,
        amount: String(amount),
        to: String(toWallet),
        type: 'cash_out',
      });

      const response = await fetch(`https://plisio.net/api/v1/payouts/insert?${queryParams.toString()}`);
      const data = await response.json();
      return res.json(data);
    } catch (err: any) {
      return res.status(500).json({ status: "error", message: err.message || "Erro ao solicitar saque no Plisio." });
    }
  });

  app.get("/api/plisio/operations/:id", async (req, res) => {
    try {
      if (!PLISIO_SECRET_KEY) {
        return res.json({ status: 'success', data: { status: 'completed' }, isSimulated: true });
      }
      const response = await fetch(`https://plisio.net/api/v1/operations/${req.params.id}?api_key=${encodeURIComponent(PLISIO_SECRET_KEY)}`);
      const data = await response.json();
      return res.json(data);
    } catch (err: any) {
      return res.status(500).json({ status: "error", message: err.message });
    }
  });
  const ai = GEMINI_API_KEY ? new GoogleGenAI({
    apiKey: GEMINI_API_KEY,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      }
    }
  }) : null;

  const SERVER_LOCAL_PHRASES: Record<string, string[]> = {
    'BETTING': [
      "Façam as vossas apostas no estádio!",
      "O jogo vai começar!",
      "Preparem os vossos bilhetes!",
      "Boa sorte a todos os apostadores!"
    ],
    'FLYING': [
      "As odds estão a subir!",
      "O multiplicador não para de crescer!",
      "Estamos na zona de lucro!",
      "Grande jogada em curso!"
    ],
    'CRASHED': [
      "Final do jogo! Fiquem atentos ao próximo.",
      "Que partida emocionante! Prontos para a próxima?",
      "A sorte favorece os audazes!",
      "Tentem novamente, o prémio está perto!"
    ]
  };

  app.post("/api/gemini/commentary", async (req, res) => {
    const { status, multiplier } = req.body;
    const phrases = SERVER_LOCAL_PHRASES[status] || ["Boa sorte!"];
    const randomLocal = phrases[Math.floor(Math.random() * phrases.length)];

    if (!ai) {
      return res.json({ text: randomLocal });
    }

    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3.6-flash',
        contents: `Status: ${status} ${multiplier ? `at ${multiplier.toFixed(2)}x` : ''}. Give a 3-word commentary in Portuguese (PT-PT). No quotes.`,
        config: {
          maxOutputTokens: 20,
          temperature: 0.8,
        }
      });

      const text = response.text?.trim();
      return res.json({ text: text && text.length > 2 ? text : randomLocal });
    } catch (error) {
      console.warn("AI Status Warning: Failed to generate content via Gemini. Using local phrase.");
      return res.json({ text: randomLocal });
    }
  });

  // API Proxy Routes
  app.get("/api/sports/live/:sport", async (req, res) => {
    const sport = req.params.sport.toLowerCase();
    await handleProxyRequest(res, sport);
  });

  app.get("/api/sports/scheduled/:sport/:date", async (req, res) => {
    const { sport, date } = req.params;
    await handleProxyRequest(res, sport.toLowerCase(), undefined, `date=${date}`);
  });

  app.get("/api/sports/odds/:eventId", async (req, res) => {
    const { eventId } = req.params;
    await handleProxyRequest(res, 'football', 'odds', `fixture=${eventId}`);
  });

  app.get("/api/sports/countries/:sport", async (req, res) => {
    const sport = req.params.sport.toLowerCase();
    await handleProxyRequest(res, sport, 'countries', '');
  });

  app.get("/api/sports/leagues/:sport/:country", async (req, res) => {
    const { sport, country } = req.params;
    await handleProxyRequest(res, sport.toLowerCase(), 'leagues', `country=${country}`);
  });

  app.get("/api/sports/team-fixtures/:sport/:teamId", async (req, res) => {
    const { sport, teamId } = req.params;
    const { season: requestedSeason } = req.query;
    const s = sport.toLowerCase();
    const config = SPORT_CONFIG[s] || SPORT_CONFIG['football'];
    const endpoint = config.endpoint;
    
    let season: string | number | undefined = requestedSeason as string;
    if (!season) {
      const now = new Date();
      const year = now.getFullYear();
      // For football, Free plan often restricts the very latest/upcoming season.
      // If we are in 2026, 2025/2026 is often restricted. 2024 is usually the latest available.
      season = s === 'football' ? (year > 2025 ? 2024 : (now.getMonth() < 6 ? year - 1 : year)) : year;
    }
    
    const query = `team=${teamId}&season=${season}`;
    await handleProxyRequest(res, s, endpoint, query);
  });

  app.get("/api/sports/search-teams/:sport/:query", async (req, res) => {
    const { sport, query } = req.params;
    await handleProxyRequest(res, sport.toLowerCase(), 'teams', `search=${query}`);
  });
}
