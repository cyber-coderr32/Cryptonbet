import express from "express";
import { registerApiRoutes } from "../apiRoutes";

// Vercel file-system routing: a file named `[...path].ts` inside /api is a
// "catch-all" route, meaning ANY request to /api/anything/anything-else is
// sent to this single serverless function, with req.url containing the full
// original path (e.g. "/api/plisio/invoice/new"). This is the pattern Vercel
// itself recommends for mounting a full Express app as a serverless
// function, and it removes the need for a manual rewrite in vercel.json
// (which was silently failing to route sub-paths and causing Vercel's
// default 404 HTML page to be returned instead of JSON).
const app = express();
app.use(express.json());
registerApiRoutes(app);

export default app;
