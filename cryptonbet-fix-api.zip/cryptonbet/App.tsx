
import React, { useState, lazy, Suspense, useEffect } from 'react';
import { ViewState, UserAccount, GlobalSettings } from './types';
import { soundService } from './services/soundService';
import { authService } from './services/authService';
import { userService } from './services/userService';
import { doc, getDocFromServer } from 'firebase/firestore';
import { db } from './services/firebase';
import LoginView from './views/LoginView';
import RegisterView from './views/RegisterView';
import HomeView from './views/HomeView';
import GlobalHeader from './components/GlobalHeader';
import DesktopRestrictionOverlay from './components/DesktopRestrictionOverlay';
import { PWAInstallPrompt } from './components/PWAInstallPrompt';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Bomb, 
  PlaneTakeoff, 
  Gamepad2, 
  User, 
  Menu, 
  ShieldAlert, 
  Zap,
  Globe,
  Wallet,
  Gift,
  History,
  TrendingUp,
  Users,
  ArrowUpDown,
  BookOpen,
  LogOut
} from 'lucide-react';

// Lazy Loading
const P2PView = lazy(() => import('@/views/P2PView'));
const AviatorView = lazy(() => import('@/views/AviatorView'));
const RouletteView = lazy(() => import('@/views/RouletteView'));
const SlotsView = lazy(() => import('@/views/SlotsView'));
const DiceView = lazy(() => import('@/views/DiceView'));
const LotteryView = lazy(() => import('@/views/LotteryView'));
const MinesView = lazy(() => import('@/views/MinesView'));
const PlinkoView = lazy(() => import('@/views/PlinkoView'));
const BlackjackView = lazy(() => import('@/views/BlackjackView'));
const CoinFlipView = lazy(() => import('@/views/CoinFlipView'));
const ProfileView = lazy(() => import('@/views/ProfileView'));
const TraderView = lazy(() => import('@/views/TraderView'));
const SocialView = lazy(() => import('@/views/SocialView'));
const PdfMarketView = lazy(() => import('./views/PdfMarketView'));

const AdminView = lazy(() => import('@/views/AdminView'));
const PromotionsView = lazy(() => import('@/views/PromotionsView'));
const HistoryView = lazy(() => import('@/views/HistoryView'));
const ComingSoonView = lazy(() => import('@/views/ComingSoonView'));
const LimboView = lazy(() => import('@/views/LimboView'));
const CrashView = lazy(() => import('@/views/CrashView'));
const WheelView = lazy(() => import('@/views/WheelView'));
const ScratchView = lazy(() => import('@/views/ScratchView'));
const HiLoView = lazy(() => import('@/views/HiLoView'));
const TowerView = lazy(() => import('@/views/TowerView'));
const KenoView = lazy(() => import('@/views/KenoView'));
const BaccaratView = lazy(() => import('@/views/BaccaratView'));
const StairsView = lazy(() => import('@/views/StairsView'));
const PokerView = lazy(() => import('@/views/PokerView'));

const MaintenanceView: React.FC = () => (
  <div className="h-full w-full flex flex-col items-center justify-center bg-[#0b0e11] p-10 text-center">
    <motion.div 
      animate={{ y: [0, -20, 0], scale: [1, 1.1, 1] }} 
      transition={{ duration: 2, repeat: Infinity }}
      className="text-8xl mb-6"
    >⚽</motion.div>
    <h1 className="text-4xl font-black uppercase italic tracking-tighter mb-4 text-white">Crypton<span className="text-[#049444]">Bet</span> Manutenção</h1>
    <p className="text-slate-500 max-w-md uppercase text-xs font-bold tracking-widest leading-loose">
      Estamos a atualizar o nosso estádio para uma melhor experiência. Voltaremos em breve com as melhores odds de Angola.
    </p>
  </div>
);

const LoadingView: React.FC = () => (
  <div className="h-full w-full flex flex-col items-center justify-center bg-[#0b0e11]">
    <div className="relative mb-8 text-[#049444]">
      <motion.div 
        animate={{ scale: [1, 1.05, 1], rotate: [-1, 1, -1] }}
        transition={{ duration: 1, repeat: Infinity }}
        className="w-24 h-12 bg-[#049444] rounded-lg flex items-center justify-center shadow-2xl shadow-[#049444]/40"
      >
        <span className="text-white font-black italic text-xl">CRYPTON</span>
      </motion.div>
      <div className="text-right -mt-2">
        <span className="text-[#049444] font-black italic text-xl">BET</span>
      </div>
    </div>
    <div className="w-48 h-1 bg-white/5 rounded-full overflow-hidden mb-4">
      <motion.div 
        initial={{ x: '-100%' }}
        animate={{ x: '100%' }}
        transition={{ duration: 1.5, repeat: Infinity, ease: 'linear' }}
        className="w-full h-full bg-[#049444]"
      />
    </div>
    <span className="text-[10px] font-black text-slate-500 uppercase tracking-[0.3em]">Ligando Servidores...</span>
  </div>
);

const App: React.FC = () => {
  const [view, setView] = useState<ViewState>('LOGIN');
  const [socialInitialFilter, setSocialInitialFilter] = useState<'all' | 'social' | 'p2p' | 'pdf'>('all');
  const [autoOpenCreateAdToken, setAutoOpenCreateAdToken] = useState(false);
  const [globalAlert, setGlobalAlert] = useState<{ message: string; isOpen: boolean } | null>(null);

  useEffect(() => {
    window.alert = (message: string) => {
      soundService.playTick();
      setGlobalAlert({ message: String(message), isOpen: true });
    };
  }, []);

  const [realBalance, setRealBalance] = useState(0);
  const [demoBalance, setDemoBalance] = useState(5000.00);
  const [isDemo, setIsDemo] = useState(false);
  const [user, setUser] = useState<UserAccount | null>(null);
  const [isLoadingAuth, setIsLoadingAuth] = useState(true);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isDesktop, setIsDesktop] = useState(window.innerWidth >= 786);
  const [settings, setSettings] = useState<GlobalSettings>({
    siteName: 'CryptonBet Angola',
    maintenanceMode: false,
    globalRtp: 95,
    forcedAviatorMultiplier: null,
    globalNotification: null,
    totalVolume: 0,
    totalPaid: 0,
    paymentMethods: [
      { id: 'pix', name: 'PIX Instantâneo', type: 'MOBILE_MONEY', account: 'pix@cryptonbet.ao', icon: 'https://cdn.worldvectorlogo.com/logos/pix-bcb.svg', isActive: true, minDeposit: 1, maxWithdraw: 10000 },
      { id: 'multicaixa', name: 'Multicaixa Express', type: 'BANK', account: 'AO06 0000 0000 0000 0000 0', icon: 'https://www.emisu.co.ao/static/logo-emisu-multicaixa-express.png', isActive: true, minDeposit: 500, maxWithdraw: 50000 }
    ]
  });

  const activeBalance = isDemo ? demoBalance : realBalance;

  // Firebase connection test and Auth Listener
  useEffect(() => {
    const testConnection = async () => {
      try {
        await getDocFromServer(doc(db, 'test', 'connection'));
      } catch (error) {
        // Silently capture since we have robust localStorage fallbacks
        console.warn("Firestore offline or inaccessible. Running in hybrid offline/fallback mode.");
      }
    };
    testConnection();

    const unsubscribe = authService.onAuthChange(async (fbUser) => {
      setIsLoadingAuth(true);
      if (fbUser) {
        let profile = null;
        try {
          // Try to fetch the user profile from Firestore or local fallback
          profile = await userService.getUserProfile(fbUser.uid) as any;
          
          // If profile doesn't exist yet (e.g., registration / Google creation in progress), wait and retry
          if (!profile) {
            await new Promise(resolve => setTimeout(resolve, 1200));
            profile = await userService.getUserProfile(fbUser.uid) as any;
          }
        } catch (e) {
          console.error("Failed to retrieve user profile from database, using fallback:", e);
        }

        // If still null, create a default profile so the user isn't locked out of the app
        if (!profile) {
          const defaultProfile = {
            displayName: fbUser.displayName || 'Piloto',
            email: fbUser.email || '',
            role: 'USER',
            joinedAt: new Date().toISOString()
          };
          try {
            await userService.createUserProfile(fbUser.uid, defaultProfile);
            profile = await userService.getUserProfile(fbUser.uid) as any;
          } catch (err) {
            console.error("Error creating default profile in auth change listener:", err);
          }
        }
        
        if (profile) {
          const isAdminUser = profile.role === 'ADMIN' || fbUser.email === 'alfaajmc@gmail.com' || fbUser.email === 'admin@cryptonbet.ao';
          const userAccount: UserAccount = {
            id: fbUser.uid,
            name: profile.displayName || 'Jogador',
            email: fbUser.email || '',
            phone: profile.phone || '',
            balance: profile.balance !== undefined ? profile.balance : 100.00,
            role: isAdminUser ? 'ADMIN' : 'USER',
            isBanned: profile.isBanned || false,
            joinedAt: profile.joinedAt || new Date().toISOString(),
            bio: profile.bio || '',
            avatarColor: profile.avatarColor || 'bg-gradient-to-tr from-[#049444] to-[#FFCC00]',
            whatsapp: profile.whatsapp || ''
          };
          setUser(userAccount);
          setRealBalance(userAccount.balance);
          
          if (view === 'LOGIN' || view === 'REGISTER') {
             const s = JSON.parse(localStorage.getItem('skyhigh_settings') || '{}');
             setView(s.maintenanceMode && !isAdminUser ? 'MAINTENANCE' : 'HOME');
          }
        } else {
          // Robust local fallback so that users can always play
          const isAdminUser = fbUser.email === 'alfaajmc@gmail.com' || fbUser.email === 'admin@cryptonbet.ao';
          const fallbackAccount: UserAccount = {
            id: fbUser.uid,
            name: fbUser.displayName || 'Jogador Conectado',
            email: fbUser.email || '',
            phone: '',
            balance: 100.00,
            role: isAdminUser ? 'ADMIN' : 'USER',
            isBanned: false,
            joinedAt: new Date().toISOString(),
            bio: '',
            avatarColor: 'bg-gradient-to-tr from-[#049444] to-[#FFCC00]',
            whatsapp: ''
          };
          setUser(fallbackAccount);
          setRealBalance(100.00);
          if (view === 'LOGIN' || view === 'REGISTER') {
             setView('HOME');
          }
        }
      } else {
        // If not authenticated, clear user but don't force login view if we are on the register page
        setUser(null);
        if (view !== 'REGISTER') setView('LOGIN');
      }
      setIsLoadingAuth(false);
    });

    return () => unsubscribe();
  }, []);

  useEffect(() => {
    const syncSettings = () => {
      const saved = localStorage.getItem('skyhigh_settings');
      if (saved) {
        const parsed = JSON.parse(saved);
        setSettings(parsed);
        if (parsed.maintenanceMode && user?.role !== 'ADMIN' && !['LOGIN', 'REGISTER'].includes(view)) {
          setView('MAINTENANCE');
        }
      } else {
        localStorage.setItem('skyhigh_settings', JSON.stringify(settings));
      }
    };

    syncSettings();
    const handleResize = () => setIsDesktop(window.innerWidth >= 786);
    window.addEventListener('resize', handleResize);
    const interval = setInterval(syncSettings, 3000);
    return () => {
      clearInterval(interval);
      window.removeEventListener('resize', handleResize);
    };
  }, [user, view]);

  useEffect(() => {
    const handleKeyPress = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement;
      if (
        target.tagName === 'INPUT' || 
        target.tagName === 'TEXTAREA' || 
        target.isContentEditable || 
        target.tagName === 'SELECT'
      ) {
        return;
      }
      
      if (e.key === 'c' || e.key === 'C') {
        soundService.playUISelect();
        setView('HOME');
      }
    };

    window.addEventListener('keydown', handleKeyPress);
    return () => {
      window.removeEventListener('keydown', handleKeyPress);
    };
  }, []);

  useEffect(() => {
    if (user && !isDemo) {
      // Sync local balance changes to Firebase
      // We debounce or throttle this in a real app, but for now we'll do simple sync
      userService.updateBalance(user.id, realBalance);
    }
  }, [realBalance, user, isDemo]);

  const handleEmailLogin = async (email: string, pass: string) => {
    try {
      setIsLoadingAuth(true);
      const trimmedEmail = (email || '').trim().toLowerCase();
      if (!trimmedEmail) {
        alert("Por favor, introduza um e-mail válido.");
        return;
      }
      await authService.signInWithEmail(trimmedEmail, pass);
    } catch (e: any) {
      console.error("Login failed", e);
      if (e.message && (e.message.includes('auth/invalid-credential') || e.message.includes('auth/wrong-password') || e.message.includes('auth/user-not-found'))) {
        alert("E-mail ou palavra-passe incorretos.");
      } else if (e.message && e.message.includes('auth/invalid-email')) {
        alert("Formato de e-mail inválido. Por favor verifique.");
      } else {
        alert("Erro ao entrar: " + (e.message || "Tente novamente."));
      }
    } finally {
      setIsLoadingAuth(false);
    }
  };

  const handleEmailRegister = async (name: string, email: string, phone: string, pass: string) => {
    try {
      setIsLoadingAuth(true);
      const trimmedEmail = (email || '').trim().toLowerCase();
      if (!trimmedEmail) {
        alert("Por favor, introduza um e-mail válido.");
        return;
      }
      const fbUser = await authService.signUpWithEmail(trimmedEmail, pass);
      if (fbUser) {
        await userService.createUserProfile(fbUser.uid, {
          displayName: name,
          email: trimmedEmail,
          phone: phone,
          role: 'USER'
        });
      }
    } catch (e: any) {
      console.error("Registration failed", e);
      if (e.message && e.message.includes('auth/email-already-in-use')) {
        alert("Este e-mail já está em uso.");
      } else if (e.message && e.message.includes('auth/invalid-email')) {
        alert("Formato de e-mail inválido. Por favor verifique.");
      } else if (e.message && e.message.includes('auth/weak-password')) {
        alert("A palavra-passe deve ter pelo menos 6 caracteres.");
      } else {
        alert("Erro ao registar: " + (e.message || "Tente novamente."));
      }
    } finally {
      setIsLoadingAuth(false);
    }
  };

  const handleGoogleLogin = async () => {
    try {
      setIsLoadingAuth(true);
      const fbUser = await authService.signInWithGoogle();
      if (fbUser) {
        let profile = await userService.getUserProfile(fbUser.uid);
        if (!profile) {
          await userService.createUserProfile(fbUser.uid, {
            displayName: fbUser.displayName || 'Jogador Google',
            email: fbUser.email || '',
            role: 'USER'
          });
        }
      }
    } catch (e: any) {
      console.error("Google Login failed", e);
      let errMsg = "Erro ao entrar com a conta do Google.";
      const currentHost = typeof window !== 'undefined' ? window.location.hostname : '';
      if (e?.code === 'auth/popup-closed-by-user') {
        errMsg = "A autenticação com o Google foi cancelada ou a janela foi fechada.";
      } else if (e?.code === 'auth/popup-blocked') {
        errMsg = "O seu navegador bloqueou a janela pop-up do Google. Permita pop-ups e tente novamente.";
      } else if (e?.code === 'auth/unauthorized-domain') {
        errMsg = `Este domínio (${currentHost}) não está autorizado no Firebase Console. Vá a Firebase Console → Authentication → Settings → Authorized domains e adicione "${currentHost}".`;
      } else if (e?.code === 'auth/operation-not-allowed') {
        errMsg = "O login com Google não está ativado neste projeto Firebase. Ative-o em Authentication → Sign-in method → Google.";
      } else if (e?.code === 'auth/network-request-failed') {
        errMsg = "Falha de rede ao contactar o Firebase/Google. Verifique a ligação à internet.";
      } else if (e?.message) {
        errMsg = e.message;
      }
      alert(errMsg);
    } finally {
      setIsLoadingAuth(false);
    }
  };

  const handleGuestLogin = () => {
    soundService.playUISelect();
    const guestUser: UserAccount = {
      id: 'guest_user',
      name: 'Piloto Convidado',
      email: 'convidado@cryptonbet.ao',
      balance: 150000.00, // Rich demo balance
      role: 'USER',
      isBanned: false,
      joinedAt: new Date().toISOString(),
      bio: 'Operador profissional de Opções Binárias no CryptonBet Angola. 🚀🇦🇴',
      avatarColor: 'bg-gradient-to-tr from-[#049444] to-[#FFCC00]',
      whatsapp: '+244 923 000 000'
    };
    setUser(guestUser);
    setRealBalance(150000.00);
    setIsDemo(true);
    setView('HOME');
  };

  const handleUpdateProfile = async (updates: { name: string; phone?: string; bio?: string; avatarColor?: string; whatsapp?: string }) => {
    if (!user) return;
    try {
      const dbUpdates = {
        displayName: updates.name,
        phone: updates.phone || '',
        bio: updates.bio || '',
        avatarColor: updates.avatarColor || 'bg-gradient-to-tr from-[#049444] to-[#FFCC00]',
        whatsapp: updates.whatsapp || ''
      };
      await userService.updateUserProfile(user.id, dbUpdates);
      setUser(prev => prev ? {
        ...prev,
        name: updates.name,
        phone: updates.phone,
        bio: updates.bio,
        avatarColor: updates.avatarColor,
        whatsapp: updates.whatsapp
      } : null);
    } catch (e) {
      console.error("Error updating profile", e);
      alert("Erro ao atualizar o perfil.");
    }
  };

  const updateBalance = (amount: number) => {
    const currentSettings = JSON.parse(localStorage.getItem('skyhigh_settings') || '{}');
    if (amount < 0) {
      currentSettings.totalVolume += Math.abs(amount);
    } else {
      currentSettings.totalPaid += amount;
    }
    localStorage.setItem('skyhigh_settings', JSON.stringify(currentSettings));

    if (isDemo) {
      setDemoBalance(prev => Math.max(0, prev + amount));
    } else {
      setRealBalance(prev => Math.max(0, prev + amount));
    }
  };

  const handleSelectGame = (v: ViewState) => {
    if (v !== view) {
      soundService.playGameTransition();
    }
    if (v === 'P2P') {
      setView('SOCIAL');
      setSocialInitialFilter('p2p');
    } else if (v === 'PDF_MARKET') {
      setView('SOCIAL');
      setSocialInitialFilter('pdf');
    } else if (v === 'SOCIAL') {
      setView('SOCIAL');
      setSocialInitialFilter('all');
    } else {
      setView(v);
    }
  };

  const handleOpenCreateAd = () => {
    soundService.playUISelect();
    setView('SOCIAL');
    setSocialInitialFilter('all');
    setAutoOpenCreateAdToken(true);
    setTimeout(() => setAutoOpenCreateAdToken(false), 500);
  };

  const renderView = () => {
    if (settings.maintenanceMode && user?.role !== 'ADMIN' && !['LOGIN', 'REGISTER'].includes(view)) {
      return <MaintenanceView />;
    }

    switch (view) {
      case 'MAINTENANCE': return <MaintenanceView />;
      case 'LOGIN': return <LoginView onLogin={handleEmailLogin} onLoginGoogle={handleGoogleLogin} onGoToRegister={() => setView('REGISTER')} />;
      case 'REGISTER': return <RegisterView onRegister={handleEmailRegister} onLoginGoogle={handleGoogleLogin} onGoToLogin={() => setView('LOGIN')} />;
      case 'HOME': return <HomeView balance={activeBalance} isDemo={isDemo} onSelectGame={handleSelectGame} userName={user?.name || 'Piloto'} onGoToProfile={() => setView('PROFILE')} />;
      case 'PROFILE': return <ProfileView balance={activeBalance} user={user!} isDemo={isDemo} onToggleDemo={setIsDemo} onUpdateBalance={updateBalance} onBack={() => setView('HOME')} onLogout={() => authService.logout()} onUpdateUser={handleUpdateProfile} />;
      case 'AVIATOR': return <AviatorView balance={activeBalance} isDemo={isDemo} onUpdateBalance={updateBalance} onBack={() => setView('HOME')} />;
      case 'ROULETTE': return <RouletteView balance={activeBalance} isDemo={isDemo} onUpdateBalance={updateBalance} onBack={() => setView('HOME')} />;
      case 'SLOTS': return <SlotsView balance={activeBalance} isDemo={isDemo} onUpdateBalance={updateBalance} onBack={() => setView('HOME')} />;
      case 'DICE': return <DiceView balance={activeBalance} isDemo={isDemo} onUpdateBalance={updateBalance} onBack={() => setView('HOME')} />;
      case 'LOTTERY': return <LotteryView balance={activeBalance} isDemo={isDemo} onUpdateBalance={updateBalance} onBack={() => setView('HOME')} />;
      case 'MINES': return <MinesView balance={activeBalance} isDemo={isDemo} onUpdateBalance={updateBalance} onBack={() => setView('HOME')} />;
      case 'PLINKO': return <PlinkoView balance={activeBalance} isDemo={isDemo} onUpdateBalance={updateBalance} onBack={() => setView('HOME')} />;
      case 'BLACKJACK': return <BlackjackView balance={activeBalance} isDemo={isDemo} onUpdateBalance={updateBalance} onBack={() => setView('HOME')} />;
      case 'COINFLIP': return <CoinFlipView balance={activeBalance} isDemo={isDemo} onUpdateBalance={updateBalance} onBack={() => setView('HOME')} />;
      case 'TRADER': return <TraderView balance={activeBalance} isDemo={isDemo} onUpdateBalance={updateBalance} onBack={() => setView('HOME')} />;
      case 'P2P': return <SocialView balance={activeBalance} isDemo={isDemo} onBack={() => setView('HOME')} onSelectGame={handleSelectGame} onUpdateBalance={updateBalance} initialFilter="p2p" autoOpenCreateAd={autoOpenCreateAdToken} />;
      case 'SOCIAL': return <SocialView balance={activeBalance} isDemo={isDemo} onBack={() => setView('HOME')} onSelectGame={handleSelectGame} onUpdateBalance={updateBalance} initialFilter={socialInitialFilter} autoOpenCreateAd={autoOpenCreateAdToken} />;
      case 'PDF_MARKET': return <SocialView balance={activeBalance} isDemo={isDemo} onUpdateBalance={updateBalance} onBack={() => setView('HOME')} initialFilter="pdf" autoOpenCreateAd={autoOpenCreateAdToken} />;
      
      // Real Games
      case 'LIMBO': return <LimboView balance={activeBalance} isDemo={isDemo} onUpdateBalance={updateBalance} onBack={() => setView('HOME')} />;
      case 'CRASH': return <CrashView balance={activeBalance} isDemo={isDemo} onUpdateBalance={updateBalance} onBack={() => setView('HOME')} />;
      case 'WHEEL': return <WheelView balance={activeBalance} isDemo={isDemo} onUpdateBalance={updateBalance} onBack={() => setView('HOME')} />;
      case 'SCRATCH': return <ScratchView balance={activeBalance} isDemo={isDemo} onUpdateBalance={updateBalance} onBack={() => setView('HOME')} />;
      case 'HILO': return <HiLoView balance={activeBalance} isDemo={isDemo} onUpdateBalance={updateBalance} onBack={() => setView('HOME')} />;
      case 'TOWER': return <TowerView balance={activeBalance} isDemo={isDemo} onUpdateBalance={updateBalance} onBack={() => setView('HOME')} />;
      case 'KENO': return <KenoView balance={activeBalance} isDemo={isDemo} onUpdateBalance={updateBalance} onBack={() => setView('HOME')} />;
      case 'BACCARAT': return <BaccaratView balance={activeBalance} isDemo={isDemo} onUpdateBalance={updateBalance} onBack={() => setView('HOME')} />;
      case 'STAIRS': return <StairsView balance={activeBalance} isDemo={isDemo} onUpdateBalance={updateBalance} onBack={() => setView('HOME')} />;
      case 'POKER': return <PokerView balance={activeBalance} isDemo={isDemo} onUpdateBalance={updateBalance} onBack={() => setView('HOME')} />;

      case 'ADMIN': return <AdminView onBack={() => setView('HOME')} />;
      case 'PROMOTIONS': return <PromotionsView onBack={() => setView('HOME')} onAction={(g) => handleSelectGame(g)} />;
      case 'HISTORY': return <HistoryView onBack={() => setView('HOME')} />;
      default: return <LoginView onLogin={handleEmailLogin} onLoginGoogle={handleGoogleLogin} onGoToRegister={() => setView('REGISTER')} />;
    }
  };

  if (isLoadingAuth) {
    return <LoadingView />;
  }

  const isAuthView = ['LOGIN', 'REGISTER', 'MAINTENANCE'].includes(view);

  return (
    <div className="h-[100dvh] w-full bg-[#0b0e11] text-white flex overflow-hidden">
      {/* RESTRIÇÃO DE TELA APENAS PARA DISPOSITIVOS MÓVEIS E TABLETS EM TELAS GRANDES */}
      <DesktopRestrictionOverlay />

      {!isAuthView && (
        <>
          <AnimatePresence>
            {isMenuOpen && (
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="fixed inset-0 bg-black/80 backdrop-blur-sm z-[100] md:hidden" 
                onClick={() => setIsMenuOpen(false)} 
              />
            )}
          </AnimatePresence>
          
          <aside className={`fixed top-0 left-0 h-full bg-[#131d27] border-r border-white/5 z-[200] transition-all duration-500 ease-in-out ${isMenuOpen ? 'translate-x-0 w-64 pointer-events-auto' : (isDesktop ? 'translate-x-0 w-20 xl:w-64 pointer-events-auto' : '-translate-x-full pointer-events-none')} flex flex-col shadow-2xl`}>
            <div className="p-6 flex items-center gap-2">
               <div className="bg-[#049444] px-3 py-1 rounded shadow-lg transform -rotate-1 flex items-center">
                 <span 
                   onClick={() => {
                     soundService.playUISelect();
                     setView('HOME');
                   }}
                   className="text-white font-black italic text-lg tracking-tighter cursor-pointer hover:text-[#FFCC00] transition-colors pr-[1px]"
                   title="Voltar para Home"
                 >
                   C
                 </span>
                 <span className="text-white font-black italic text-lg tracking-tighter">
                   RYPTON
                 </span>
               </div>
               <div className={`transition-opacity duration-300 ${isMenuOpen ? 'opacity-100' : (isDesktop ? 'opacity-0 xl:opacity-100' : 'opacity-0')}`}>
                  <span className="font-black text-xl tracking-tighter uppercase italic block leading-none text-[#FFCC00]">BET</span>
               </div>
            </div>
            
            <nav className="flex-1 px-4 py-8 space-y-2 overflow-y-auto no-scrollbar">
              {user?.role === 'ADMIN' && (
                <motion.button 
                  initial={{ x: -20, opacity: 0 }}
                  animate={{ x: 0, opacity: 1 }}
                  onClick={() => { 
                    soundService.playUISelect();
                    setIsMenuOpen(false);
                    setView('ADMIN');
                  }} 
                  className="w-full flex items-center gap-4 p-3.5 rounded-2xl transition-all relative overflow-hidden group cursor-pointer z-[10] bg-gradient-to-r from-amber-500/20 to-amber-600/10 border border-amber-500/30 text-amber-300 hover:bg-amber-500/30 shadow-md mb-2"
                >
                  <span className="shrink-0 transition-transform group-hover:scale-110 text-amber-400">
                    <ShieldAlert className="w-5 h-5 md:w-6 md:h-6" />
                  </span>
                  <span className={`font-black uppercase text-[11px] tracking-widest transition-opacity duration-300 whitespace-nowrap ${isMenuOpen ? 'opacity-100' : (isDesktop ? 'opacity-0 xl:opacity-100' : 'opacity-0')}`}>
                    Painel Admin
                  </span>
                </motion.button>
              )}

              <motion.button 
                initial={{ x: -20, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                onClick={async () => { 
                  soundService.playUISelect();
                  setIsMenuOpen(false);
                  await authService.logout();
                }} 
                className="w-full flex items-center gap-4 p-3.5 rounded-2xl transition-all relative overflow-hidden group cursor-pointer z-[10] text-red-500 hover:bg-red-500/10 hover:text-red-400"
              >
                <span className="shrink-0 transition-transform group-hover:scale-110">
                  <LogOut className="w-5 h-5 md:w-6 md:h-6" />
                </span>
                <span className={`font-black uppercase text-[11px] tracking-widest transition-opacity duration-300 whitespace-nowrap ${isMenuOpen ? 'opacity-100' : (isDesktop ? 'opacity-0 xl:opacity-100' : 'opacity-0')}`}>
                  Sair da Conta
                </span>
              </motion.button>
            </nav>
            
            <div className="p-4 border-t border-white/5 bg-black/20">
               <div className={`flex items-center gap-3 transition-opacity ${isMenuOpen ? 'opacity-100' : (isDesktop ? 'opacity-0 xl:opacity-100' : 'opacity-0')}`}>
                  <div className="w-10 h-10 rounded-full bg-[#049444] border-2 border-white/20 flex items-center justify-center font-black uppercase text-xs shadow-lg">
                    {user?.name?.charAt(0) || 'P'}
                  </div>
                  <div className="flex flex-col overflow-hidden">
                     <span className="text-[10px] font-black uppercase truncate">{user?.name}</span>
                     <span className="text-[8px] text-slate-500 font-bold uppercase truncate tracking-tighter">Pilot ID: #{user?.id?.substring(0,6)}</span>
                  </div>
               </div>
            </div>
          </aside>
        </>
      )}
      
      <main className={`flex-1 flex flex-col transition-all duration-500 overflow-hidden ${!isAuthView ? (isDesktop ? 'pl-20 xl:pl-64' : 'pb-16') : ''}`}>
        {!isAuthView && (
          <GlobalHeader
            currentView={view}
            user={user}
            balance={activeBalance}
            isDemo={isDemo}
            onSelectGame={handleSelectGame}
            onGoToProfile={() => setView('PROFILE')}
            onToggleDemo={setIsDemo}
            onOpenCreateAd={handleOpenCreateAd}
          />
        )}

        <AnimatePresence>
          {settings.globalNotification && !isAuthView && (
            <motion.div 
              initial={{ y: -50 }}
              animate={{ y: 0 }}
              exit={{ y: -50 }}
              className="bg-[#049444] py-1.5 px-4 text-center text-[10px] font-black uppercase tracking-widest border-b border-white/10 z-[150] shadow-xl"
            >
              <span className="animate-pulse">Crypton Alert: {settings.globalNotification}</span>
            </motion.div>
          )}
        </AnimatePresence>
        
        <div className="flex-1 relative z-[10] overflow-hidden">
          <AnimatePresence mode="wait">
            <motion.div
              key={view}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.3, ease: 'easeInOut' }}
              className="flex-1 h-full"
            >
              <Suspense fallback={<LoadingView />}>
                {renderView()}
              </Suspense>
            </motion.div>
          </AnimatePresence>
        </div>
      </main>

      {!isAuthView && !isDesktop && (
        <nav className="fixed bottom-0 left-0 right-0 h-16 bg-[#131d27]/95 backdrop-blur-xl border-t border-white/5 z-[200] flex items-center justify-around px-4 shadow-[0_-10px_40px_rgba(0,0,0,0.8)]">
          {[
            { id: 'HOME', icon: <Globe className="w-5 h-5" />, label: 'Home' },
            { id: 'TRADER', icon: <TrendingUp className="w-5 h-5" />, label: 'Crypton Option' },
            { id: 'MINES', icon: <Bomb className="w-5 h-5" />, label: 'Minas' },
            { id: 'AVIATOR', icon: <PlaneTakeoff className="w-5 h-5" />, label: 'Aviator' },
            { id: 'PROMOTIONS', icon: <Gift className="w-5 h-5" />, label: 'Ofertas' },
          ].map((item) => (
            <button 
              key={item.id} 
              onClick={() => {
                soundService.playUISelect();
                handleSelectGame(item.id as ViewState);
              }} 
              className={`flex flex-col items-center gap-1 transition-all relative z-[10] cursor-pointer ${view === item.id ? 'text-[#FFCC00]' : 'text-slate-500 opacity-60'}`}
            >
              {view === item.id && (
                <motion.div 
                  layoutId="bottom-nav-bubble"
                  className="absolute -top-3 w-12 h-12 bg-[#049444]/10 rounded-full blur-xl"
                />
              )}
              <motion.div 
                animate={view === item.id ? { scale: 1.2, y: -4 } : { scale: 1, y: 0 }}
              >
                {item.icon}
              </motion.div>
              <span className="text-[7px] font-black uppercase tracking-tighter">{item.label}</span>
            </button>
          ))}
          <button 
            onClick={() => {
              soundService.playUISelect();
              setIsMenuOpen(true);
            }} 
            className="flex flex-col items-center gap-1 text-slate-500 opacity-60 cursor-pointer z-[10]"
          >
            <Menu className="w-5 h-5" />
            <span className="text-[7px] font-black uppercase tracking-tighter">Menu</span>
          </button>
        </nav>
      )}

      {/* GLOBAL BEAUTIFUL ALERT MODAL */}
      <AnimatePresence>
        {globalAlert?.isOpen && (
          <div className="fixed inset-0 z-[99999] flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-black/85 backdrop-blur-md"
              onClick={() => setGlobalAlert(null)}
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="relative w-full max-w-sm bg-gradient-to-b from-[#142031] to-[#0a111a] border border-white/10 p-6 rounded-[2rem] shadow-2xl text-center space-y-4 overflow-hidden"
            >
              {/* Decorative top pulse glow */}
              <div className="absolute top-0 left-1/2 -translate-x-1/2 w-24 h-[2px] bg-gradient-to-r from-transparent via-[#FFCC00]/50 to-transparent animate-pulse" />
              
              <div className="flex justify-center">
                <div className="w-12 h-12 rounded-full bg-[#FFCC00]/10 border border-[#FFCC00]/20 flex items-center justify-center text-[#FFCC00]">
                  <ShieldAlert className="w-6 h-6" />
                </div>
              </div>

              <div className="space-y-1">
                <h3 className="text-xs font-black uppercase tracking-widest text-[#FFCC00]">Aviso da Plataforma</h3>
                <p className="text-sm font-semibold text-slate-100 leading-relaxed font-sans">{globalAlert.message}</p>
              </div>

              <button
                onClick={() => {
                  soundService.playUISelect();
                  setGlobalAlert(null);
                }}
                className="w-full bg-[#FFCC00] text-[#05070a] hover:bg-[#ffe066] active:scale-95 py-3 rounded-xl font-black text-xs uppercase tracking-widest transition-all cursor-pointer shadow-[0_4px_12px_rgba(255,204,0,0.2)]"
              >
                Confirmar
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* PWA INSTALLATION BANNER */}
      <PWAInstallPrompt />
    </div>
  );
};

export default App;

