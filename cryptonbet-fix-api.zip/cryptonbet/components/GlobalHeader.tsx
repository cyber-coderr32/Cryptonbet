import React, { useState, useEffect, useRef } from 'react';
import { ViewState, UserAccount } from '../types';
import { soundService } from '../services/soundService';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Search, 
  X, 
  Gamepad2, 
  Package, 
  User, 
  Sparkles, 
  ChevronRight, 
  TrendingUp, 
  PlaneTakeoff, 
  Bomb, 
  Coins, 
  BookOpen, 
  ArrowUpDown, 
  Wallet, 
  Globe, 
  SlidersHorizontal,
  Dices,
  Club,
  Rocket,
  Eraser,
  Trophy,
  ArrowRight,
  ExternalLink,
  Flame,
  Clock,
  ShieldCheck,
  Zap,
  Megaphone
} from 'lucide-react';

export interface SearchResultItem {
  id: string;
  type: 'game' | 'product' | 'user';
  title: string;
  subtitle: string;
  icon?: string | React.ReactNode;
  category?: string;
  price?: string;
  badge?: string;
  viewTarget?: ViewState;
  socialFilterTarget?: 'all' | 'social' | 'p2p' | 'pdf';
  userData?: Partial<UserAccount>;
}

interface GlobalHeaderProps {
  currentView: ViewState;
  user: UserAccount | null;
  balance: number;
  isDemo: boolean;
  onSelectGame: (view: ViewState, category?: string) => void;
  onGoToProfile: () => void;
  onToggleDemo?: (isDemo: boolean) => void;
  onOpenDeposit?: () => void;
  onOpenCreateAd?: () => void;
}

// Full catalogue of platform games
const ALL_GAMES: Array<{
  id: ViewState;
  name: string;
  description: string;
  category: string;
  icon: string;
  popular?: boolean;
  hot?: boolean;
}> = [
  { id: 'AVIATOR', name: 'Aviator', description: 'Jogo de multiplicador nas alturas', category: 'Crash', icon: '✈️', popular: true, hot: true },
  { id: 'TRADER', name: 'Crypton Option', description: 'Opções binárias em tempo real BTC/USD', category: 'Trading', icon: '📈', popular: true, hot: true },
  { id: 'MINES', name: 'Mines / Minas', description: 'Encontre os diamantes e evite bombas', category: 'Estratégia', icon: '💣', popular: true },
  { id: 'CRASH', name: 'Crash Rocket', description: 'Multiplicador de foguete em tempo real', category: 'Crash', icon: '🚀', hot: true },
  { id: 'SLOTS', name: 'Vegas Slots', description: 'Caça-níqueis com jackpots cumulativos', category: 'Cassino', icon: '🎰', popular: true },
  { id: 'ROULETTE', name: 'Roleta Europeia', description: 'Roleta clássica de cassino', category: 'Mesa', icon: '🎡' },
  { id: 'PLINKO', name: 'Plinko Ball', description: 'Solte as esferas e ganhe multiplicadores', category: 'Arcade', icon: '⚪', popular: true },
  { id: 'BLACKJACK', name: 'Blackjack 21', description: 'Desafie o croupier no jogo de 21', category: 'Cartas', icon: '🃏' },
  { id: 'DICE', name: 'Jogo de Dados', description: 'Defina a probabilidade e lance os dados', category: 'Probabilidade', icon: '🎲' },
  { id: 'COINFLIP', name: 'Cara ou Coroa', description: 'Escolha um lado e dobre o seu saldo', category: 'Rápido', icon: '🪙' },
  { id: 'LIMBO', name: 'Limbo Multiplier', description: 'Aposte no alvo do multiplicador', category: 'Crash', icon: '⚡' },
  { id: 'WHEEL', name: 'Roda da Fortuna', description: 'Gire a roda e multiplique os ganhos', category: 'Arcade', icon: '🎡' },
  { id: 'SCRATCH', name: 'Raspadinha Premiada', description: 'Raspe e encontre símbolos iguais', category: 'Instantâneo', icon: '🏷️' },
  { id: 'HILO', name: 'HiLo Cartas', description: 'Adivinhe se a próxima carta é maior ou menor', category: 'Cartas', icon: '🎴' },
  { id: 'TOWER', name: 'Torre do Tesouro', description: 'Suba os andares da torre sem errar', category: 'Estratégia', icon: '🏰' },
  { id: 'KENO', name: 'Keno Bingo', description: 'Escolha os seus números da sorte', category: 'Lotaria', icon: '🎱' },
  { id: 'LOTTERY', name: 'Mega Sorteios', description: 'Bilhetes de lotaria diários com grandes prémios', category: 'Lotaria', icon: '🎟️' },
  { id: 'BACCARAT', name: 'Baccarat VIP', description: 'Jogo de cartas clássico de alta classe', category: 'Cartas', icon: '👑' },
  { id: 'STAIRS', name: 'Subida de Escadas', description: 'Evite os obstáculos e suba até ao topo', category: 'Estratégia', icon: '🪜' },
  { id: 'POKER', name: 'Poker Texas Hold\'em', description: 'Partidas de poker desafiantes', category: 'Cartas', icon: '♠️' },
  { id: 'P2P', name: 'Mercado P2P Cripto', description: 'Compra e venda de USDT e moedas crypto', category: 'Mercado', icon: '🔄', popular: true },
  { id: 'PDF_MARKET', name: 'Mercado de E-books', description: 'Compre e venda produtos digitais e estratégias', category: 'Digital', icon: '📚', popular: true },
  { id: 'SOCIAL', name: 'Comunidade & Feed', description: 'Acompanhe apostas, posts e anúncios de membros', category: 'Social', icon: '🌐' },
  { id: 'PROMOTIONS', name: 'Bónus & Promoções', description: 'Ver ofertas, rodadas grátis e bónus ativos', category: 'Ofertas', icon: '🎁' },
  { id: 'HISTORY', name: 'Histórico de Operações', description: 'Extrato detalhado de ganhos e depósitos', category: 'Conta', icon: '📜' },
];

// Catalogue of sample products & services
const SAMPLE_PRODUCTS = [
  { id: 'prod_1', title: 'E-Book: Guia Definitivo do Aviator & Crash', subtitle: 'Estratégia de gerenciamento de risco e sinais de padrões', price: '1.50 USDT', category: 'E-Book PDF', viewTarget: 'PDF_MARKET' as ViewState },
  { id: 'prod_2', title: 'E-Book: Manual de Opções Binárias & Análise Técnica', subtitle: 'Candlesticks, suporte, resistência e tempo de expiração', price: '3.00 USDT', category: 'E-Book PDF', viewTarget: 'PDF_MARKET' as ViewState },
  { id: 'prod_3', title: 'E-Book: Gestão de Banca & Psicologia de Apostas', subtitle: 'Como evitar o tilt e manter consistência a longo prazo', price: '2.00 USDT', category: 'E-Book PDF', viewTarget: 'PDF_MARKET' as ViewState },
  { id: 'prod_4', title: 'E-Book: Segredos das Minas & Plinko', subtitle: 'Tabelas de probabilidades e sequências de aposta', price: '1.20 USDT', category: 'E-Book PDF', viewTarget: 'PDF_MARKET' as ViewState },
  { id: 'prod_5', title: 'Oferta P2P: Venda 100 USDT', subtitle: 'Vendedor Verificado • Pagamento Imediato', price: '100.00 USDT', category: 'Oferta P2P', viewTarget: 'P2P' as ViewState },
  { id: 'prod_6', title: 'Oferta P2P: Compra de Saldo CryptonBet', subtitle: 'Transferência instantânea para a tua conta de jogo', price: 'Taxa Preferencial', category: 'Oferta P2P', viewTarget: 'P2P' as ViewState },
];

// Catalogue of sample prominent users/traders
const SAMPLE_USERS = [
  { id: 'user_mestre', name: 'Mestre Trader Angola', subtitle: 'Especialista em Opções Binárias • Winrate 84%', role: 'Pro Trader', bio: 'Operando Crypton Option diariamente no mercado de Angola.', avatarColor: 'bg-gradient-to-tr from-amber-500 to-amber-700' },
  { id: 'user_ana', name: 'Ana Silva Crypto', subtitle: 'Compradora VIP P2P • 100% Transações Concluídas', role: 'Vendedora P2P', bio: 'Troca rápida de USDT e criptomoedas.', avatarColor: 'bg-gradient-to-tr from-purple-600 to-indigo-600' },
  { id: 'user_carlos', name: 'Carlos Eduardo', subtitle: 'Top Vencedor Aviator & Crash', role: 'Piloto Master', bio: 'Caçador de multiplicadores 100x no Aviator.', avatarColor: 'bg-gradient-to-tr from-blue-600 to-cyan-500' },
  { id: 'user_mateus', name: 'Mateus Crypto', subtitle: 'Criador de Conteúdo & Autor de E-books', role: 'Criador Digital', bio: 'Autor do Guia do Aviator no Mercado PDF.', avatarColor: 'bg-gradient-to-tr from-[#049444] to-[#037235]' },
  { id: 'user_beatriz', name: 'Beatriz Luanda', subtitle: 'Jogadora de Cassino & Slots', role: 'VIP Member', bio: 'Apostando forte em Vegas Slots e Roulette.', avatarColor: 'bg-gradient-to-tr from-rose-500 to-pink-600' },
];

export const GlobalHeader: React.FC<GlobalHeaderProps> = ({
  currentView,
  user,
  balance,
  isDemo,
  onSelectGame,
  onGoToProfile,
  onToggleDemo,
  onOpenDeposit,
  onOpenCreateAd
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [isFocused, setIsFocused] = useState(false);
  const [activeTab, setActiveTab] = useState<'all' | 'games' | 'products' | 'users'>('all');
  const [selectedIndex, setSelectedIndex] = useState(0);
  const searchInputRef = useRef<HTMLInputElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  // Keyboard shortcut (Ctrl+K or /)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        searchInputRef.current?.focus();
        setIsFocused(true);
      } else if (e.key === '/' && document.activeElement !== searchInputRef.current) {
        const target = e.target as HTMLElement;
        if (target.tagName !== 'INPUT' && target.tagName !== 'TEXTAREA' && !target.isContentEditable) {
          e.preventDefault();
          searchInputRef.current?.focus();
          setIsFocused(true);
        }
      } else if (e.key === 'Escape') {
        setIsFocused(false);
        searchInputRef.current?.blur();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Close dropdown on click outside
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setIsFocused(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Filter games based on search query
  const query = searchQuery.trim().toLowerCase();

  const filteredGames = ALL_GAMES.filter(g => 
    !query || 
    g.name.toLowerCase().includes(query) || 
    g.description.toLowerCase().includes(query) || 
    g.category.toLowerCase().includes(query)
  );

  // Filter products based on query
  const filteredProducts = SAMPLE_PRODUCTS.filter(p =>
    !query ||
    p.title.toLowerCase().includes(query) ||
    p.subtitle.toLowerCase().includes(query) ||
    p.category.toLowerCase().includes(query)
  );

  // Filter users based on query
  const filteredUsers = SAMPLE_USERS.filter(u =>
    !query ||
    u.name.toLowerCase().includes(query) ||
    u.subtitle.toLowerCase().includes(query) ||
    u.role.toLowerCase().includes(query)
  );

  const totalResultsCount = 
    (activeTab === 'all' || activeTab === 'games' ? filteredGames.length : 0) +
    (activeTab === 'all' || activeTab === 'products' ? filteredProducts.length : 0) +
    (activeTab === 'all' || activeTab === 'users' ? filteredUsers.length : 0);

  const handleExecuteSearchItem = (item: SearchResultItem) => {
    soundService.playUISelect();
    setIsFocused(false);
    setSearchQuery('');

    if (item.type === 'game' && item.viewTarget) {
      onSelectGame(item.viewTarget);
    } else if (item.type === 'product') {
      if (item.viewTarget) {
        onSelectGame(item.viewTarget);
      } else {
        onSelectGame('PDF_MARKET');
      }
    } else if (item.type === 'user') {
      onSelectGame('SOCIAL');
    }
  };

  return (
    <header className="sticky top-0 z-[120] bg-[#111923]/95 backdrop-blur-xl border-b border-white/10 px-3 sm:px-6 py-2.5 transition-all shadow-xl">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-2 sm:gap-4">
        
        {/* Left branding title indicator on mobile / quick badge */}
        <div className="flex items-center gap-2 shrink-0">
          <div 
            onClick={() => onSelectGame('HOME')}
            className="flex items-center gap-1.5 cursor-pointer group"
            title="Página Inicial"
          >
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-[#049444] to-emerald-600 flex items-center justify-center text-white font-black text-sm shadow-md group-hover:scale-105 transition-all">
              ⚡
            </div>
            <div className="hidden sm:flex flex-col">
              <span className="text-xs font-black italic tracking-tighter text-white leading-none">
                CRYPTON<span className="text-[#049444]">BET</span>
              </span>
              <span className="text-[8px] text-[#FFCC00] font-bold uppercase tracking-wider">
                Angola
              </span>
            </div>
          </div>
        </div>

        {/* CENTER GLOBAL SEARCH BAR CONTAINER */}
        <div ref={containerRef} className="relative flex-1 max-w-3xl lg:max-w-4xl xl:max-w-5xl mx-1 sm:mx-3">
          <div className={`relative flex items-center bg-[#0b1017] border transition-all rounded-xl sm:rounded-2xl px-3.5 py-1.5 sm:py-2 ${
            isFocused 
              ? 'border-[#049444] ring-2 ring-[#049444]/30 shadow-[0_0_25px_rgba(4,148,68,0.25)] bg-[#0e1622]' 
              : 'border-white/10 hover:border-white/20'
          }`}>
            <Search className={`w-4 h-4 mr-2.5 shrink-0 transition-colors ${isFocused ? 'text-[#049444]' : 'text-slate-400'}`} />
            
            <input
              ref={searchInputRef}
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onFocus={() => setIsFocused(true)}
              placeholder="Pesquisar jogos (Aviator, Minas), P2P, E-books, Pilotos..."
              className="w-full bg-transparent text-xs sm:text-sm font-semibold text-white placeholder-slate-400 outline-none"
            />

            {searchQuery ? (
              <button
                onClick={() => {
                  setSearchQuery('');
                  searchInputRef.current?.focus();
                }}
                className="p-1 hover:bg-white/10 rounded-lg text-slate-400 hover:text-white transition-all cursor-pointer"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            ) : (
              <div className="hidden md:flex items-center gap-1 text-[9px] font-extrabold text-slate-500 bg-white/5 border border-white/10 px-2 py-0.5 rounded-lg select-none">
                <span>Ctrl</span>
                <span>+</span>
                <span>K</span>
              </div>
            )}
          </div>

          {/* SEARCH RESULTS OVERLAY DROPDOWN */}
          <AnimatePresence>
            {isFocused && (
              <>
                <div 
                  className="fixed inset-0 bg-black/60 backdrop-blur-xs z-[190]" 
                  onClick={() => setIsFocused(false)} 
                />
                <motion.div
                  initial={{ opacity: 0, y: 12, scale: 0.98 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: 8, scale: 0.98 }}
                  transition={{ duration: 0.15 }}
                  className="fixed top-14 sm:top-16 left-1/2 -translate-x-1/2 w-[calc(100vw-24px)] sm:w-[92vw] md:w-[780px] lg:w-[960px] max-w-[calc(100vw-24px)] sm:max-w-[92vw] lg:max-w-5xl bg-[#121b28]/98 backdrop-blur-2xl border border-white/20 rounded-2xl shadow-[0_25px_70px_rgba(0,0,0,0.9)] overflow-hidden z-[200] max-h-[82vh] flex flex-col text-left"
                >
                {/* CATEGORY FILTER TABS */}
                <div className="p-3 bg-[#0c121b] border-b border-white/10 flex items-center justify-between gap-2 overflow-x-auto no-scrollbar text-[11px] font-black uppercase">
                  <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar">
                    <button
                      onClick={() => setActiveTab('all')}
                      className={`px-3.5 py-1.5 rounded-xl transition-all whitespace-nowrap cursor-pointer flex items-center gap-1.5 ${
                        activeTab === 'all' 
                          ? 'bg-[#049444] text-white shadow-md' 
                          : 'bg-white/5 text-slate-400 hover:text-white hover:bg-white/10'
                      }`}
                    >
                      <Sparkles className="w-3.5 h-3.5" />
                      <span>Todos ({totalResultsCount})</span>
                    </button>

                    <button
                      onClick={() => setActiveTab('games')}
                      className={`px-3.5 py-1.5 rounded-xl transition-all whitespace-nowrap cursor-pointer flex items-center gap-1.5 ${
                        activeTab === 'games' 
                          ? 'bg-[#049444] text-white shadow-md' 
                          : 'bg-white/5 text-slate-400 hover:text-white hover:bg-white/10'
                      }`}
                    >
                      <Gamepad2 className="w-3.5 h-3.5 text-amber-400" />
                      <span>Jogos ({filteredGames.length})</span>
                    </button>

                    <button
                      onClick={() => setActiveTab('products')}
                      className={`px-3.5 py-1.5 rounded-xl transition-all whitespace-nowrap cursor-pointer flex items-center gap-1.5 ${
                        activeTab === 'products' 
                          ? 'bg-[#049444] text-white shadow-md' 
                          : 'bg-white/5 text-slate-400 hover:text-white hover:bg-white/10'
                      }`}
                    >
                      <Package className="w-3.5 h-3.5 text-cyan-400" />
                      <span>Produtos & P2P ({filteredProducts.length})</span>
                    </button>

                    <button
                      onClick={() => setActiveTab('users')}
                      className={`px-3.5 py-1.5 rounded-xl transition-all whitespace-nowrap cursor-pointer flex items-center gap-1.5 ${
                        activeTab === 'users' 
                          ? 'bg-[#049444] text-white shadow-md' 
                          : 'bg-white/5 text-slate-400 hover:text-white hover:bg-white/10'
                      }`}
                    >
                      <User className="w-3.5 h-3.5 text-purple-400" />
                      <span>Usuários ({filteredUsers.length})</span>
                    </button>
                  </div>

                  <button
                    onClick={() => setIsFocused(false)}
                    className="p-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-slate-400 hover:text-white transition-all cursor-pointer shrink-0"
                    title="Fechar Pesquisa"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>

                {/* RESULTS SCROLL AREA */}
                <div className="p-3 sm:p-4 space-y-5 overflow-y-auto no-scrollbar max-h-[62vh]">
                  
                  {totalResultsCount === 0 ? (
                    <div className="py-12 text-center space-y-3">
                      <div className="w-14 h-14 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-slate-400 mx-auto text-2xl">
                        🔍
                      </div>
                      <p className="text-sm font-bold text-slate-300 uppercase tracking-wider">
                        Nenhum resultado encontrado para "{searchQuery}"
                      </p>
                      <p className="text-xs text-slate-400 font-medium max-w-md mx-auto">
                        Tente pesquisar por termos como "Aviator", "Mines", "Trader", "E-Book", "P2P" ou "USDT".
                      </p>
                    </div>
                  ) : (
                    <>
                      {/* SECTION 1: GAMES */}
                      {(activeTab === 'all' || activeTab === 'games') && filteredGames.length > 0 && (
                        <div className="space-y-2">
                          <div className="px-1 py-1 text-xs font-black uppercase tracking-widest text-amber-400 flex items-center gap-2">
                            <Gamepad2 className="w-4 h-4" />
                            <span>Jogos da Plataforma ({filteredGames.length})</span>
                          </div>

                          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
                            {filteredGames.slice(0, activeTab === 'games' ? 24 : 6).map((game) => (
                              <button
                                key={game.id}
                                onClick={() => handleExecuteSearchItem({
                                  id: game.id,
                                  type: 'game',
                                  title: game.name,
                                  subtitle: game.description,
                                  viewTarget: game.id
                                })}
                                className="w-full p-3 bg-white/5 hover:bg-white/10 border border-white/5 hover:border-[#049444]/60 rounded-xl transition-all cursor-pointer flex items-center justify-between gap-2.5 text-left group"
                              >
                                <div className="flex items-center gap-3 overflow-hidden">
                                  <div className="w-10 h-10 rounded-xl bg-slate-900 border border-white/10 flex items-center justify-center text-xl shrink-0 shadow-sm group-hover:scale-110 transition-transform">
                                    {game.icon}
                                  </div>
                                  <div className="overflow-hidden">
                                    <div className="flex items-center gap-1.5">
                                      <span className="font-extrabold text-xs text-white group-hover:text-[#FFCC00] transition-colors truncate">
                                        {game.name}
                                      </span>
                                      {game.hot && (
                                        <span className="bg-red-500/20 text-red-400 border border-red-500/30 text-[8px] font-black px-1.5 py-0.2 rounded uppercase shrink-0">
                                          HOT
                                        </span>
                                      )}
                                    </div>
                                    <p className="text-[10px] text-slate-400 truncate">
                                      {game.description}
                                    </p>
                                  </div>
                                </div>

                                <div className="shrink-0 flex items-center gap-1 text-[10px] text-[#049444] font-black group-hover:translate-x-0.5 transition-transform">
                                  <span>Jogar</span>
                                  <ChevronRight className="w-3.5 h-3.5" />
                                </div>
                              </button>
                            ))}
                          </div>
                        </div>
                      )}

                      {/* SECTION 2: PRODUCTS & P2P */}
                      {(activeTab === 'all' || activeTab === 'products') && filteredProducts.length > 0 && (
                        <div className="space-y-2 pt-3 border-t border-white/10">
                          <div className="px-1 py-1 text-xs font-black uppercase tracking-widest text-cyan-400 flex items-center gap-2">
                            <Package className="w-4 h-4" />
                            <span>E-Books & Ofertas P2P ({filteredProducts.length})</span>
                          </div>

                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                            {filteredProducts.slice(0, activeTab === 'products' ? 12 : 4).map((prod) => (
                              <button
                                key={prod.id}
                                onClick={() => handleExecuteSearchItem({
                                  id: prod.id,
                                  type: 'product',
                                  title: prod.title,
                                  subtitle: prod.subtitle,
                                  price: prod.price,
                                  viewTarget: prod.viewTarget
                                })}
                                className="w-full p-3 bg-white/5 hover:bg-white/10 border border-white/5 hover:border-cyan-500/60 rounded-xl transition-all cursor-pointer flex items-center justify-between gap-3 text-left group"
                              >
                                <div className="flex items-center gap-3 overflow-hidden">
                                  <div className="w-9 h-9 rounded-xl bg-cyan-950/60 border border-cyan-500/30 flex items-center justify-center text-cyan-400 shrink-0 text-sm font-black">
                                    {prod.category.includes('P2P') ? '🔄' : '📚'}
                                  </div>
                                  <div className="overflow-hidden">
                                    <div className="flex items-center gap-1.5">
                                      <span className="font-extrabold text-xs text-white group-hover:text-cyan-300 transition-colors truncate">
                                        {prod.title}
                                      </span>
                                      <span className="text-[8px] bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 font-black px-1.5 py-0.2 rounded uppercase shrink-0">
                                        {prod.category}
                                      </span>
                                    </div>
                                    <p className="text-[10px] text-slate-400 truncate">
                                      {prod.subtitle}
                                    </p>
                                  </div>
                                </div>

                                <div className="shrink-0 text-right">
                                  <span className="font-mono text-xs font-black text-[#FFCC00]">
                                    {prod.price}
                                  </span>
                                </div>
                              </button>
                            ))}
                          </div>
                        </div>
                      )}

                      {/* SECTION 3: USERS & TRADERS */}
                      {(activeTab === 'all' || activeTab === 'users') && filteredUsers.length > 0 && (
                        <div className="space-y-2 pt-3 border-t border-white/10">
                          <div className="px-1 py-1 text-xs font-black uppercase tracking-widest text-purple-400 flex items-center gap-2">
                            <User className="w-4 h-4" />
                            <span>Pilotos & Comunidade ({filteredUsers.length})</span>
                          </div>

                          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
                            {filteredUsers.slice(0, activeTab === 'users' ? 12 : 6).map((usr) => (
                              <button
                                key={usr.id}
                                onClick={() => handleExecuteSearchItem({
                                  id: usr.id,
                                  type: 'user',
                                  title: usr.name,
                                  subtitle: usr.subtitle,
                                  viewTarget: 'SOCIAL'
                                })}
                                className="w-full p-3 bg-white/5 hover:bg-white/10 border border-white/5 hover:border-purple-500/60 rounded-xl transition-all cursor-pointer flex items-center justify-between gap-2.5 text-left group"
                              >
                                <div className="flex items-center gap-3 overflow-hidden">
                                  <div className={`w-9 h-9 rounded-full ${usr.avatarColor} border border-white/20 flex items-center justify-center text-white text-xs font-black shrink-0 shadow-sm`}>
                                    {usr.name.charAt(0)}
                                  </div>
                                  <div className="overflow-hidden">
                                    <div className="flex items-center gap-1.5">
                                      <span className="font-extrabold text-xs text-white group-hover:text-purple-300 transition-colors truncate">
                                        {usr.name}
                                      </span>
                                      <span className="text-[8px] bg-purple-500/20 text-purple-300 border border-purple-500/30 font-black px-1.5 py-0.2 rounded uppercase shrink-0">
                                        {usr.role}
                                      </span>
                                    </div>
                                    <p className="text-[10px] text-slate-400 truncate">
                                      {usr.subtitle}
                                    </p>
                                  </div>
                                </div>

                                <div className="shrink-0 flex items-center gap-1 text-[10px] text-purple-400 font-black group-hover:translate-x-0.5 transition-transform">
                                  <span>Ver</span>
                                  <ChevronRight className="w-3.5 h-3.5" />
                                </div>
                              </button>
                            ))}
                          </div>
                        </div>
                      )}
                    </>
                  )}
                </div>

                {/* FOOTER HINT */}
                <div className="p-3 bg-[#090e15] border-t border-white/10 flex items-center justify-between text-[10px] text-slate-400 font-semibold">
                  <div className="flex items-center gap-2">
                    <span className="text-[#049444] font-black">⚡ CryptonBet Busca</span>
                    <span>• NAVEGAÇÃO RÁPIDA</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="hidden sm:inline text-slate-500">Pressione ESC para fechar</span>
                    <button
                      onClick={() => setIsFocused(false)}
                      className="text-xs text-slate-300 hover:text-white font-bold underline cursor-pointer"
                    >
                      Fechar
                    </button>
                  </div>
                </div>
              </motion.div>
            </>
          )}
          </AnimatePresence>
        </div>

        {/* RIGHT SIDE: CREATE AD & ADMIN BUTTONS */}
        <div className="flex items-center gap-2 shrink-0">
          
          {user?.role === 'ADMIN' && (
            <button
              onClick={() => {
                soundService.playUISelect();
                onSelectGame('ADMIN');
              }}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl sm:rounded-2xl bg-gradient-to-r from-amber-500 to-yellow-600 hover:from-amber-400 hover:to-yellow-500 text-black font-black text-xs uppercase tracking-wider shadow-lg hover:scale-105 transition-all cursor-pointer border border-amber-300/50 shrink-0 active:scale-95"
              title="Abrir Painel de Administração"
            >
              <ShieldCheck className="w-3.5 h-3.5 text-black" />
              <span className="hidden sm:inline">Painel Admin</span>
              <span className="sm:hidden">Admin</span>
            </button>
          )}

          {/* CREATE AD BUTTON */}
          <button
            onClick={() => {
              soundService.playUISelect();
              if (onOpenCreateAd) {
                onOpenCreateAd();
              } else {
                onSelectGame('SOCIAL');
              }
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl sm:rounded-2xl bg-gradient-to-r from-blue-600 via-blue-500 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-black text-xs uppercase tracking-wider shadow-md hover:scale-105 transition-all cursor-pointer border border-blue-400/30 shrink-0 active:scale-95"
            title="Criar Campanha de Anúncio Patrocinado"
          >
            <Megaphone className="w-3.5 h-3.5 text-amber-300 animate-pulse" />
            <span>Anunciar</span>
          </button>
        </div>

      </div>
    </header>
  );
};

export default GlobalHeader;
