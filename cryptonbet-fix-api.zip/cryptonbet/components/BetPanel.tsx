
import React from 'react';
import { GameStatus, Bet } from '../types';

interface BetPanelProps {
  status: GameStatus;
  bet: Bet;
  setBet: React.Dispatch<React.SetStateAction<Bet>>;
  hasActiveBet: boolean;
  onPlaceBet: () => void;
  onCashOut: () => void;
  multiplier: number;
  balance: number;
}

const BetPanel: React.FC<BetPanelProps> = ({
  status,
  bet,
  setBet,
  hasActiveBet,
  onPlaceBet,
  onCashOut,
  multiplier,
  balance
}) => {
  const adjustBet = (amount: number) => {
    if (status !== GameStatus.BETTING && status !== GameStatus.IDLE) return;
    setBet(prev => ({ ...prev, amount: Math.max(1, prev.amount + amount) }));
  };

  const isWin = bet.cashedOut;
  const currentWin = hasActiveBet && !isWin ? (bet.amount * multiplier).toFixed(2) : "0.00";

  return (
    <section className="bg-[#0b1219] p-2 sm:p-4 lg:p-6 border-t border-white/10 shadow-[0_-20px_50px_rgba(0,0,0,0.5)] z-50">
      <div className="max-w-4xl mx-auto flex flex-col md:flex-row gap-2 sm:gap-4 items-stretch">
        
        {/* Input Console */}
        <div className="flex flex-row md:flex-1 gap-2">
          {/* Valor da Aposta */}
          <div className="flex-1 bg-black/40 p-2 sm:p-4 rounded-2xl border border-white/5 flex flex-col justify-between min-h-[60px] sm:min-h-0">
            <div className="flex justify-between items-center mb-1">
              <span className="text-[7px] sm:text-[9px] font-black text-slate-500 uppercase tracking-widest">Valor</span>
              <div className="hidden sm:flex gap-1">
                 {[50, 100, 500].map(v => (
                   <button key={v} onClick={() => adjustBet(v - bet.amount)} className="text-[6px] sm:text-[8px] font-black bg-white/5 px-1.5 py-0.5 rounded sm:rounded-md hover:bg-white/10 transition-colors uppercase">{v}</button>
                 ))}
              </div>
            </div>
            <div className="flex items-center gap-1 sm:gap-4 text-white">
               <button onClick={() => adjustBet(-10)} className="w-7 h-7 sm:w-10 sm:h-10 rounded-lg bg-slate-800 flex items-center justify-center font-black text-sm hover:bg-slate-700 transition-all">-</button>
               <input 
                 type="number" 
                 value={bet.amount}
                 onChange={e => setBet(prev => ({ ...prev, amount: Number(e.target.value) }))}
                 className="flex-1 bg-transparent text-center text-sm sm:text-2xl font-black font-mono outline-none min-w-0"
               />
               <button onClick={() => adjustBet(10)} className="w-7 h-7 sm:w-10 sm:h-10 rounded-lg bg-slate-800 flex items-center justify-center font-black text-sm hover:bg-slate-700 transition-all">+</button>
            </div>
          </div>

          {/* Auto Cashout */}
          <div className="w-1/3 md:w-auto md:min-w-[120px] bg-black/40 p-2 sm:p-4 rounded-2xl border border-white/5 flex flex-col justify-between min-h-[60px] sm:min-h-0">
             <span className="text-[7px] sm:text-[9px] font-black text-slate-500 uppercase tracking-widest mb-1">Auto</span>
             <div className="flex items-center gap-1 bg-[#131d27] rounded-xl p-1.5 border border-white/5">
                <input 
                  type="number" 
                  placeholder="OFF"
                  step="0.1"
                  value={bet.autoCashout || ''}
                  onChange={e => setBet(prev => ({ ...prev, autoCashout: Number(e.target.value) || null }))}
                  className="w-full bg-transparent text-center font-black text-xs sm:text-xl text-[#FFCC00] outline-none placeholder:text-slate-800 min-w-0"
                />
                <span className="text-[#FFCC00]/30 font-black font-mono text-[10px] sm:text-sm">x</span>
             </div>
          </div>
        </div>

        {/* Action Lever (Button) */}
        <div className="w-full md:w-72 h-16 sm:h-24 lg:h-auto">
          {hasActiveBet && !isWin ? (
            <button 
              onClick={onCashOut}
              disabled={status !== GameStatus.FLYING}
              className={`w-full h-full rounded-2xl sm:rounded-3xl flex flex-col items-center justify-center transition-all active:scale-95 shadow-2xl relative overflow-hidden group border-b-2 sm:border-b-8
                ${status === GameStatus.FLYING 
                  ? 'bg-[#FFCC00] hover:bg-[#e6b800] border-orange-700 shadow-orange-900/40 text-black' 
                  : 'bg-slate-800 opacity-50 cursor-not-allowed text-slate-500'}
              `}
            >
              <span className="text-[7px] sm:text-[9px] font-black opacity-50 uppercase tracking-widest leading-none mb-0.5 font-sans">Levantar</span>
              <span className="text-xl sm:text-3xl font-black font-mono leading-none">{currentWin} <span className="text-[0.5em] opacity-60">USDT</span></span>
            </button>
          ) : isWin ? (
            <div className="w-full h-full bg-[#049444]/10 border-2 border-[#049444]/30 rounded-2xl sm:rounded-3xl flex flex-col items-center justify-center animate-in zoom-in duration-300">
               <span className="text-[#049444] font-black text-[8px] sm:text-[10px] uppercase tracking-widest leading-none mb-1 font-sans text-center">Ronda Finalizada</span>
               <span className="text-xl sm:text-3xl font-black text-[#049444] font-mono text-center">+{bet.winAmount.toFixed(2)}</span>
            </div>
          ) : (
            <button 
              onClick={onPlaceBet}
              disabled={status !== GameStatus.BETTING || balance < bet.amount}
              className={`w-full h-full rounded-2xl sm:rounded-3xl flex flex-col items-center justify-center transition-all active:scale-95 shadow-2xl border-b-2 sm:border-b-8 group
                ${status === GameStatus.BETTING && balance >= bet.amount
                  ? 'bg-[#049444] hover:bg-[#037235] border-[#035a2a] shadow-emerald-900/40 text-white' 
                  : 'bg-slate-800 text-slate-600 border-slate-900 border-b-0'}
              `}
            >
              <span className="text-xl sm:text-2xl font-black uppercase tracking-tight group-hover:scale-105 transition-transform font-sans">APOSTAR</span>
              <span className="text-[7px] font-bold opacity-30 uppercase tracking-widest mt-0.5 font-sans">PREMIER BET</span>
            </button>
          )}
        </div>
      </div>
    </section>

  );
};

export default BetPanel;
