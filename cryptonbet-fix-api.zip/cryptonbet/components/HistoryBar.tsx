
import React from 'react';
import { RoundHistory } from '../types';

interface HistoryBarProps {
  history: RoundHistory[];
}

const HistoryBar: React.FC<HistoryBarProps> = ({ history }) => {
  return (
    <div className="h-10 w-full bg-black/40 flex items-center border-y border-white/5 relative overflow-hidden flex-shrink-0">
      {/* Container de Scroll Horizontal Isolado */}
      <div className="flex-1 h-full overflow-x-auto overflow-y-hidden scroll-smooth no-scrollbar px-3">
        <div className="flex items-center gap-2 h-full py-1 flex-nowrap">
          {history.length === 0 ? (
            <span className="text-[8px] font-black text-slate-700 uppercase tracking-[0.2em] whitespace-nowrap">
              A RADARAR CÉUS...
            </span>
          ) : (
            history.map((round) => (
              <div 
                key={round.id}
                className={`
                  flex-shrink-0 inline-flex items-center justify-center px-2 py-0.5 sm:px-3 sm:py-1 rounded-md sm:rounded-lg text-[9px] sm:text-[10px] font-black font-mono border transition-all hover:scale-105 whitespace-nowrap
                  ${round.multiplier < 2 ? 'bg-[#3498db]/10 text-[#3498db] border-[#3498db]/20' : 
                    round.multiplier < 10 ? 'bg-[#913dff]/10 text-[#913dff] border-[#913dff]/20' : 
                    'bg-[#c017b2]/10 text-[#c017b2] border-[#c017b2]/20'}
                `}
              >
                {round.multiplier.toFixed(2)}x
              </div>
            ))
          )}
        </div>
      </div>
      
      {/* Sombra de indicação de scroll à direita */}
      <div className="absolute right-0 top-0 bottom-0 w-8 bg-gradient-to-l from-[#131d27] to-transparent pointer-events-none z-10" />

      <style>{`
        .no-scrollbar::-webkit-scrollbar {
          display: none;
        }
        .no-scrollbar {
          -ms-overflow-style: none;
          scrollbar-width: none;
        }
      `}</style>
    </div>
  );
};

export default HistoryBar;
