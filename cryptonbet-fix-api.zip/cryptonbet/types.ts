
export enum GameStatus {
  IDLE = 'IDLE',
  BETTING = 'BETTING',
  FLYING = 'FLYING',
  CRASHED = 'CRASHED'
}

export type ViewState = 'LOGIN' | 'REGISTER' | 'HOME' | 'AVIATOR' | 'ROULETTE' | 'SLOTS' | 'DICE' | 'LOTTERY' | 'MINES' | 'PLINKO' | 'PENALTY' | 'BLACKJACK' | 'COINFLIP' | 'POKER' | 'KENO' | 'BACCARAT' | 'SCRATCH' | 'WHEEL' | 'CRASH' | 'LIMBO' | 'TOWER' | 'HILO' | 'STAIRS' | 'PROFILE' | 'TRADER' | 'ADMIN' | 'MAINTENANCE' | 'PROMOTIONS' | 'HISTORY' | 'SOCIAL' | 'P2P' | 'PDF_MARKET';

export interface Bet {
  amount: number;
  autoCashout: number | null;
  cashedOut: boolean;
  winAmount: number;
  multiplierAtCashout: number | null;
}

export interface RoundHistory {
  id: string;
  multiplier: number;
  timestamp: number;
}

export interface UserAccount {
  id: string;
  name: string;
  email: string;
  phone?: string;
  balance: number;
  usdtBalance?: number;
  role: 'USER' | 'ADMIN';
  isBanned: boolean;
  joinedAt: string;
  bio?: string;
  avatarColor?: string;
  whatsapp?: string;
}

export interface P2POffer {
  id: string;
  userId: string;
  userName: string;
  type: 'BUY' | 'SELL';
  amount: number;
  totalAmount: number;
  price: number;
  minLimit?: number;
  whatsapp?: string;
  paymentDetails: string;
  createdAt: string;
  status: 'ACTIVE' | 'INACTIVE' | 'COMPLETED';
}

export interface P2PTrade {
  id: string;
  offerId: string;
  buyerId: string;
  buyerName: string;
  sellerId: string;
  sellerName: string;
  amount: number;
  price: number;
  totalKZ: number;
  status: 'PENDING_PAYMENT' | 'PAID' | 'COMPLETED' | 'CANCELLED' | 'DISPUTED';
  paymentProofUrl?: string;
  buyerPhone?: string;
  sellerPhone?: string;
  createdAt: string;
  updatedAt: string;
  disputeReason?: string;
  disputedBy?: string;
}

export interface TransactionRequest {
  id: string;
  userId: string;
  userName: string;
  type: 'DEPOSIT' | 'WITHDRAW';
  amount: number;
  method: string;
  status: 'PENDING' | 'APPROVED' | 'REJECTED';
  timestamp: string;
  proofUrl?: string;
  accountDetails?: string;
}

export interface PaymentMethod {
  id: string;
  name: string;
  type: 'CRYPTO' | 'MOBILE_MONEY' | 'BANK';
  icon: string;
  account: string;
  details?: string;
  isActive: boolean;
  minDeposit: number;
  maxWithdraw: number;
}

export interface GlobalSettings {
  siteName: string;
  maintenanceMode: boolean;
  globalRtp: number;
  baitingMode?: boolean;
  houseAdvantageLevel?: 'LOW' | 'MEDIUM' | 'EXTREME';
  maxRoundPayback?: number;
  fakeWinnersEnabled?: boolean;
  forcedAviatorMultiplier: number | null;
  globalNotification: string | null;
  totalVolume: number;
  totalPaid: number;
  paymentMethods: PaymentMethod[];
}
