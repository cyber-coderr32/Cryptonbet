// Plisio Crypto Payment Service for CryptonBet
// All Plisio API operations are proxied through backend server endpoints (/api/plisio/*)
// to ensure PLISIO_SECRET_KEY remains hidden on the server.

export interface PlisioInvoiceRequest {
  amount: number;
  currency?: string; // Default: 'USDT_TRX' (USDT TRC-20) or 'USDT_BSC', 'USDT_ETH'
  orderNumber: string;
  orderName: string;
  email?: string;
}

export interface PlisioInvoiceResponse {
  status: 'success' | 'error';
  data?: {
    txn_id: string;
    invoice_url: string;
    amount: string;
    currency: string;
    wallet_hash: string;
    qr_code_base64?: string;
    expire_at_utc: number;
  };
  message?: string;
  isSimulated?: boolean;
}

export interface PlisioPayoutRequest {
  amount: number;
  currency?: string;
  toWallet: string;
  type?: 'cash_out';
}

export interface PlisioPayoutResponse {
  status: 'success' | 'error';
  data?: {
    id: string;
    tx_url?: string;
    amount: string;
    currency: string;
    status: string;
  };
  message?: string;
  isSimulated?: boolean;
}

export const SUPPORTED_USDT_NETWORKS = [
  { id: 'USDT_TRX', name: 'USDT (TRC-20)', network: 'TRON (TRC20)', icon: '🔴', fee: '1.00 USDT' },
  { id: 'USDT_BSC', name: 'USDT (BEP-20)', network: 'BNB Smart Chain (BEP20)', icon: '🟡', fee: '0.50 USDT' },
  { id: 'USDT_ETH', name: 'USDT (ERC-20)', network: 'Ethereum (ERC20)', icon: '🔵', fee: '5.00 USDT' },
  { id: 'USDT_MATIC', name: 'USDT (Polygon)', network: 'Polygon (POS)', icon: '🟣', fee: '0.30 USDT' },
];

class PlisioService {
  /**
   * Check if backend has PLISIO_SECRET_KEY configured in environment variables
   */
  public async checkBackendStatus(): Promise<{ configured: boolean; message: string }> {
    try {
      const res = await fetch('/api/plisio/status');
      if (res.ok) {
        return await res.json();
      }
    } catch (e) {
      console.warn('[PlisioService] Failed to check backend status:', e);
    }
    return { configured: false, message: 'Não foi possível verificar a configuração do servidor.' };
  }

  /**
   * Fetch live cryptocurrency rates via backend proxy
   */
  public async getCurrenciesRates(sourceCurrency = 'USD'): Promise<{ [cryptoSymbol: string]: number }> {
    const fallbackRates: { [key: string]: number } = {
      'BTC': 67450.00,
      'ETH': 3480.00,
      'SOL': 178.20,
      'BNB': 585.00,
      'TRX': 0.136,
      'DOGE': 0.128,
      'LTC': 82.50,
      'USDT': 1.00,
      'USDT_TRX': 1.00,
      'USDT_BSC': 1.00,
      'USDT_ETH': 1.00,
    };

    try {
      const response = await fetch(`/api/plisio/currencies?sourceCurrency=${encodeURIComponent(sourceCurrency)}`);
      if (response.ok) {
        const json = await response.json();
        if (json.status === 'success' && json.data) {
          const ratesMap: { [key: string]: number } = { ...fallbackRates };
          const dataArray = Array.isArray(json.data) ? json.data : Object.values(json.data);

          dataArray.forEach((item: any) => {
            const sym = item.cid || item.currency || item.symbol;
            const price = parseFloat(item.rate_usd || item.price_usd || item.crypto_rate_usd || item.rate || 0);
            if (sym && price > 0) {
              ratesMap[sym.toUpperCase()] = price;
            }
          });
          return ratesMap;
        }
      }
    } catch (err) {
      console.warn('[PlisioService] Backend proxy fetch failed, trying public price ticker fallback:', err);
    }

    // Try live Binance API fallback if server proxy fails or is offline
    try {
      const resp = await fetch('https://api.binance.com/api/v3/ticker/price');
      if (resp.ok) {
        const tickers = await resp.json();
        const liveRates: { [key: string]: number } = { ...fallbackRates };
        tickers.forEach((t: { symbol: string; price: string }) => {
          if (t.symbol.endsWith('USDT')) {
            const coin = t.symbol.replace('USDT', '');
            const val = parseFloat(t.price);
            if (val > 0) liveRates[coin] = val;
          }
        });
        return liveRates;
      }
    } catch (e) {
      // ignore
    }

    return fallbackRates;
  }

  /**
   * Format any number as standard USDT currency string
   */
  public formatUSDT(amount: number, showSymbol = true): string {
    const val = Number(amount) || 0;
    const formatted = val.toLocaleString('en-US', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    });
    return showSymbol ? `$ ${formatted} USDT` : `${formatted} USDT`;
  }

  /**
   * Short USDT format e.g. $100.00
   */
  public formatUSDTShort(amount: number): string {
    const val = Number(amount) || 0;
    return `$ ${val.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  }

  /**
   * Create a deposit invoice via backend proxy endpoint
   */
  public async createDepositInvoice(req: PlisioInvoiceRequest): Promise<PlisioInvoiceResponse> {
    try {
      const response = await fetch('/api/plisio/invoice/new', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(req),
      });

      const json = await response.json();

      if (json.status === 'success') {
        return {
          status: 'success',
          data: {
            txn_id: json.data.txn_id,
            invoice_url: json.data.invoice_url,
            amount: json.data.amount,
            currency: json.data.currency,
            wallet_hash: json.data.wallet_hash,
            qr_code_base64: json.data.qr_code_base64,
            expire_at_utc: json.data.expire_at_utc,
          },
          isSimulated: json.isSimulated,
        };
      } else {
        return {
          status: 'error',
          message: json.message || json.data?.message || 'Falha ao gerar fatura de depósito Plisio.'
        };
      }
    } catch (err: any) {
      console.error('[PlisioService] Error creating invoice via backend:', err);
      return {
        status: 'error',
        message: 'Erro de conexão com o servidor da aplicação: ' + (err.message || 'Tente novamente.')
      };
    }
  }

  /**
   * Request a crypto withdrawal (payout) to a wallet via backend proxy
   */
  public async requestWithdrawal(req: PlisioPayoutRequest): Promise<PlisioPayoutResponse> {
    try {
      const response = await fetch('/api/plisio/payout/insert', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(req),
      });

      const json = await response.json();

      if (json.status === 'success') {
        return {
          status: 'success',
          data: {
            id: json.data.id,
            amount: json.data.amount,
            currency: json.data.currency,
            status: json.data.status || 'pending',
            tx_url: json.data.tx_url,
          },
          isSimulated: json.isSimulated,
        };
      } else {
        return {
          status: 'error',
          message: json.message || json.data?.message || 'Falha ao processar saque via Plisio.'
        };
      }
    } catch (err: any) {
      console.error('[PlisioService] Error requesting withdrawal via backend:', err);
      return {
        status: 'error',
        message: 'Erro ao comunicar com o servidor para saque: ' + (err.message || 'Tente novamente.')
      };
    }
  }

  /**
   * Verify transaction status via backend proxy
   */
  public async checkOperationStatus(id: string): Promise<any> {
    try {
      const response = await fetch(`/api/plisio/operations/${id}`);
      return await response.json();
    } catch (err) {
      console.error('[PlisioService] Error checking status:', err);
      return null;
    }
  }
}

export const plisioService = new PlisioService();
