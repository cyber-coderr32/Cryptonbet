import { ref, uploadBytesResumable, getDownloadURL, deleteObject } from 'firebase/storage';
import { storage } from './firebase';

export interface UploadResult {
  url: string;
  path: string;
  name: string;
  size: number;
}

/**
 * Uploads a file to Firebase Storage under the given folder and resolves
 * with its public download URL. Used for post images, story images, PDF
 * covers, ad campaign images and the PDF files themselves — replacing the
 * previous approach of embedding base64 data URIs in localStorage / posting
 * PDFs to a local-disk Express endpoint (which doesn't survive on
 * serverless hosts like Vercel).
 */
export function uploadFile(
  file: File,
  folder: string,
  onProgress?: (percent: number) => void
): Promise<UploadResult> {
  return new Promise((resolve, reject) => {
    const safeName = file.name.replace(/[^a-zA-Z0-9._-]/g, '_');
    const path = `${folder}/${Date.now()}_${Math.random().toString(36).slice(2, 8)}_${safeName}`;
    const storageRef = ref(storage, path);
    const task = uploadBytesResumable(storageRef, file);

    task.on(
      'state_changed',
      (snapshot) => {
        if (onProgress) {
          const percent = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
          onProgress(percent);
        }
      },
      (error) => {
        console.error('[storageService] Upload failed:', error);
        reject(error);
      },
      async () => {
        try {
          const url = await getDownloadURL(task.snapshot.ref);
          resolve({ url, path, name: file.name, size: file.size });
        } catch (err) {
          reject(err);
        }
      }
    );
  });
}

/**
 * Deletes a previously uploaded file given its storage path (the `path`
 * field returned by uploadFile) — best-effort, failures are logged and
 * swallowed since a missing/already-deleted file shouldn't block the caller.
 */
export async function deleteFile(path: string): Promise<void> {
  try {
    await deleteObject(ref(storage, path));
  } catch (err) {
    console.warn('[storageService] Failed to delete file (ignored):', err);
  }
}
