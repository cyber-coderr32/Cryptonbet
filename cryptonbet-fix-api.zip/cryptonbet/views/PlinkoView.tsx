
import React, { useState, useEffect, useRef } from 'react';
import { soundService } from '../services/soundService';

interface PlinkoViewProps {
  balance: number;
  onUpdateBalance: (amount: number) => void;
  onBack: () => void;
}

const RISK_LEVELS = ['LOW', 'MEDIUM', 'HIGH'] as const;
type RiskType = typeof RISK_LEVELS[number];

const MULTIPLIER_MAP: Record<RiskType, Record<number, number[]>> = {
  LOW: {
    8: [5.6, 2.1, 1.1, 1, 0.5, 1, 1.1, 2.1, 5.6],
    10: [8.9, 3, 1.4, 1.1, 1, 0.5, 1, 1.1, 1.4, 3, 8.9],
    12: [10, 5, 2, 1.6, 1.4, 1.2, 1.1, 1, 0.5, 1, 1.1, 1.2, 1.4, 1.6, 2, 5, 10],
    14: [15, 7, 3, 2, 1.5, 1.1, 1, 1, 0.5, 1, 1, 1.1, 1.5, 2, 3, 7, 15],
    16: [16, 9, 4, 3, 2, 1.4, 1.1, 1, 0.5, 1, 1.1, 1.4, 2, 3, 4, 9, 16],
  },
  MEDIUM: {
    8: [13, 3, 1.3, 0.7, 0.4, 0.7, 1.3, 3, 13],
    10: [22, 5, 2, 1.4, 0.6, 0.4, 0.6, 1.4, 2, 5, 22],
    12: [33, 11, 4, 2, 1.1, 0.6, 0.3, 0.6, 1.1, 2, 4, 11, 33],
    14: [58, 15, 7, 4, 1.9, 1, 0.5, 0.2, 0.5, 1, 1.9, 4, 7, 15, 58],
    16: [110, 41, 10, 5, 3, 1.5, 1, 0.5, 0.3, 0.5, 1, 1.5, 3, 5, 10, 41, 110],
  },
  HIGH: {
    8: [29, 4, 1.5, 0.3, 0.2, 0.3, 1.5, 4, 29],
    10: [76, 10, 3, 0.9, 0.3, 0.2, 0.3, 0.9, 3, 10, 76],
    12: [170, 24, 8, 2, 0.7, 0.2, 0.2, 0.2, 0.7, 2, 8, 24, 170],
    14: [420, 56, 18, 5, 2, 0.5, 0.2, 0.2, 0.2, 0.5, 2, 5, 18, 56, 420],
    16: [1000, 130, 26, 9, 4, 2, 0.2, 0.2, 0.2, 0.2, 0.2, 2, 4, 9, 26, 130, 1000],
  }
};

const PlinkoView: React.FC<PlinkoViewProps> = ({ balance, onUpdateBalance, onBack }) => {
  const [bet, setBet] = useState(10);
  const [risk, setRisk] = useState<RiskType>('MEDIUM');
  const [rows, setRows] = useState(8);
  const [balls, setBalls] = useState<{id: number, x: number, y: number, row: number}[]>([]);
  const ballIdCounter = useRef(0);

  const multipliers = MULTIPLIER_MAP[risk][rows] || MULTIPLIER_MAP[risk][8];

  const dropBall = () => {
    if (balance < bet) return;
    onUpdateBalance(-bet);
    const newBall = { id: ballIdCounter.current++, x: 50, y: 0, row: 0 };
    setBalls(prev => [...prev, newBall]);
    soundService.playTick();
  };

  useEffect(() => {
    const interval = setInterval(() => {
      setBalls(prev => prev.map(ball => {
        if (ball.row < rows) {
          const direction = Math.random() > 0.5 ? 1 : -1;
          const stepSize = 100 / (rows * 2); 
          soundService.playTick();
          return { 
            ...ball, 
            x: ball.x + (direction * stepSize), 
            y: ball.y + (100 / (rows + 1)), 
            row: ball.row + 1 
          };
        }
        return ball;
      }).filter(ball => {
        if (ball.row === rows) {
           const segmentWidth = 100 / multipliers.length;
           const index = Math.floor(ball.x / segmentWidth);
           const safeIndex = Math.max(0, Math.min(index, multipliers.length - 1));
           const win = bet * multipliers[safeIndex];
           onUpdateBalance(win);
           if (win > bet) soundService.playWin();
           else if (win < bet) soundService.playLoss();
           return false;
        }
        return true;
      }));
    }, 150);
    return () => clearInterval(interval);
  }, [bet, rows, multipliers]);

  return (
    <div className="h-full flex flex-col bg-[#0b0e11] text-white overflow-hidden">
      <div className="p-4 flex bg-[#131d27] border-b border-white/5 items-center justify-between shrink-0">
        <div className="flex items-center gap-3">
          <button onClick={onBack} className="p-2 hover:bg-white/5 rounded-xl transition-colors text-pink-500">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" /></svg>
          </button>
          <h2 className="font-black uppercase text-sm italic tracking-tighter">PLINKO <span className="text-pink-500">PRO</span></h2>
        </div>
        <div className="bg-black/40 px-4 py-2 rounded-xl border border-white/5 font-mono font-bold text-green-400 text-xs sm:text-base">
          $ {balance.toFixed(2)} USDT
        </div>
      </div>

      <div className="flex-1 flex flex-col items-center justify-between p-4 sm:p-6 relative overflow-hidden bg-[radial-gradient(circle_at_top,_#1a1219_0%,_#0b0e11_100%)] min-h-0">
        {/* Pyramid of Pegs */}
        <div className="relative w-full max-w-lg aspect-[4/3] mb-4 shrink-0">
           {[...Array(rows + 1)].map((_, row) => (
             <div key={row} className="flex justify-center gap-2 sm:gap-4 lg:gap-6" style={{ marginTop: `${Math.min(20, 300/rows)}px` }}>
                {[...Array(row + 3)].map((_, i) => (
                   <div key={i} className="w-1 h-1 bg-slate-700 rounded-full shadow-[0_0_10px_rgba(255,255,255,0.2)]" />
                ))}
             </div>
           ))}

           {/* Animated Balls */}
           {balls.map(ball => (
             <div 
                key={ball.id} 
                className="absolute w-2.5 h-2.5 bg-pink-500 rounded-full shadow-[0_0_15px_#ec4899] z-20" 
                style={{ left: `${ball.x}%`, top: `${ball.y}%`, transform: 'translate(-50%, -50%)', transition: 'all 0.15s linear' }} 
             />
           ))}
        </div>

        {/* Multipliers Bar */}
        <div className="w-full max-w-lg flex gap-0.5 h-8 mb-4 shrink-0">
          {multipliers.map((m, i) => (
            <div key={i} className={`flex-1 flex items-center justify-center rounded text-[7px] font-black border-b-2 transition-all
              ${m >= 5 ? 'bg-red-600 border-red-900' : m >= 1.5 ? 'bg-orange-500 border-orange-800' : 'bg-slate-700 border-slate-900 opacity-60'}`}>
              {m}x
            </div>
          ))}
        </div>

        <div className="w-full max-w-md bg-[#131d27] p-4 rounded-[2rem] border border-white/5 shadow-2xl space-y-4 shrink-0">
           <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-1">
                 <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1">Risco e Linhas</span>
                 <div className="flex flex-col gap-1.5">
                    <div className="flex gap-1 bg-black/40 p-1 rounded-xl">
                       {RISK_LEVELS.map(r => (
                         <button key={r} onClick={() => setRisk(r)} className={`flex-1 py-1.5 rounded-lg text-[9px] font-black transition-all ${risk === r ? 'bg-pink-600 text-white shadow-lg' : 'text-slate-500 hover:bg-white/5'}`}>{r}</button>
                       ))}
                    </div>
                    <select value={rows} onChange={e => setRows(Number(e.target.value))} className="w-full bg-black/40 border border-white/5 px-4 py-2 rounded-xl text-[10px] font-black outline-none focus:border-pink-500/50 appearance-none text-center">
                       {[8, 10, 12, 14, 16].map(r => <option key={r} value={r}>{r} LINHAS</option>)}
                    </select>
                 </div>
              </div>

              <div className="space-y-1">
                 <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1">Aposta (USDT)</span>
                 <div className="flex items-center gap-2 bg-black/40 p-2 rounded-xl border border-white/5 h-[62px]">
                    <button onClick={() => setBet(Math.max(1, bet / 2))} className="w-8 h-8 bg-slate-800 rounded-lg font-black text-xs">½</button>
                    <input type="number" value={bet} onChange={e => setBet(Number(e.target.value))} className="flex-1 bg-transparent text-center font-black text-sm font-mono focus:outline-none" />
                    <button onClick={() => setBet(bet * 2)} className="w-8 h-8 bg-slate-800 rounded-lg font-black text-xs">2x</button>
                 </div>
              </div>
           </div>

           <button onClick={dropBall} className="w-full py-4 bg-pink-600 hover:bg-pink-500 text-white rounded-2xl font-black uppercase tracking-widest shadow-xl border-b-4 border-pink-800 active:scale-95 transition-all">Lançar Bola</button>
        </div>
      </div>
    </div>
  );
};

export default PlinkoView;
