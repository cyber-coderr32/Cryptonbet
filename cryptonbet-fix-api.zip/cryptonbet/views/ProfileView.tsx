import React, { useState, useEffect } from 'react';

import { motion, AnimatePresence } from 'motion/react';
import { 
  Wallet, 
  Settings, 
  BarChart3, 
  LogOut, 
  ChevronLeft, 
  CheckCircle2, 
  Clock, 
  Star,
  ArrowUpRight,
  ArrowDownLeft,
  CreditCard,
  ShieldCheck,
  Zap,
  Sparkles,
  DollarSign,
  Megaphone,
  FileText,
  BookOpen,
  TrendingUp,
  Coins,
  ArrowRight,
  RefreshCw,
  Key,
  ArrowLeftRight,
  X,
  ExternalLink
} from 'lucide-react';
import { soundService } from '../services/soundService';
import { plisioService, SUPPORTED_USDT_NETWORKS } from '../services/plisioService';
import { TransactionRequest, GlobalSettings, PaymentMethod } from '../types';

interface ProfileViewProps {
  balance: number;
  user: { 
    id: string; 
    name: string; 
    email: string;
    phone?: string;
    bio?: string;
    avatarColor?: string;
    whatsapp?: string;
    totalWins?: number;
    totalBets?: number;
  };
  isDemo: boolean;
  onToggleDemo: (val: boolean) => void;
  onUpdateBalance: (amount: number) => void;
  onUpdateUser: (updates: { name: string; phone?: string; bio?: string; avatarColor?: string; whatsapp?: string }) => void;
  onBack: () => void;
  onLogout: () => void;
}

const ProfileView: React.FC<ProfileViewProps> = ({ balance, user, isDemo, onToggleDemo, onUpdateBalance, onUpdateUser, onBack, onLogout }) => {
  const [activeTab, setActiveTab] = useState<'WALLET' | 'SWAP' | 'MONETIZATION' | 'STATS' | 'SETTINGS'>('WALLET');
  const [walletMode, setWalletMode] = useState<'DEPOSIT' | 'WITHDRAW'>('DEPOSIT');

  // Backend Plisio status
  const [backendPlisio, setBackendPlisio] = useState<{ configured: boolean; message: string }>({
    configured: false,
    message: 'A verificar gateway...'
  });

  // Crypto Swap & Buy state
  const [swapToCrypto, setSwapToCrypto] = useState<'BTC' | 'ETH' | 'SOL' | 'BNB' | 'TRX' | 'DOGE'>('BTC');
  const [swapAmountUsdt, setSwapAmountUsdt] = useState<number>(50);
  const [cryptoRates, setCryptoRates] = useState<{ [key: string]: number }>({
    'BTC': 67450.00,
    'ETH': 3480.00,
    'SOL': 178.20,
    'BNB': 585.00,
    'TRX': 0.136,
    'DOGE': 0.128,
  });
  const [isExecutingSwap, setIsExecutingSwap] = useState<boolean>(false);
  const [swapFeedback, setSwapFeedback] = useState<string | null>(null);
  const [cryptoBalances, setCryptoBalances] = useState<{ [key: string]: number }>(() => {
    const saved = localStorage.getItem('user_crypto_balances');
    return saved ? JSON.parse(saved) : { BTC: 0, ETH: 0, SOL: 0, BNB: 0, TRX: 0, DOGE: 0 };
  });

  useEffect(() => {
    plisioService.checkBackendStatus().then(res => setBackendPlisio(res));
    plisioService.getCurrenciesRates('USD').then(rates => {
      setCryptoRates(prev => ({ ...prev, ...rates }));
    });
  }, []);

  const handleExecuteCryptoSwap = () => {
    if (swapAmountUsdt > balance) {
      setSwapFeedback('Saldo USDT insuficiente para realizar esta troca!');
      return;
    }
    if (swapAmountUsdt < 1) {
      setSwapFeedback('O valor mínimo de troca é $ 1.00 USDT');
      return;
    }

    setIsExecutingSwap(true);
    soundService.playUISelect();

    setTimeout(() => {
      const rate = cryptoRates[swapToCrypto] || 1;
      const receivedAmount = swapAmountUsdt / rate;

      // Deduct USDT balance
      onUpdateBalance(-swapAmountUsdt);

      // Update user crypto balance
      const newCryptoBals = {
        ...cryptoBalances,
        [swapToCrypto]: (cryptoBalances[swapToCrypto] || 0) + receivedAmount
      };
      setCryptoBalances(newCryptoBals);
      localStorage.setItem('user_crypto_balances', JSON.stringify(newCryptoBals));

      soundService.playWin();
      setIsExecutingSwap(false);
      setSwapFeedback(`Troca concluída com sucesso! Recebeste ${receivedAmount.toFixed(6)} ${swapToCrypto}.`);
    }, 1200);
  };

  // Creator & Monetization stats calculated from local posts & transactions
  const [userPdfPosts, setUserPdfPosts] = useState<any[]>([]);
  const [pdfSalesTotal, setPdfSalesTotal] = useState<number>(0);
  const [superChatTotal, setSuperChatTotal] = useState<number>(0);
  const [p2pSalesTotal, setP2pSalesTotal] = useState<number>(0);
  const [adReadEarnings, setAdReadEarnings] = useState<number>(0);
  const [campaignCommission, setCampaignCommission] = useState<number>(0);
  const [claimedEarnings, setClaimedEarnings] = useState<number>(0);

  // Stateful form fields for full profile management
  const [editName, setEditName] = useState(user.name);
  const [editPhone, setEditPhone] = useState(user.phone || '');
  const [editBio, setEditBio] = useState(user.bio || '');
  const [editWhatsapp, setEditWhatsapp] = useState(user.whatsapp || '');
  const [selectedAvatarColor, setSelectedAvatarColor] = useState(user.avatarColor || 'bg-gradient-to-tr from-[#049444] to-[#FFCC00]');
  const [isSavingProfile, setIsSavingProfile] = useState(false);

  // Creator configuration
  const [creatorIban, setCreatorIban] = useState<string>('AO06.0040.0000.4152.9912.8271.3 - Banco BAI');
  const [minSuperChat, setMinSuperChat] = useState<number>(500);

  useEffect(() => {
    setEditName(user.name);
    setEditPhone(user.phone || '');
    setEditBio(user.bio || '');
    setEditWhatsapp(user.whatsapp || '');
    setSelectedAvatarColor(user.avatarColor || 'bg-gradient-to-tr from-[#049444] to-[#FFCC00]');

    // Load creator & monetization stats from local storage posts
    try {
      const posts = JSON.parse(localStorage.getItem('cryptonbet_posts') || '[]');
      const myPdfPosts = posts.filter((p: any) => p.postType === 'pdf' && (p.authorId === user.id || p.authorName === user.name));
      setUserPdfPosts(myPdfPosts);

      // Sum PDF revenue: sum of downloads * price
      const totalPdf = myPdfPosts.reduce((acc: number, p: any) => acc + ((p.pdfDownloads || 0) * (p.pdfPrice || 0)), 0);
      setPdfSalesTotal(totalPdf);

      // Sum Super Chat tips received on user posts
      const myPosts = posts.filter((p: any) => p.authorId === user.id || p.authorName === user.name);
      const totalSuper = myPosts.reduce((acc: number, p: any) => acc + (p.superChatTips || 0), 0);
      setSuperChatTotal(totalSuper);

      // Sum P2P sales completed
      const myP2p = posts.filter((p: any) => p.postType === 'p2p' && (p.authorId === user.id || p.authorName === user.name) && p.p2pStatus === 'sold');
      const totalP2p = myP2p.reduce((acc: number, p: any) => acc + (p.p2pPrice || 0), 0);
      setP2pSalesTotal(totalP2p);

      // Load text ad read earnings
      const readEarned = Number(localStorage.getItem(`cryptonbet_ad_read_earnings_${user.id || 'default'}`) || '0');
      setAdReadEarnings(readEarned);

      // Load 30% global campaign revenue share pool
      const globalAdRevenuePool = Number(localStorage.getItem('cryptonbet_global_ad_revenue') || '15000');
      // 30% pool share is allocated to active creators
      setCampaignCommission(Math.floor(globalAdRevenuePool * 0.35));

      // Claimed earnings
      const claimed = Number(localStorage.getItem(`cryptonbet_claimed_earnings_${user.id}`) || '0');
      setClaimedEarnings(claimed);
    } catch (e) {
      console.error("Error loading creator stats", e);
    }
  }, [user]);
  
  const [paymentMethods, setPaymentMethods] = useState<PaymentMethod[]>([]);
  const [selectedMethod, setSelectedMethod] = useState<PaymentMethod | null>(null);
  const [selectedUsdtNetwork, setSelectedUsdtNetwork] = useState<string>('USDT_TRX');
  const [plisioInvoiceData, setPlisioInvoiceData] = useState<any>(null);
  const [depositAmount, setDepositAmount] = useState<number>(50);
  const [paymentStep, setPaymentStep] = useState<'FORM' | 'PROCESSING' | 'SUCCESS'>('FORM');
  
  const [withdrawAmount, setWithdrawAmount] = useState<number>(20);
  const [withdrawAccount, setWithdrawAccount] = useState<string>('');
  const [withdrawStep, setWithdrawStep] = useState<'FORM' | 'PROCESSING' | 'SUCCESS'>('FORM');

  const [feedback, setFeedback] = useState<string | null>(null);

  const [isDesktop, setIsDesktop] = useState(window.innerWidth >= 786);

  // Mocked XP Data
  const playerLevel = 12;
  const currentXP = 750;
  const nextLevelXP = 1200;
  const progressPercent = (currentXP / nextLevelXP) * 100;

  useEffect(() => {
    const handleResize = () => setIsDesktop(window.innerWidth >= 786);
    window.addEventListener('resize', handleResize);
    const settings: GlobalSettings = JSON.parse(localStorage.getItem('skyhigh_settings') || '{}');
    if (settings.paymentMethods) {
      const activeMethods = settings.paymentMethods.filter(m => m.isActive);
      setPaymentMethods(activeMethods);
      if (activeMethods.length > 0) setSelectedMethod(activeMethods[0]);
    }
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const showFeedback = (msg: string) => {
    setFeedback(msg);
    setTimeout(() => setFeedback(null), 3000);
  };

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    soundService.playUISelect();
    setIsSavingProfile(true);
    try {
      await onUpdateUser({
        name: editName,
        phone: editPhone,
        bio: editBio,
        avatarColor: selectedAvatarColor,
        whatsapp: editWhatsapp
      });
      showFeedback('Perfil guardado com sucesso!');
    } catch (err) {
      console.error(err);
      showFeedback('Erro ao guardar perfil.');
    } finally {
      setIsSavingProfile(false);
    }
  };

  const handleGenerateInvoice = async () => {
    setPaymentStep('PROCESSING');
    soundService.playDepositProcessing();

    try {
      const res = await plisioService.createDepositInvoice({
        amount: depositAmount,
        currency: selectedUsdtNetwork,
        orderNumber: 'DEP_' + Date.now(),
        orderName: 'Depósito CryptonBet USDT',
        email: user?.email
      });

      if (res.status === 'success' && res.data) {
        setPlisioInvoiceData(res.data);

        // Record the pending deposit locally; the balance is credited once
        // Plisio confirms the on-chain payment via webhook.
        const transactions: TransactionRequest[] = JSON.parse(localStorage.getItem('skyhigh_transactions') || '[]');
        const newRequest: TransactionRequest = {
          id: res.data.txn_id || Math.random().toString(36).substr(2, 6).toUpperCase(),
          userId: user.id,
          userName: user.name,
          type: 'DEPOSIT',
          amount: depositAmount,
          method: 'CryptonBet Pay (' + selectedUsdtNetwork + ')',
          status: 'PENDING',
          timestamp: new Date().toLocaleString('pt-PT')
        };
        transactions.push(newRequest);
        localStorage.setItem('skyhigh_transactions', JSON.stringify(transactions));

        // Redirect the user straight to Plisio's own hosted checkout page
        // instead of rebuilding a custom invoice UI in-app.
        window.open(res.data.invoice_url, '_blank', 'noopener,noreferrer');

        soundService.playDepositSuccess();
        setPaymentStep('SUCCESS');
      } else {
        showFeedback(res.message || 'Erro ao gerar depósito. Tenta novamente.');
        setPaymentStep('FORM');
      }
    } catch (err) {
      console.error(err);
      showFeedback('Erro ao comunicar com o gateway de pagamento.');
      setPaymentStep('FORM');
    }
  };

  const handleWithdrawRequest = async () => {
    if (withdrawAmount > balance) {
      showFeedback("Saldo insuficiente.");
      soundService.playCrash();
      return;
    }
    if (!withdrawAccount) {
      showFeedback("Insira um endereço de carteira USDT.");
      return;
    }

    setWithdrawStep('PROCESSING');
    soundService.playWithdrawProcessing();
    
    try {
      const res = await plisioService.requestWithdrawal({
        amount: withdrawAmount,
        currency: selectedUsdtNetwork,
        toWallet: withdrawAccount,
      });

      const transactions: TransactionRequest[] = JSON.parse(localStorage.getItem('skyhigh_transactions') || '[]');
      const newRequest: TransactionRequest = {
        id: res.data?.id || Math.random().toString(36).substr(2, 6).toUpperCase(),
        userId: user.id,
        userName: user.name,
        type: 'WITHDRAW',
        amount: withdrawAmount,
        method: 'CryptonBet Pay Payout (' + selectedUsdtNetwork + ')',
        status: 'PENDING',
        timestamp: new Date().toLocaleString('pt-PT')
      };
      transactions.push(newRequest);
      localStorage.setItem('skyhigh_transactions', JSON.stringify(transactions));

      setTimeout(() => {
        setWithdrawStep('SUCCESS');
        soundService.playWithdrawSuccess();
      }, 2000);
    } catch (err) {
      console.error(err);
      showFeedback('Erro ao processar saque.');
      setWithdrawStep('FORM');
    }
  };

  // Mock Transaction History in USDT
  const recentTransactions = [
    { type: 'DEPOSIT', amount: 150.00, date: 'Hoje, 10:24', status: 'COMPLETED' },
    { type: 'WITHDRAW', amount: 50.00, date: 'Ontem, 21:05', status: 'PENDING' },
    { type: 'DEPOSIT', amount: 20.00, date: '04 Mai, 14:12', status: 'COMPLETED' },
  ];

  return (
    <div className="h-full flex flex-col bg-[#060809] text-white overflow-hidden font-sans">
      {/* Header Refinado */}
      <div className="px-4 py-4 flex items-center bg-black/40 backdrop-blur-xl border-b border-white/5 z-30 sticky top-0">
        <button onClick={() => { soundService.playUISelect(); onBack(); }} className="p-2 hover:bg-white/5 rounded-xl transition-all cursor-pointer">
          <ChevronLeft className="w-5 h-5 text-white/50" />
        </button>
        <div className="flex bg-white/5 px-3 py-1 rounded-lg ml-2 border border-white/5">
          <span className="text-[#049444] font-black italic text-sm tracking-tighter">CRYPTON</span>
          <span className="text-[#FFCC00] font-black italic text-sm tracking-tighter ml-1">BET</span>
        </div>
        <button onClick={() => { soundService.playUISelect(); onLogout(); }} className="ml-auto flex items-center gap-2 text-[10px] font-black text-white/40 uppercase hover:text-red-500 transition-colors border border-white/5 px-4 py-2 rounded-xl bg-white/5">
           <LogOut className="w-3 h-3" />
           Sair
        </button>
      </div>

      <div className="flex-1 overflow-y-auto no-scrollbar">
        <div className="max-w-6xl mx-auto p-4 md:p-8 space-y-8">
          
          {/* VIP PLAYER CARD WITH PILOTO GOOGLE CREATOR BADGE & SALDO DASHBOARD */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="relative overflow-hidden group"
          >
            <div className="absolute inset-0 bg-gradient-to-br from-[#049444] via-[#037235] to-[#FFCC00]/10 opacity-20" />
            <div className="bg-[#131d27]/40 backdrop-blur-2xl border border-white/5 rounded-[2.5rem] p-6 md:p-8 flex flex-col lg:flex-row items-center gap-8 relative z-10 shadow-2xl">
                
                <div className="relative group shrink-0">
                   <div className={`w-24 h-24 md:w-32 md:h-32 rounded-full ${user.avatarColor || 'bg-gradient-to-tr from-[#049444] to-[#FFCC00]'} p-1 shadow-2xl relative z-10`}>
                      <div className="w-full h-full rounded-full bg-[#131d27] flex items-center justify-center text-4xl font-black italic text-white border-2 border-white/10 uppercase">
                         {user.name.charAt(0)}
                      </div>
                   </div>
                   <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 bg-[#FFCC00] text-black px-4 py-1 rounded-full text-[10px] font-black uppercase tracking-widest z-20 shadow-xl border-2 border-[#131d27] whitespace-nowrap">
                      Nível {playerLevel}
                   </div>
                   {/* Decorative rings */}
                   <div className="absolute inset-0 rounded-full border border-[#049444]/20 scale-125 animate-pulse" />
                   <div className="absolute inset-0 rounded-full border border-[#FFCC00]/10 scale-150" />
                </div>

                <div className="flex-1 text-center lg:text-left space-y-3">
                   <div className="space-y-1">
                      {/* Piloto Google Creator Official Badge */}
                      <div className="inline-flex items-center gap-1.5 bg-gradient-to-r from-[#FFCC00]/20 via-[#049444]/20 to-transparent border border-[#FFCC00]/40 px-3 py-1 rounded-full text-[9px] font-black text-[#FFCC00] uppercase tracking-widest mb-1 shadow-md">
                         <Sparkles className="w-3.5 h-3.5 text-[#FFCC00]" />
                         <span>PILOTO GOOGLE • CRIADOR VERIFICADO</span>
                         <span className="w-2 h-2 rounded-full bg-[#049444] animate-ping" />
                      </div>

                      <div className="flex items-center justify-center lg:justify-start gap-2">
                         <h2 className="text-2xl md:text-3xl font-black tracking-tighter uppercase italic">{user.name}</h2>
                         <div className="w-5 h-5 bg-[#FFCC00]/20 rounded-full flex items-center justify-center">
                            <Star className="w-3 h-3 text-[#FFCC00] fill-[#FFCC00]" />
                         </div>
                      </div>
                      <p className="text-white/30 text-[10px] font-bold uppercase tracking-[0.2em]">{user.email}</p>
                      {user.bio && (
                         <p className="text-white/60 text-[11px] font-medium mt-1 border-l-2 border-[#049444] pl-3 italic max-w-md leading-relaxed">{user.bio}</p>
                      )}
                      {user.whatsapp && (
                         <p className="text-[#049444] text-[9px] font-black uppercase tracking-widest mt-1.5 flex items-center gap-1 justify-center lg:justify-start">🟢 WhatsApp: {user.whatsapp}</p>
                      )}
                   </div>

                   <div className="space-y-1.5 max-w-sm mx-auto lg:mx-0">
                      <div className="flex justify-between items-end">
                         <span className="text-[9px] font-black text-white/40 uppercase tracking-widest">Prestígio VIP</span>
                         <span className="text-[10px] font-black text-[#FFCC00] uppercase tracking-widest">{currentXP} / {nextLevelXP} XP</span>
                      </div>
                      <div className="h-2 bg-white/5 rounded-full overflow-hidden border border-white/5 p-0.5">
                         <motion.div 
                           initial={{ width: 0 }}
                           animate={{ width: `${progressPercent}%` }}
                           className="h-full bg-gradient-to-r from-[#049444] via-[#049444] to-[#FFCC00] rounded-full shadow-[0_0_15px_rgba(4,148,68,0.5)]"
                         />
                      </div>
                   </div>
                </div>

                {/* Dashboard de Saldo & Monetização */}
                <div className="flex flex-col sm:flex-row lg:flex-col gap-3 w-full lg:w-auto shrink-0">
                   {/* Saldo Principal */}
                   <div className="bg-white/5 border border-white/10 p-4 rounded-2xl text-center lg:text-left min-w-[180px] relative group overflow-hidden">
                      <div className="flex items-center justify-between gap-2 mb-1">
                         <span className="text-[8px] font-black text-white/40 uppercase tracking-widest">Dashboard de Saldo</span>
                         <span className={`text-[7px] font-black px-2 py-0.5 rounded-full uppercase ${isDemo ? 'bg-amber-500/20 text-amber-400' : 'bg-emerald-500/20 text-emerald-400'}`}>
                            {isDemo ? 'Modo Demo' : 'Modo Real'}
                         </span>
                      </div>
                      <div className="text-xl font-black font-mono text-[#049444]">$ {balance.toFixed(2)} <span className="opacity-40 text-xs">USDT</span></div>
                   </div>

                   {/* Saldo de Monetização (E-Books & Super Chat) */}
                   <div className="bg-gradient-to-br from-[#FFCC00]/10 to-black/40 border border-[#FFCC00]/20 p-4 rounded-2xl text-center lg:text-left min-w-[180px] relative">
                      <div className="flex items-center justify-between gap-2 mb-1">
                         <span className="text-[8px] font-black text-[#FFCC00] uppercase tracking-widest flex items-center gap-1">
                            <Zap className="w-3 h-3" /> Monetização Pendente
                         </span>
                         <span className="text-[8px] font-bold text-white/40 font-mono">$ {(pdfSalesTotal + superChatTotal + p2pSalesTotal).toFixed(2)} USDT</span>
                      </div>
                      <div className="text-xl font-black font-mono text-[#FFCC00]">
                         $ {Math.max(0, (pdfSalesTotal + superChatTotal + p2pSalesTotal) - claimedEarnings).toFixed(2)} <span className="opacity-60 text-xs">USDT</span>
                      </div>
                      {Math.max(0, (pdfSalesTotal + superChatTotal + p2pSalesTotal) - claimedEarnings) > 0 && (
                         <button 
                           onClick={() => {
                             soundService.playDepositSuccess();
                             const claimable = Math.max(0, (pdfSalesTotal + superChatTotal + p2pSalesTotal) - claimedEarnings);
                             const newClaimed = claimedEarnings + claimable;
                             localStorage.setItem(`cryptonbet_claimed_earnings_${user.id}`, newClaimed.toString());
                             setClaimedEarnings(newClaimed);
                             onUpdateBalance(claimable);
                             setFeedback(`Transferência de $ ${claimable.toFixed(2)} USDT para o teu saldo principal concluída!`);
                           }}
                           className="mt-2 w-full py-1.5 bg-[#FFCC00] hover:bg-[#e6b800] text-black font-black text-[9px] uppercase tracking-wider rounded-lg transition-all active:scale-95 shadow-md flex items-center justify-center gap-1 cursor-pointer"
                         >
                            <Coins className="w-3 h-3" /> Resgatar para Saldo
                         </button>
                      )}
                   </div>
                </div>
            </div>
          </motion.div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
             
             {/* Navegação de TAb */}
             <div className="lg:col-span-3 space-y-2">
                {[
                  { id: 'WALLET', label: 'Financeiro', icon: Wallet },
                  { id: 'SWAP', label: 'Troca / Compra Cripto', icon: RefreshCw, badge: 'Crypto API' },
                  { id: 'MONETIZATION', label: 'Painel de Monetização', icon: DollarSign, badge: 'Piloto Google' },
                  { id: 'STATS', label: 'Estatísticas', icon: BarChart3 },
                  { id: 'SETTINGS', label: 'Segurança', icon: Settings }
                ].map(t => (
                  <button 
                    key={t.id} 
                    onClick={() => { soundService.playUISelect(); setActiveTab(t.id as any); }} 
                    className={`w-full flex items-center justify-between p-4 rounded-2xl border transition-all cursor-pointer group ${activeTab === t.id ? 'bg-[#049444] border-[#049444] text-white shadow-xl shadow-[#049444]/10' : 'bg-white/5 border-white/5 text-white/40 hover:border-white/20 hover:bg-white/[0.08]'}`}
                  >
                    <div className="flex items-center gap-3">
                       <t.icon className={`w-4 h-4 ${activeTab === t.id ? 'text-white' : 'text-white/40 group-hover:text-white'}`} />
                       <span className="text-[10px] font-black uppercase tracking-widest">{t.label}</span>
                    </div>
                    {t.badge && (
                       <span className="text-[7px] font-black bg-[#FFCC00] text-black px-1.5 py-0.5 rounded uppercase tracking-tighter">{t.badge}</span>
                    )}
                    {activeTab === t.id && <div className="w-1.5 h-1.5 bg-white rounded-full shadow-[0_0_8px_white]" />}
                  </button>
                ))}
             </div>

             <div className="lg:col-span-9">
                <AnimatePresence mode="wait">
                   {activeTab === 'WALLET' && (
                     <motion.div 
                       key="wallet"
                       initial={{ opacity: 0, x: 20 }}
                       animate={{ opacity: 1, x: 0 }}
                       exit={{ opacity: 0, x: -20 }}
                       className="space-y-6"
                     >
                        <div className="bg-[#131d27]/60 backdrop-blur-xl border border-white/5 rounded-[2rem] p-6 space-y-6">
                           <div className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl border text-[9px] font-black uppercase tracking-widest ${backendPlisio.configured ? 'bg-[#049444]/10 border-[#049444]/30 text-[#049444]' : 'bg-amber-500/10 border-amber-500/30 text-amber-400'}`}>
                              <span className={`w-2 h-2 rounded-full ${backendPlisio.configured ? 'bg-[#049444] animate-pulse' : 'bg-amber-400 animate-pulse'}`} />
                              {backendPlisio.configured ? 'Gateway Real Ativo' : 'Modo Simulado — Gateway não configurado'}
                           </div>
                           <div className="flex p-1.5 bg-black/40 rounded-2xl border border-white/5">
                              <button onClick={() => setWalletMode('DEPOSIT')} className={`flex-1 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${walletMode === 'DEPOSIT' ? 'bg-[#049444] text-white shadow-lg' : 'text-white/30 hover:text-white'}`}>Depósito USDT</button>
                              <button onClick={() => setWalletMode('WITHDRAW')} className={`flex-1 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${walletMode === 'WITHDRAW' ? 'bg-[#FFCC00] text-black shadow-lg' : 'text-white/30 hover:text-white'}`}>Levantamento USDT</button>
                           </div>

                           {walletMode === 'DEPOSIT' ? (
                             paymentStep === 'FORM' ? (
                               <div className="space-y-8">
                                  {/* Seleção de Rede USDT */}
                                  <div className="space-y-3">
                                     <label className="text-[10px] font-black text-white/40 uppercase tracking-widest block">Selecione a Rede Crypto</label>
                                     <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                                        {SUPPORTED_USDT_NETWORKS.map(net => (
                                          <button 
                                            key={net.id} 
                                            onClick={() => setSelectedUsdtNetwork(net.id)} 
                                            className={`p-4 rounded-2xl border transition-all flex flex-col items-center gap-1.5 text-center group ${selectedUsdtNetwork === net.id ? 'bg-[#049444]/15 border-[#049444] shadow-lg' : 'bg-black/20 border-white/5 hover:border-white/20'}`}
                                          >
                                            <span className="text-2xl">{net.icon}</span>
                                            <span className={`text-[11px] font-black ${selectedUsdtNetwork === net.id ? 'text-[#049444]' : 'text-white'}`}>{net.name}</span>
                                            <span className="text-[8px] font-mono text-slate-400">{net.network}</span>
                                          </button>
                                        ))}
                                     </div>
                                  </div>

                                  <div className="space-y-4">
                                     <div className="flex justify-between items-end px-2">
                                        <label className="text-[10px] font-black text-white/30 uppercase tracking-widest">Montante em USDT</label>
                                        <span className="text-[10px] font-black text-[#049444] uppercase tracking-widest">Mín: $ 10.00 USDT</span>
                                     </div>
                                     <div className="relative">
                                        <input 
                                          type="number" 
                                          value={depositAmount} 
                                          onChange={e => setDepositAmount(Number(e.target.value))} 
                                          className="w-full bg-black/40 border border-white/5 rounded-3xl px-8 py-6 text-white font-mono font-black text-4xl outline-none focus:border-[#049444] transition-all" 
                                        />
                                        <div className="absolute right-8 top-1/2 -translate-y-1/2 text-2xl font-black text-[#049444] uppercase italic font-mono">USDT</div>
                                     </div>
                                  </div>

                                  <button onClick={handleGenerateInvoice} className="w-full py-5 bg-[#049444] hover:bg-[#037235] text-white rounded-2xl font-black uppercase text-xs tracking-[0.2em] shadow-xl shadow-[#049444]/20 transition-all active:scale-95 group flex items-center justify-center gap-2">
                                     Depositar (Checkout Seguro)
                                     <ArrowUpRight className="w-4 h-4 group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
                                  </button>
                               </div>
                             ) : paymentStep === 'PROCESSING' ? (
                               <div className="py-16 text-center space-y-4 flex flex-col items-center">
                                  <Clock className="w-12 h-12 text-[#049444] animate-spin" />
                                  <p className="text-xs font-black uppercase tracking-widest text-slate-300">Conectando ao gateway de pagamento...</p>
                               </div>
                             ) : (
                               <div className="py-20 text-center space-y-6 flex flex-col items-center">
                                  <div className="w-20 h-20 bg-[#049444]/10 border border-[#049444]/20 text-[#049444] rounded-full flex items-center justify-center text-4xl shadow-2xl shadow-[#049444]/10">
                                     <CheckCircle2 className="w-10 h-10 text-[#049444]" />
                                  </div>
                                  <div className="space-y-2">
                                     <h3 className="text-3xl font-black uppercase italic tracking-tighter">Depósito <span className="text-[#049444]">Registado</span></h3>
                                     <p className="text-white/40 text-[10px] font-bold uppercase tracking-[0.3em] max-w-xs">O checkout seguro foi aberto numa nova janela. Assim que a confirmação na blockchain for concluída, o saldo será ativado automaticamente.</p>
                                  </div>
                                  {plisioInvoiceData?.invoice_url && (
                                     <a
                                       href={plisioInvoiceData.invoice_url}
                                       target="_blank"
                                       rel="noreferrer"
                                       className="px-10 py-4 bg-indigo-600/30 border border-indigo-500/40 text-indigo-300 rounded-2xl font-black text-[10px] uppercase tracking-widest hover:bg-indigo-600/50 transition-all"
                                     >
                                        Reabrir Checkout ↗
                                     </a>
                                  )}
                                  <button onClick={() => setPaymentStep('FORM')} className="px-10 py-4 bg-white/5 hover:bg-white/10 text-white rounded-2xl font-black text-[10px] uppercase tracking-widest border border-white/5 transition-all">Voltar ao Painel</button>
                               </div>
                             )
                           ) : (
                             withdrawStep === 'FORM' ? (
                               <div className="space-y-8">
                                  {/* Seleção de Rede USDT para Levantamento */}
                                  <div className="space-y-3">
                                     <label className="text-[10px] font-black text-white/40 uppercase tracking-widest block">Rede para Saque USDT</label>
                                     <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                                        {SUPPORTED_USDT_NETWORKS.map(net => (
                                          <button 
                                            key={net.id} 
                                            onClick={() => setSelectedUsdtNetwork(net.id)} 
                                            className={`p-3 rounded-2xl border transition-all flex flex-col items-center gap-1 text-center group ${selectedUsdtNetwork === net.id ? 'bg-[#FFCC00]/15 border-[#FFCC00] shadow-lg' : 'bg-black/20 border-white/5 hover:border-white/20'}`}
                                          >
                                            <span className="text-xl">{net.icon}</span>
                                            <span className={`text-[10px] font-black ${selectedUsdtNetwork === net.id ? 'text-[#FFCC00]' : 'text-white'}`}>{net.name}</span>
                                            <span className="text-[7px] font-mono text-slate-400">Taxa: {net.fee}</span>
                                          </button>
                                        ))}
                                     </div>
                                  </div>

                                  <div className="space-y-4">
                                     <div className="flex justify-between items-end px-2">
                                        <label className="text-[10px] font-black text-white/30 uppercase tracking-widest">Valor do Levantamento</label>
                                        <span className="text-[10px] font-black text-red-500 uppercase tracking-widest">Máx: $ {balance.toFixed(2)} USDT</span>
                                     </div>
                                     <div className="relative">
                                        <input 
                                          type="number" 
                                          value={withdrawAmount} 
                                          onChange={e => setWithdrawAmount(Number(e.target.value))} 
                                          className="w-full bg-black/40 border border-white/5 rounded-3xl px-8 py-6 text-white font-mono font-black text-4xl outline-none focus:border-[#FFCC00] transition-all" 
                                        />
                                        <div className="absolute right-8 top-1/2 -translate-y-1/2 text-2xl font-black text-[#FFCC00] uppercase italic font-mono">USDT</div>
                                     </div>
                                  </div>

                                  <div className="space-y-2">
                                     <label className="text-[9px] font-black text-white/30 uppercase ml-4 block tracking-widest">Endereço de Carteira Destino ({selectedUsdtNetwork})</label>
                                     <div className="relative">
                                        <CreditCard className="absolute left-6 top-1/2 -translate-y-1/2 w-5 h-5 text-white/20" />
                                        <input 
                                          type="text" 
                                          placeholder="Ex: T... (TRC20) ou 0x... (BEP20 / ERC20)" 
                                          value={withdrawAccount} 
                                          onChange={e => setWithdrawAccount(e.target.value)} 
                                          className="w-full bg-black/40 border border-white/5 rounded-2xl px-16 py-5 text-white font-mono font-bold text-sm outline-none focus:border-[#FFCC00] transition-all placeholder:text-white/10" 
                                        />
                                     </div>
                                  </div>

                                  <button onClick={handleWithdrawRequest} disabled={withdrawAmount > balance || !withdrawAccount || withdrawAmount < 10} className={`w-full py-5 rounded-2xl font-black uppercase text-xs tracking-[0.2em] transition-all active:scale-95 flex items-center justify-center gap-2 ${withdrawAmount > balance || !withdrawAccount || withdrawAmount < 10 ? 'bg-white/5 text-white/20 cursor-not-allowed' : 'bg-[#FFCC00] text-black shadow-xl shadow-[#FFCC00]/10 hover:bg-[#e6b800] group'}`}>
                                     Solicitar Levantamento Crypto
                                     <ArrowDownLeft className="w-5 h-5 group-hover:-translate-x-1 group-hover:translate-y-1 transition-transform" />
                                  </button>
                               </div>
                             ) : (
                               <div className="py-20 text-center space-y-6 flex flex-col items-center">
                                  <div className="w-20 h-20 bg-[#FFCC00]/10 border border-[#FFCC00]/20 text-[#FFCC00] rounded-full flex items-center justify-center text-4xl shadow-2xl shadow-[#FFCC00]/10">
                                     <Clock className="w-10 h-10 animate-spin-slow" />
                                  </div>
                                  <div className="space-y-2">
                                     <h3 className="text-3xl font-black uppercase italic tracking-tighter">Em <span className="text-[#FFCC00]">Análise</span></h3>
                                     <p className="text-white/30 text-[10px] font-bold uppercase tracking-[0.3em] max-w-xs">O seu pedido está na fila de processamento. Receberá os fundos na sua carteira USDT em breve.</p>
                                  </div>
                                  <button onClick={() => setWithdrawStep('FORM')} className="px-10 py-4 bg-white/5 hover:bg-white/10 text-white rounded-2xl font-black text-[10px] uppercase tracking-widest border border-white/5 transition-all">Fechar</button>
                               </div>
                             )
                           )}
                        </div>

                        {/* Recent Activity List */}
                        <div className="space-y-4">
                           <h4 className="text-[11px] font-black uppercase text-white/30 tracking-[0.3em] ml-4">Atividade Recente</h4>
                           <div className="bg-[#131d27]/40 border border-white/5 rounded-[2rem] overflow-hidden">
                              {recentTransactions.map((tx, i) => (
                                <div key={i} className="flex items-center justify-between p-5 border-b border-white/5 last:border-0 hover:bg-white/5 transition-colors group">
                                   <div className="flex items-center gap-4">
                                      <div className={`w-10 h-10 rounded-xl flex items-center justify-center text-lg ${tx.type === 'DEPOSIT' ? 'bg-[#049444]/10 text-[#049444]' : 'bg-red-500/10 text-red-500'}`}>
                                         {tx.type === 'DEPOSIT' ? <ArrowUpRight className="w-5 h-5" /> : <ArrowDownLeft className="w-5 h-5" />}
                                      </div>
                                      <div>
                                         <p className="text-[11px] font-black uppercase tracking-tight text-white group-hover:text-[#FFCC00] transition-colors">{tx.type === 'DEPOSIT' ? 'Depósito Realizado' : 'Levantamento Solicitado'}</p>
                                         <p className="text-[9px] font-bold text-white/20 uppercase">{tx.date}</p>
                                      </div>
                                   </div>
                                   <div className="text-right">
                                      <p className={`text-sm font-black font-mono ${tx.type === 'DEPOSIT' ? 'text-[#049444]' : 'text-white'}`}>{tx.type === 'DEPOSIT' ? '+' : '-'}$ {tx.amount.toFixed(2)} <span className="text-[10px]">USDT</span></p>
                                      <span className={`text-[8px] font-black px-2 py-0.5 rounded-full uppercase tracking-widest ${tx.status === 'COMPLETED' ? 'bg-[#049444]/20 text-[#049444]' : 'bg-[#FFCC00]/20 text-[#FFCC00]'}`}>{tx.status === 'COMPLETED' ? 'Sucesso' : 'Pendente'}</span>
                                   </div>
                                </div>
                              ))}
                           </div>
                        </div>
                     </motion.div>
                   )}

                   {activeTab === 'SWAP' && (
                     <motion.div 
                       key="swap"
                       initial={{ opacity: 0, x: 20 }}
                       animate={{ opacity: 1, x: 0 }}
                       exit={{ opacity: 0, x: -20 }}
                       className="space-y-6"
                     >
                       <div className="bg-[#131d27]/60 backdrop-blur-xl border border-white/5 rounded-[2rem] p-6 md:p-8 space-y-8">
                         <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 pb-6 border-b border-white/5">
                           <div>
                             <div className="flex items-center gap-2 mb-1">
                               <RefreshCw className="w-5 h-5 text-[#049444]" />
                               <span className="text-[10px] font-black uppercase tracking-widest text-[#049444]">CryptonBet Crypto Exchange & Swap</span>
                             </div>
                             <h3 className="text-2xl font-black uppercase italic tracking-tight text-white">
                               Trocar / Comprar <span className="text-[#FFCC00]">Criptomoedas</span>
                             </h3>
                             <p className="text-[10px] text-slate-400 font-medium">Converte o teu saldo USDT em BTC, ETH, SOL, BNB, TRX ou DOGE usando cotações em tempo real.</p>
                           </div>

                           <div className="bg-black/40 border border-white/10 px-5 py-3 rounded-2xl text-right shrink-0">
                             <span className="text-[8px] font-black text-slate-400 uppercase tracking-widest block">Saldo USDT Disponível</span>
                             <span className="text-lg font-black font-mono text-[#049444]">$ {balance.toFixed(2)} USDT</span>
                           </div>
                         </div>

                         {/* Selection of Target Crypto */}
                         <div className="space-y-3">
                           <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block">1. Seleciona a Criptomoeda Destino</label>
                           <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-3">
                             {[
                               { sym: 'BTC', name: 'Bitcoin', icon: '₿' },
                               { sym: 'ETH', name: 'Ethereum', icon: 'Ξ' },
                               { sym: 'SOL', name: 'Solana', icon: '☀️' },
                               { sym: 'BNB', name: 'Binance', icon: '🟡' },
                               { sym: 'TRX', name: 'Tron', icon: '🔴' },
                               { sym: 'DOGE', name: 'Dogecoin', icon: '🐶' }
                             ].map((coin) => {
                               const rate = cryptoRates[coin.sym] || 1;
                               const isSel = swapToCrypto === coin.sym;
                               return (
                                 <button
                                   key={coin.sym}
                                   type="button"
                                   onClick={() => { soundService.playUISelect(); setSwapToCrypto(coin.sym as any); }}
                                   className={`p-4 rounded-2xl border transition-all flex flex-col items-center text-center gap-1 cursor-pointer ${
                                     isSel ? 'bg-[#049444]/20 border-[#049444] shadow-lg shadow-[#049444]/10' : 'bg-black/30 border-white/5 hover:border-white/20'
                                   }`}
                                 >
                                   <span className="text-2xl mb-1">{coin.icon}</span>
                                   <span className={`text-xs font-black ${isSel ? 'text-[#049444]' : 'text-white'}`}>{coin.sym}</span>
                                   <span className="text-[9px] font-mono font-bold text-slate-400">${rate < 1 ? rate.toFixed(4) : rate.toLocaleString('en-US', { maximumFractionDigits: 2 })}</span>
                                 </button>
                               );
                             })}
                           </div>
                         </div>

                         {/* Amount Input & Calculation */}
                         <div className="grid grid-cols-1 md:grid-cols-2 gap-6 bg-black/40 p-6 rounded-3xl border border-white/5">
                           <div className="space-y-3">
                             <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block">2. Valor a Pagar em USDT</label>
                             <div className="relative">
                               <input 
                                 type="number" 
                                 value={swapAmountUsdt} 
                                 onChange={e => setSwapAmountUsdt(Number(e.target.value))}
                                 className="w-full bg-black/60 border border-white/10 rounded-2xl px-5 py-4 text-white font-mono font-black text-2xl outline-none focus:border-[#049444]"
                               />
                               <span className="absolute right-4 top-1/2 -translate-y-1/2 font-mono font-black text-sm text-[#049444]">USDT</span>
                             </div>

                             <div className="flex gap-2">
                               {[10, 25, 50, 100, 250, 500].map(amt => (
                                 <button
                                   key={amt}
                                   type="button"
                                   onClick={() => setSwapAmountUsdt(amt)}
                                   className="flex-1 py-1.5 bg-white/5 hover:bg-white/10 rounded-lg text-[9px] font-mono font-bold text-slate-300 border border-white/5 cursor-pointer"
                                 >
                                   ${amt}
                                 </button>
                               ))}
                             </div>
                           </div>

                           <div className="space-y-3 flex flex-col justify-between">
                             <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block">3. Receberás Aproximadamente</label>
                             <div className="p-4 bg-gradient-to-tr from-[#049444]/10 to-transparent border border-[#049444]/30 rounded-2xl space-y-1">
                               <div className="text-2xl font-black font-mono text-[#FFCC00]">
                                 {(swapAmountUsdt / (cryptoRates[swapToCrypto] || 1)).toFixed(6)} {swapToCrypto}
                               </div>
                               <div className="text-[9px] font-mono text-slate-400">
                                 1 {swapToCrypto} = ${(cryptoRates[swapToCrypto] || 1).toLocaleString()} USDT (Cotação em tempo real)
                               </div>
                             </div>
                           </div>
                         </div>

                         {swapFeedback && (
                           <div className={`p-4 rounded-2xl text-xs font-black uppercase text-center border ${swapFeedback.includes('sucesso') ? 'bg-[#049444]/20 border-[#049444] text-[#049444]' : 'bg-red-500/20 border-red-500 text-red-400'}`}>
                             {swapFeedback}
                           </div>
                         )}

                         <button
                           type="button"
                           onClick={handleExecuteCryptoSwap}
                           disabled={isExecutingSwap || swapAmountUsdt > balance || swapAmountUsdt <= 0}
                           className="w-full py-5 bg-[#049444] hover:bg-[#037235] disabled:opacity-50 text-white font-black uppercase text-xs tracking-[0.2em] rounded-2xl shadow-xl shadow-[#049444]/20 transition-all flex items-center justify-center gap-2 cursor-pointer"
                         >
                           {isExecutingSwap ? <Clock className="w-5 h-5 animate-spin" /> : <ArrowLeftRight className="w-5 h-5" />}
                           {isExecutingSwap ? 'A Processar Troca...' : `Confirmar Troca por ${swapToCrypto}`}
                         </button>

                         {/* User Crypto Wallet Balances */}
                         <div className="pt-6 border-t border-white/5 space-y-3">
                           <h4 className="text-xs font-black uppercase tracking-widest text-slate-400">Teu Portfolio de Criptomoedas na Carteira</h4>
                           <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-3">
                             {Object.entries(cryptoBalances).map(([sym, amt]) => (
                               <div key={sym} className="bg-black/30 border border-white/5 p-3 rounded-2xl text-center">
                                 <span className="text-[9px] font-black text-slate-500 uppercase block">{sym}</span>
                                 <span className="text-xs font-black font-mono text-white block mt-0.5">{amt.toFixed(4)}</span>
                               </div>
                             ))}
                           </div>
                         </div>
                       </div>
                     </motion.div>
                   )}

                   {activeTab === 'PLISIO_CONFIG' && (
                     <motion.div 
                       key="plisio_config"
                       initial={{ opacity: 0, x: 20 }}
                       animate={{ opacity: 1, x: 0 }}
                       exit={{ opacity: 0, x: -20 }}
                       className="space-y-6"
                     >
                       <div className="bg-[#131d27]/60 backdrop-blur-xl border border-white/5 rounded-[2rem] p-6 md:p-8 space-y-6">
                         <div className="flex items-center gap-3 pb-4 border-b border-white/5">
                           <div className="w-12 h-12 rounded-2xl bg-[#049444]/20 border border-[#049444]/30 flex items-center justify-center text-[#049444]">
                             <Key className="w-6 h-6" />
                           </div>
                           <div>
                             <h3 className="text-xl font-black uppercase italic tracking-tight text-white">Configuração do Gateway de Pagamento</h3>
                             <p className="text-[10px] text-slate-400">Insira a sua Secret Key para habilitar depósitos e saques diretos na blockchain.</p>
                           </div>
                         </div>

                         <div className="p-5 bg-black/40 border border-white/5 rounded-2xl space-y-4">
                           <div className="flex items-center justify-between">
                             <span className="text-[10px] font-black uppercase text-slate-400 tracking-widest">Status da Integração</span>
                             <span className={`text-[9px] font-black uppercase px-3 py-1 rounded-full border ${plisioService.getApiKey() ? 'bg-[#049444]/20 border-[#049444] text-[#049444]' : 'bg-yellow-500/20 border-yellow-500 text-yellow-400'}`}>
                               {plisioService.getApiKey() ? '⚡ API Real Ativa' : '🧪 Modo Simulação Ativo'}
                             </span>
                           </div>

                           <div className="space-y-2">
                             <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest block">Secret / API Key do Gateway</label>
                             <input 
                               type="password" 
                               value={plisioSecretKey}
                               onChange={e => setPlisioSecretKey(e.target.value)}
                               placeholder="Ex: secret_key_plisio_..."
                               className="w-full bg-black/60 border border-white/10 rounded-2xl px-5 py-4 text-white font-mono text-xs outline-none focus:border-[#049444]"
                             />
                             <p className="text-[9px] text-slate-500">A sua chave é mantida apenas no armazenamento local seguro do seu navegador.</p>
                           </div>

                           {plisioKeySaved && (
                             <div className="p-3 bg-[#049444]/20 border border-[#049444] rounded-xl text-xs font-black text-[#049444] uppercase text-center">
                               ✓ Secret Key guardada com sucesso!
                             </div>
                           )}

                           <button
                             type="button"
                             onClick={handleSavePlisioKey}
                             className="w-full py-4 bg-[#FFCC00] hover:bg-[#e6b800] text-black font-black uppercase text-xs tracking-widest rounded-xl transition-all shadow-md cursor-pointer"
                           >
                             Guardar Chave Secreta
                           </button>
                         </div>

                         <div className="p-5 bg-indigo-500/10 border border-indigo-500/20 rounded-2xl space-y-2">
                           <h4 className="text-xs font-black uppercase text-indigo-300">Como obter a sua Secret Key?</h4>
                           <p className="text-[10px] text-slate-300 leading-relaxed">
                             1. Aceda à sua conta oficial em <a href="https://plisio.net" target="_blank" rel="noreferrer" className="text-[#FFCC00] underline font-bold">plisio.net</a><br />
                             2. Navegue até <strong>API Keys / Store Settings</strong>.<br />
                             3. Copie o seu <strong>Secret Key</strong> e cole no campo acima para vincular o gateway de pagamento à sua plataforma CryptonBet.
                           </p>
                         </div>
                       </div>
                     </motion.div>
                   )}

                   {activeTab === 'MONETIZATION' && (
                     <motion.div 
                       key="monetization"
                       initial={{ opacity: 0, x: 20 }}
                       animate={{ opacity: 1, x: 0 }}
                       exit={{ opacity: 0, x: -20 }}
                       className="space-y-6"
                     >
                        {/* Header Banner do Criador Piloto Google */}
                        <div className="bg-gradient-to-r from-[#131d27] via-[#049444]/20 to-[#FFCC00]/10 border border-[#FFCC00]/30 rounded-[2.5rem] p-6 md:p-8 relative overflow-hidden">
                           <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 relative z-10">
                              <div className="space-y-2">
                                 <div className="inline-flex items-center gap-2 bg-[#FFCC00] text-black px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-widest">
                                    <Sparkles className="w-3.5 h-3.5" /> ESTÚDIO DE MONETIZAÇÃO PILOTO GOOGLE
                                 </div>
                                 <h3 className="text-2xl md:text-3xl font-black uppercase tracking-tight italic">
                                    Ganhos de <span className="text-[#FFCC00]">Criador & Conteúdo</span>
                                 </h3>
                                 <p className="text-white/60 text-xs font-medium max-w-xl">
                                    Vende E-Books em PDF, recebe gorjetas Super Chat na comunidade social e comissões P2P. Todos os teus rendimentos são creditados automaticamente.
                                 </p>
                              </div>

                              <div className="bg-black/60 border border-[#FFCC00]/30 p-5 rounded-2xl text-center md:text-right shrink-0">
                                 <span className="text-[9px] font-black text-[#FFCC00] uppercase tracking-widest block mb-1">Rendimento Bruto Total</span>
                                 <div className="text-2xl font-black font-mono text-[#049444]">
                                    $ {(pdfSalesTotal + superChatTotal + p2pSalesTotal + adReadEarnings + campaignCommission).toFixed(2)} <span className="text-xs opacity-50">USDT</span>
                                 </div>
                                 <span className="text-[8px] text-white/40 font-bold uppercase tracking-wider block mt-1">Status: Ativo 🟢</span>
                              </div>
                           </div>
                        </div>

                        {/* 4 Cards de Estatísticas da Monetização */}
                        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                           <div className="bg-[#131d27]/60 border border-white/5 p-5 rounded-2xl">
                              <div className="flex items-center justify-between text-amber-400 mb-2">
                                 <BookOpen className="w-5 h-5" />
                                 <span className="text-[9px] font-black uppercase bg-amber-400/10 px-2 py-0.5 rounded">PDF E-Books</span>
                              </div>
                              <span className="text-[9px] font-black text-white/40 uppercase block">Vendas de PDFs</span>
                              <div className="text-xl font-black font-mono text-white mt-1">$ {pdfSalesTotal.toFixed(2)} USDT</div>
                              <p className="text-[8px] text-white/40 font-bold uppercase mt-1">{userPdfPosts.length} Materiais Publicados</p>
                           </div>

                           <div className="bg-[#131d27]/60 border border-white/5 p-5 rounded-2xl">
                              <div className="flex items-center justify-between text-[#FFCC00] mb-2">
                                 <Zap className="w-5 h-5" />
                                 <span className="text-[9px] font-black uppercase bg-[#FFCC00]/10 px-2 py-0.5 rounded">Super Chat</span>
                              </div>
                              <span className="text-[9px] font-black text-white/40 uppercase block">Gorjetas Recebidas</span>
                              <div className="text-xl font-black font-mono text-white mt-1">$ {superChatTotal.toFixed(2)} USDT</div>
                              <p className="text-[8px] text-white/40 font-bold uppercase mt-1">Apoio da Comunidade</p>
                           </div>

                           <div className="bg-[#131d27]/60 border border-white/5 p-5 rounded-2xl">
                              <div className="flex items-center justify-between text-emerald-400 mb-2">
                                 <TrendingUp className="w-5 h-5" />
                                 <span className="text-[9px] font-black uppercase bg-emerald-400/10 px-2 py-0.5 rounded">Mercado P2P</span>
                              </div>
                              <span className="text-[9px] font-black text-white/40 uppercase block">Volume de Trades P2P</span>
                              <div className="text-xl font-black font-mono text-white mt-1">$ {p2pSalesTotal.toFixed(2)} USDT</div>
                              <p className="text-[8px] text-white/40 font-bold uppercase mt-1">Transações Concluídas</p>
                           </div>

                           <div className="bg-[#131d27]/60 border border-white/5 p-5 rounded-2xl">
                              <div className="flex items-center justify-between text-yellow-400 mb-2">
                                 <Star className="w-5 h-5 fill-yellow-400" />
                                 <span className="text-[9px] font-black uppercase bg-yellow-400/10 px-2 py-0.5 rounded">Reputação</span>
                              </div>
                              <span className="text-[9px] font-black text-white/40 uppercase block">Avaliação do Criador</span>
                              <div className="text-xl font-black font-mono text-white mt-1">4.9 / 5.0</div>
                              <p className="text-[8px] text-emerald-400 font-bold uppercase mt-1">⭐ Criador Recomendado</p>
                           </div>

                           <div className="bg-[#131d27]/60 border border-amber-500/20 p-5 rounded-2xl bg-amber-500/5">
                              <div className="flex items-center justify-between text-amber-400 mb-2">
                                 <DollarSign className="w-5 h-5" />
                                 <span className="text-[9px] font-black uppercase bg-amber-500/20 px-2 py-0.5 rounded text-amber-300">Anúncios Texto</span>
                              </div>
                              <span className="text-[9px] font-black text-white/40 uppercase block">Ganhos por Leitura</span>
                              <div className="text-xl font-black font-mono text-amber-400 mt-1">$ {adReadEarnings.toFixed(2)} USDT</div>
                              <p className="text-[8px] text-amber-400/70 font-bold uppercase mt-1">Lê & Ganha</p>
                           </div>

                           <div className="bg-[#131d27]/60 border border-blue-500/20 p-5 rounded-2xl bg-blue-500/5">
                              <div className="flex items-center justify-between text-blue-400 mb-2">
                                 <Megaphone className="w-5 h-5" />
                                 <span className="text-[9px] font-black uppercase bg-blue-500/20 px-2 py-0.5 rounded text-blue-300">30% Campanhas</span>
                              </div>
                              <span className="text-[9px] font-black text-white/40 uppercase block">Comissão Criador</span>
                              <div className="text-xl font-black font-mono text-blue-400 mt-1">$ {campaignCommission.toFixed(2)} USDT</div>
                              <p className="text-[8px] text-blue-400/70 font-bold uppercase mt-1">Revenue Share Pool</p>
                           </div>
                        </div>

                        {/* Meus Conteúdos Monetizados Publicados */}
                        <div className="bg-[#131d27]/60 border border-white/5 rounded-[2rem] p-6 md:p-8 space-y-6">
                           <div className="flex items-center justify-between">
                              <div>
                                 <h4 className="text-base font-black uppercase tracking-tight text-white italic">
                                    Os Meus <span className="text-[#FFCC00]">E-Books & Conteúdos</span>
                                 </h4>
                                 <p className="text-white/40 text-[10px] font-medium uppercase tracking-wider">Publicações ativas no feed da CryptonBet</p>
                              </div>
                           </div>

                           {userPdfPosts.length === 0 ? (
                              <div className="p-8 border border-dashed border-white/10 rounded-2xl text-center space-y-3">
                                 <FileText className="w-8 h-8 text-white/20 mx-auto" />
                                 <p className="text-xs text-white/40 font-bold uppercase">Ainda não publicou nenhum E-Book em PDF.</p>
                                 <p className="text-[10px] text-white/20">Aceda à aba Social para publicar e-books de estratégia e começar a rentabilizar!</p>
                              </div>
                           ) : (
                              <div className="space-y-3">
                                 {userPdfPosts.map((pdf, idx) => (
                                    <div key={idx} className="bg-black/30 border border-white/5 p-4 rounded-2xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                                       <div className="flex items-center gap-3">
                                          <div className="w-10 h-12 bg-gradient-to-tr from-amber-600 to-amber-900 rounded-lg flex items-center justify-center text-white font-black text-xs shrink-0 shadow">
                                             PDF
                                          </div>
                                          <div>
                                             <h5 className="text-xs font-black text-white uppercase">{pdf.pdfTitle}</h5>
                                             <p className="text-[9px] text-white/40 font-mono">Preço: $ {pdf.pdfPrice} USDT • Downloads: {pdf.pdfDownloads || 0}</p>
                                          </div>
                                       </div>
                                       <div className="text-right shrink-0">
                                          <span className="text-xs font-black font-mono text-[#049444]">
                                             +$ {( (pdf.pdfDownloads || 0) * (pdf.pdfPrice || 0) ).toFixed(2)} USDT
                                          </span>
                                          <span className="block text-[8px] text-white/30 font-bold uppercase">Total Arrecadado</span>
                                       </div>
                                    </div>
                                 ))}
                              </div>
                           )}
                        </div>

                        {/* Configurações da Conta de Monetização */}
                        <div className="bg-[#131d27]/60 border border-white/5 rounded-[2rem] p-6 md:p-8 space-y-6">
                           <h4 className="text-xs font-black uppercase text-white/40 tracking-[0.2em] flex items-center gap-2">
                              <Settings className="w-4 h-4 text-[#FFCC00]" /> Configurações de Vendas & Super Chat
                           </h4>
                           
                           <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                              <div className="space-y-2">
                                 <label className="text-[9px] font-black text-white/30 uppercase ml-2 block">IBAN Oficial para Vendas Directas</label>
                                 <input 
                                   type="text" 
                                   value={creatorIban} 
                                   onChange={(e) => setCreatorIban(e.target.value)}
                                   className="w-full bg-black/40 border border-white/10 rounded-2xl px-5 py-3 text-white text-xs font-mono font-bold outline-none focus:border-[#FFCC00]"
                                 />
                              </div>

                              <div className="space-y-2">
                                 <label className="text-[9px] font-black text-white/30 uppercase ml-2 block">Valor Mínimo de Super Chat (USDT)</label>
                                 <input 
                                   type="number" 
                                   value={minSuperChat} 
                                   onChange={(e) => setMinSuperChat(Number(e.target.value))}
                                   className="w-full bg-black/40 border border-white/10 rounded-2xl px-5 py-3 text-white text-xs font-mono font-bold outline-none focus:border-[#FFCC00]"
                                 />
                              </div>
                           </div>

                           <button 
                             onClick={() => {
                               soundService.playUISelect();
                               showFeedback('Definições de Monetização guardadas!');
                             }}
                             className="py-3 px-8 bg-[#FFCC00] hover:bg-[#e6b800] text-black font-black text-xs uppercase tracking-wider rounded-xl transition-all shadow-md cursor-pointer"
                           >
                              Guardar Configurações de Criador
                           </button>
                        </div>
                     </motion.div>
                   )}

                   {activeTab === 'STATS' && (
                     <motion.div 
                       key="stats"
                       initial={{ opacity: 0, scale: 0.95 }}
                       animate={{ opacity: 1, scale: 1 }}
                       exit={{ opacity: 0, scale: 0.95 }}
                       className="grid grid-cols-1 sm:grid-cols-2 gap-6"
                     >
                        {[
                          { l: 'Total de Apostas', v: '1,452', sub: '+12% este mês', icon: Star },
                          { l: 'Maior Multiplicador', v: '248.50x', sub: 'No Aviator', icon: ArrowUpRight },
                          { l: 'Lucro Líquido (Real)', v: '$ 425.00 USDT', sub: 'Recorde pessoal', icon: Wallet },
                          { l: 'Nível de Prestígio', v: 'Safira II', sub: 'Próximo: Safira III', icon: ShieldCheck }
                        ].map((s, i) => (
                          <div key={i} className="bg-[#131d27]/60 border border-white/5 p-8 rounded-[2.5rem] relative group hover:border-[#049444]/30 transition-all overflow-hidden">
                             <div className="absolute -right-4 -bottom-4 opacity-[0.03] text-8xl rotate-12 group-hover:opacity-[0.05] transition-opacity">
                                <s.icon />
                             </div>
                             <span className="text-[10px] font-black text-white/30 uppercase tracking-[0.2em] block mb-2">{s.l}</span>
                             <div className="text-3xl font-black font-mono text-white tracking-tighter mb-1 uppercase">{s.v}</div>
                             <p className="text-[9px] font-bold text-[#049444] uppercase tracking-widest">{s.sub}</p>
                          </div>
                        ))}
                     </motion.div>
                   )}

                                       {activeTab === 'SETTINGS' && (
                       <motion.div 
                         key="settings"
                         initial={{ opacity: 0, y: 20 }}
                         animate={{ opacity: 1, y: 0 }}
                         className="bg-[#131d27]/60 backdrop-blur-xl border border-white/5 rounded-[2rem] p-8 space-y-10"
                       >
                          <form onSubmit={handleSaveProfile} className="space-y-6">
                             <h4 className="text-[11px] font-black uppercase text-white/30 tracking-[0.3em] flex items-center gap-2">
                                Perfil Completo & Segurança
                             </h4>
                             
                             <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div className="flex flex-col gap-2">
                                   <label className="text-[9px] font-black text-white/20 uppercase ml-4">Nome de Jogador</label>
                                   <input 
                                     type="text" 
                                     value={editName} 
                                     onChange={(e) => setEditName(e.target.value)}
                                     required
                                     className="bg-white/5 border border-white/5 rounded-2xl px-6 py-4 text-white font-bold text-xs uppercase focus:outline-none focus:border-[#049444]/50 transition-colors" 
                                   />
                                </div>

                                <div className="flex flex-col gap-2">
                                   <label className="text-[9px] font-black text-white/20 uppercase ml-4">Telefone / Contacto</label>
                                   <input 
                                     type="text" 
                                     value={editPhone} 
                                     onChange={(e) => setEditPhone(e.target.value)}
                                     placeholder="+244 9..."
                                     className="bg-white/5 border border-white/5 rounded-2xl px-6 py-4 text-white font-bold text-xs focus:outline-none focus:border-[#049444]/50 transition-colors" 
                                   />
                                </div>

                                <div className="flex flex-col gap-2">
                                   <label className="text-[9px] font-black text-white/20 uppercase ml-4">WhatsApp Link / Direct</label>
                                   <input 
                                     type="text" 
                                     value={editWhatsapp} 
                                     onChange={(e) => setEditWhatsapp(e.target.value)}
                                     placeholder="+244 923 000 000"
                                     className="bg-white/5 border border-white/5 rounded-2xl px-6 py-4 text-white font-bold text-xs focus:outline-none focus:border-[#049444]/50 transition-colors" 
                                   />
                                </div>

                                <div className="flex flex-col gap-2">
                                   <label className="text-[9px] font-black text-white/20 uppercase ml-4">Email da Conta</label>
                                   <input 
                                     type="email" 
                                     value={user.email} 
                                     disabled 
                                     className="bg-white/5 border border-white/5 rounded-2xl px-6 py-4 text-white/40 font-bold text-xs cursor-not-allowed" 
                                   />
                                </div>
                             </div>

                             <div className="flex flex-col gap-2">
                                <label className="text-[9px] font-black text-white/20 uppercase ml-4">Biografia / Apresentação</label>
                                <textarea 
                                  value={editBio} 
                                  onChange={(e) => setEditBio(e.target.value)}
                                  placeholder="Escreve algo sobre o teu perfil de trader no CryptonBet Angola..."
                                  rows={3}
                                  className="bg-white/5 border border-white/5 rounded-2xl px-6 py-4 text-white font-bold text-xs focus:outline-none focus:border-[#049444]/50 transition-colors resize-none" 
                                />
                             </div>

                             <div className="space-y-2">
                                <label className="text-[9px] font-black text-white/20 uppercase ml-4 block">Cor do Emblema de Avatar</label>
                                <div className="flex items-center gap-3 bg-white/5 p-4 rounded-2xl border border-white/5">
                                   {[
                                     { label: 'Crypton', class: 'bg-gradient-to-tr from-[#049444] to-[#FFCC00]' },
                                     { label: 'Sun', class: 'bg-gradient-to-tr from-[#ff416c] to-[#ff4b2b]' },
                                     { label: 'Cyber', class: 'bg-gradient-to-tr from-[#8a2387] to-[#e94057]' },
                                     { label: 'Ocean', class: 'bg-gradient-to-tr from-[#11998e] to-[#38ef7d]' },
                                     { label: 'Midnight', class: 'bg-gradient-to-tr from-[#0f2027] to-[#203a43]' }
                                   ].map((item, idx) => (
                                      <button
                                        key={idx}
                                        type="button"
                                        onClick={() => { setSelectedAvatarColor(item.class); }}
                                        className={`w-10 h-10 rounded-full ${item.class} border-2 transition-all relative ${selectedAvatarColor === item.class ? 'border-white scale-110 shadow-lg' : 'border-transparent hover:scale-105'}`}
                                        title={item.label}
                                      >
                                        {selectedAvatarColor === item.class && (
                                           <div className="absolute inset-0 flex items-center justify-center text-white text-[10px]">✓</div>
                                        )}
                                      </button>
                                   ))}
                                </div>
                             </div>

                             <div className="flex items-center justify-between p-5 bg-white/5 rounded-2xl border border-white/5">
                                <div>
                                   <h5 className="text-[11px] font-black text-white uppercase tracking-tight">Modo de Demonstração</h5>
                                   <p className="text-[9px] font-bold text-white/20 uppercase tracking-widest">Alternar para apostas virtuais</p>
                                </div>
                                <button 
                                  type="button"
                                  onClick={() => onToggleDemo(!isDemo)} 
                                  className={`w-14 h-7 rounded-full relative transition-all ${isDemo ? 'bg-[#FFCC00]' : 'bg-white/10'}`}
                                >
                                   <motion.div 
                                     animate={{ x: isDemo ? 28 : 4 }}
                                     className="absolute top-1 w-5 h-5 bg-white rounded-full shadow-xl"
                                   />
                                </button>
                             </div>

                             <button
                               type="submit"
                               disabled={isSavingProfile}
                               className="w-full bg-[#049444] hover:bg-[#037235] text-white py-4 rounded-2xl font-black text-xs uppercase tracking-widest transition-all shadow-lg border border-white/10 flex items-center justify-center gap-2"
                             >
                               {isSavingProfile ? 'A guardar...' : 'Guardar Alterações do Perfil'}
                             </button>
                          </form>

                          <div className="pt-6 border-t border-white/5">
                             <p className="text-[8px] font-bold text-white/10 uppercase text-center tracking-[0.5em]">CryptonBet System • ID: {user.id.toUpperCase()}</p>
                          </div>
                       </motion.div>
                    )}
                </AnimatePresence>
             </div>
          </div>
        </div>
      </div>

      {feedback && (
        <motion.div 
          initial={{ opacity: 0, y: -20, x: '-50%' }}
          animate={{ opacity: 1, y: 0, x: '-50%' }}
          exit={{ opacity: 0, y: -20, x: '-50%' }}
          className="fixed top-6 left-1/2 -translate-x-1/2 bg-[#049444] text-white px-8 py-4 rounded-2xl font-black uppercase text-[11px] tracking-widest shadow-2xl z-[1000] border border-white/20 shadow-[#049444]/20"
        >
          <div className="flex items-center gap-3">
             <CheckCircle2 className="w-4 h-4" />
             {feedback}
          </div>
        </motion.div>
      )}

    </div>
  );
};

export default ProfileView;

