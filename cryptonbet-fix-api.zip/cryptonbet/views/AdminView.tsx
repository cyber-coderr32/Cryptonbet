import React, { useState, useEffect } from 'react';
import { UserAccount, TransactionRequest, GlobalSettings, PaymentMethod, P2POffer } from '../types';
import { soundService } from '../services/soundService';
import { db } from '../services/firebase';
import { collection, getDocs, doc, updateDoc, setDoc, query, limit } from 'firebase/firestore';
import { 
  ShieldCheck, 
  TrendingUp, 
  Users, 
  Wallet, 
  CreditCard, 
  Cpu, 
  Megaphone, 
  Search, 
  CheckCircle2, 
  XCircle, 
  Plus, 
  Trash2, 
  Edit3, 
  Lock, 
  Unlock, 
  ArrowUpRight, 
  ArrowDownLeft, 
  BookOpen, 
  RefreshCw, 
  Sliders, 
  Eye, 
  DollarSign, 
  AlertTriangle, 
  Zap, 
  Sparkles,
  ChevronRight,
  LogOut,
  Radio,
  FileText
} from 'lucide-react';

interface AdminViewProps {
  onBack: () => void;
}

type AdminTab = 'DASHBOARD' | 'USERS' | 'FINANCE' | 'PAYMENTS' | 'ENGINE' | 'P2P_MARKET';

const LOCAL_USERS_KEY = 'skyhigh_users';
const LOCAL_TRANS_KEY = 'skyhigh_transactions';
const LOCAL_SETTINGS_KEY = 'skyhigh_settings';

export const AdminView: React.FC<AdminViewProps> = ({ onBack }) => {
  const [activeTab, setActiveTab] = useState<AdminTab>('DASHBOARD');
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);

  const [users, setUsers] = useState<UserAccount[]>([]);
  const [transactions, setTransactions] = useState<TransactionRequest[]>([]);
  const [p2pOffers, setP2POffers] = useState<P2POffer[]>([]);
  
  const [settings, setSettings] = useState<GlobalSettings>({
    siteName: 'CryptonBet Angola',
    maintenanceMode: false,
    globalRtp: 95,
    baitingMode: true,
    houseAdvantageLevel: 'MEDIUM',
    fakeWinnersEnabled: true,
    maxRoundPayback: 500000,
    forcedAviatorMultiplier: null,
    globalNotification: '⚡ Bónus Especial de Depósito: Receba 100% de Bónus no seu primeiro depósito via Multicaixa Express!',
    totalVolume: 4250000,
    totalPaid: 3120000,
    paymentMethods: [
      {
        id: 'multicaixa_express',
        name: 'Multicaixa Express',
        type: 'MOBILE_MONEY',
        icon: 'https://images.unsplash.com/photo-1559526324-4b87b5e36e44?auto=format&fit=crop&w=100&q=80',
        account: '923 456 789 (CryptonBet AO)',
        details: 'Envie o comprovativo por WhatsApp ou carregue o ficheiro',
        isActive: true,
        minDeposit: 500,
        maxWithdraw: 500000
      },
      {
        id: 'iban_bai',
        name: 'Transferência IBAN (BAI)',
        type: 'BANK',
        icon: 'https://images.unsplash.com/photo-1541354329998-f4d9a9f9297f?auto=format&fit=crop&w=100&q=80',
        account: 'AO06 0040 0000 1234 5678 1015 4',
        details: 'Banco Angolano de Investimentos (BAI) - Titular: CryptonBet Lda',
        isActive: true,
        minDeposit: 1000,
        maxWithdraw: 1000000
      },
      {
        id: 'usdt_trc20',
        name: 'USDT (TRC-20 Cripto)',
        type: 'CRYPTO',
        icon: 'https://images.unsplash.com/photo-1621416894569-0f39ed31d247?auto=format&fit=crop&w=100&q=80',
        account: 'TYd8S1kX9aPz2mQqR4vW7tL0uJ3bC5nE',
        details: 'Rede TRON (TRC20) • Cotação 1 USDT = 950 Kz',
        isActive: true,
        minDeposit: 10,
        maxWithdraw: 10000
      }
    ]
  });

  const [editingMethod, setEditingMethod] = useState<Partial<PaymentMethod> | null>(null);
  const [searchUser, setSearchUser] = useState('');
  const [searchTrans, setSearchTrans] = useState('');
  const [selectedUserForCredit, setSelectedUserForCredit] = useState<UserAccount | null>(null);
  const [creditAmount, setCreditAmount] = useState<string>('');
  const [creditReason, setCreditReason] = useState<string>('Ajuste Administrativo');

  // Load initial data from Firestore & LocalStorage
  const loadData = async () => {
    setIsLoading(true);
    try {
      // 1. Fetch Users
      const localUsers = JSON.parse(localStorage.getItem(LOCAL_USERS_KEY) || '[]');
      try {
        const usersSnap = await getDocs(query(collection(db, 'users'), limit(100)));
        if (!usersSnap.empty) {
          const firestoreUsers: UserAccount[] = usersSnap.docs.map(docSnap => {
            const data = docSnap.data();
            return {
              id: docSnap.id,
              name: data.displayName || data.name || 'Jogador',
              email: data.email || '',
              phone: data.phone || '',
              balance: data.balance !== undefined ? data.balance : 100,
              role: data.role || 'USER',
              isBanned: data.isBanned || false,
              joinedAt: data.joinedAt || new Date().toISOString(),
              bio: data.bio || '',
              avatarColor: data.avatarColor || 'bg-gradient-to-tr from-[#049444] to-[#FFCC00]',
              whatsapp: data.whatsapp || ''
            };
          });
          
          // Merge local and firestore users
          const combined = [...firestoreUsers];
          localUsers.forEach((lu: UserAccount) => {
            if (!combined.some(c => c.id === lu.id)) {
              combined.push(lu);
            }
          });
          setUsers(combined);
        } else {
          setUsers(localUsers);
        }
      } catch (e) {
        console.warn("Firestore users query failed, using local storage", e);
        setUsers(localUsers);
      }

      // 2. Fetch Transactions
      const localTrans = JSON.parse(localStorage.getItem(LOCAL_TRANS_KEY) || '[]');
      try {
        const transSnap = await getDocs(query(collection(db, 'transactions'), limit(100)));
        if (!transSnap.empty) {
          const fsTrans = transSnap.docs.map(d => ({ id: d.id, ...d.data() } as TransactionRequest));
          setTransactions(fsTrans);
        } else {
          setTransactions(localTrans);
        }
      } catch (e) {
        setTransactions(localTrans);
      }

      // 3. Settings
      const savedSettings = JSON.parse(localStorage.getItem(LOCAL_SETTINGS_KEY) || 'null');
      if (savedSettings) {
        setSettings(prev => ({ ...prev, ...savedSettings }));
      }
    } catch (err) {
      console.error("Error loading admin data:", err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const saveSettings = (newSettings: GlobalSettings) => {
    setSettings(newSettings);
    localStorage.setItem(LOCAL_SETTINGS_KEY, JSON.stringify(newSettings));
    showNotification("Definições do Sistema Atualizadas com Sucesso!");
    soundService.playWin();
  };

  const updateUsersState = (newUsers: UserAccount[]) => {
    setUsers(newUsers);
    localStorage.setItem(LOCAL_USERS_KEY, JSON.stringify(newUsers));
  };

  const showNotification = (msg: string) => {
    setStatusMessage(msg);
    setTimeout(() => setStatusMessage(null), 4000);
  };

  // Resolve Deposit / Withdrawal Request
  const handleResolveTransaction = async (id: string, status: 'APPROVED' | 'REJECTED') => {
    const trans = transactions.find(t => t.id === id);
    if (!trans) return;

    if (status === 'APPROVED') {
      const userToUpdate = users.find(u => u.id === trans.userId);
      if (userToUpdate) {
        const balanceChange = trans.type === 'DEPOSIT' ? trans.amount : -trans.amount;
        const newBalance = Math.max(0, userToUpdate.balance + balanceChange);
        const updatedUsers = users.map(u => u.id === trans.userId ? { ...u, balance: newBalance } : u);
        updateUsersState(updatedUsers);

        // Try syncing to Firestore
        try {
          await updateDoc(doc(db, 'users', trans.userId), { balance: newBalance });
        } catch (e) {
          console.warn("Firestore update failed, saved locally.");
        }
      }
    }

    const updatedTrans = transactions.map(t => t.id === id ? { ...t, status } : t);
    setTransactions(updatedTrans);
    localStorage.setItem(LOCAL_TRANS_KEY, JSON.stringify(updatedTrans));

    // Try syncing transaction status to Firestore
    try {
      await updateDoc(doc(db, 'transactions', id), { status });
    } catch (e) {
      // ignore
    }

    soundService.playTick();
    showNotification(`Transação #${id.substring(0, 6)} ${status === 'APPROVED' ? 'Aprovada' : 'Rejeitada'}!`);
  };

  // Direct Credit / Debit User Balance Kz
  const handleManualCredit = async () => {
    if (!selectedUserForCredit || !creditAmount || isNaN(Number(creditAmount))) {
      alert("Por favor, introduza um valor válido em Kwanza.");
      return;
    }

    const delta = Number(creditAmount);
    const newBalance = Math.max(0, selectedUserForCredit.balance + delta);
    const updatedUsers = users.map(u => u.id === selectedUserForCredit.id ? { ...u, balance: newBalance } : u);
    updateUsersState(updatedUsers);

    // Add manual record
    const newTrans: TransactionRequest = {
      id: 'tx_manual_' + Date.now(),
      userId: selectedUserForCredit.id,
      userName: selectedUserForCredit.name,
      type: delta >= 0 ? 'DEPOSIT' : 'WITHDRAW',
      amount: Math.abs(delta),
      method: `Ajuste Admin (${creditReason})`,
      status: 'APPROVED',
      timestamp: new Date().toLocaleString('pt-AO')
    };

    const updatedTrans = [newTrans, ...transactions];
    setTransactions(updatedTrans);
    localStorage.setItem(LOCAL_TRANS_KEY, JSON.stringify(updatedTrans));

    try {
      await updateDoc(doc(db, 'users', selectedUserForCredit.id), { balance: newBalance });
    } catch (e) {
      // fallback
    }

    soundService.playWin();
    showNotification(`Saldo de ${selectedUserForCredit.name} atualizado para ${newBalance.toLocaleString('pt-AO')} Kz!`);
    setSelectedUserForCredit(null);
    setCreditAmount('');
  };

  // Toggle Ban / Unban User
  const handleToggleBanUser = async (user: UserAccount) => {
    const updated = users.map(u => u.id === user.id ? { ...u, isBanned: !u.isBanned } : u);
    updateUsersState(updated);

    try {
      await updateDoc(doc(db, 'users', user.id), { isBanned: !user.isBanned });
    } catch (e) {
      // fallback
    }

    soundService.playCrash();
    showNotification(`Usuário ${user.name} ${!user.isBanned ? 'BANIDO' : 'DESBANIDO'} com sucesso!`);
  };

  // Toggle Role (USER <-> ADMIN)
  const handleToggleRole = async (user: UserAccount) => {
    const newRole = user.role === 'ADMIN' ? 'USER' : 'ADMIN';
    const updated = users.map(u => u.id === user.id ? { ...u, role: newRole as 'USER' | 'ADMIN' } : u);
    updateUsersState(updated);

    try {
      await updateDoc(doc(db, 'users', user.id), { role: newRole });
    } catch (e) {
      // fallback
    }

    soundService.playWin();
    showNotification(`Função de ${user.name} alterada para ${newRole}!`);
  };

  // Save / Add Payment Gateway
  const handleSavePaymentMethod = () => {
    if (!editingMethod?.name || !editingMethod?.account) {
      alert("Por favor, preencha o nome do método e os dados da conta.");
      return;
    }
    const newMethods = [...settings.paymentMethods];
    const index = newMethods.findIndex(m => m.id === editingMethod.id);
    
    if (index >= 0) {
      newMethods[index] = { ...newMethods[index], ...editingMethod } as PaymentMethod;
    } else {
      newMethods.push({
        ...editingMethod,
        id: 'pm_' + Math.random().toString(36).substr(2, 8),
        isActive: true,
        minDeposit: editingMethod.minDeposit || 500,
        maxWithdraw: editingMethod.maxWithdraw || 500000
      } as PaymentMethod);
    }
    saveSettings({ ...settings, paymentMethods: newMethods });
    setEditingMethod(null);
  };

  const menuItems = [
    { id: 'DASHBOARD' as AdminTab, label: 'Telemetria & Dashboard', icon: <TrendingUp className="w-5 h-5 text-cyan-400" /> },
    { id: 'USERS' as AdminTab, label: 'Gestão de Jogadores', icon: <Users className="w-5 h-5 text-emerald-400" /> },
    { id: 'FINANCE' as AdminTab, label: 'Aprovação Financeira', icon: <Wallet className="w-5 h-5 text-amber-400" /> },
    { id: 'PAYMENTS' as AdminTab, label: 'Métodos de Pagamento', icon: <CreditCard className="w-5 h-5 text-purple-400" /> },
    { id: 'ENGINE' as AdminTab, label: 'Motor & Algoritmos (RTP)', icon: <Cpu className="w-5 h-5 text-red-400" /> },
  ];

  const pendingCount = transactions.filter(t => t.status === 'PENDING').length;
  const approvedDeposits = transactions.filter(t => t.type === 'DEPOSIT' && t.status === 'APPROVED').reduce((acc, t) => acc + t.amount, 0);
  const approvedWithdrawals = transactions.filter(t => t.type === 'WITHDRAW' && t.status === 'APPROVED').reduce((acc, t) => acc + t.amount, 0);
  const totalUsersCount = users.length;
  const totalBannedCount = users.filter(u => u.isBanned).length;

  return (
    <div className="h-full flex bg-[#03060a] text-slate-100 font-sans overflow-hidden relative selection:bg-[#049444] selection:text-white">
      
      {/* BACKGROUND FUTURISTIC GRID */}
      <div className="absolute inset-0 bg-[radial-gradient(#049444_1px,transparent_1px)] [background-size:24px_24px] opacity-10 pointer-events-none" />
      
      {/* STATUS TOAST NOTIFICATION */}
      {statusMessage && (
        <div className="fixed top-5 right-5 z-[250] bg-gradient-to-r from-emerald-600 to-teal-600 text-white px-5 py-3 rounded-2xl shadow-[0_0_30px_rgba(4,148,68,0.5)] border border-emerald-400/40 flex items-center gap-3 animate-in fade-in slide-in-from-top-4">
          <Sparkles className="w-5 h-5 text-yellow-300 animate-spin" />
          <span className="font-black text-xs uppercase tracking-wider">{statusMessage}</span>
        </div>
      )}

      {/* MOBILE OVERLAY */}
      {isSidebarOpen && (
        <div 
          className="fixed inset-0 bg-black/80 backdrop-blur-md z-[160] lg:hidden"
          onClick={() => setIsSidebarOpen(false)}
        />
      )}

      {/* SIDEBAR NAVIGATION */}
      <aside className={`
        fixed lg:relative top-0 left-0 h-full bg-[#090e17]/95 backdrop-blur-2xl border-r border-white/10 flex flex-col shadow-[0_0_50px_rgba(0,0,0,0.8)] z-[170] transition-transform duration-300 w-72 shrink-0
        ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
      `}>
        {/* LOGO AREA */}
        <div className="p-6 border-b border-white/10 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-amber-500 to-yellow-600 flex items-center justify-center text-black font-black shadow-[0_0_20px_rgba(245,158,11,0.4)] shrink-0">
              <ShieldCheck className="w-6 h-6 text-black" />
            </div>
            <div>
              <h1 className="font-black italic tracking-tighter text-lg leading-none text-white">
                CRYPTON<span className="text-amber-400">ADMIN</span>
              </h1>
              <p className="text-[8px] font-black text-emerald-400 uppercase tracking-widest mt-1 flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                Painel Futuro v3.5
              </p>
            </div>
          </div>

          <button 
            onClick={() => setIsSidebarOpen(false)}
            className="lg:hidden p-1.5 text-slate-400 hover:text-white"
          >
            <XCircle className="w-6 h-6" />
          </button>
        </div>

        {/* MENU ITEMS */}
        <nav className="flex-1 p-4 space-y-2 overflow-y-auto no-scrollbar">
          {menuItems.map(item => (
            <button
              key={item.id}
              onClick={() => {
                soundService.playUISelect();
                setActiveTab(item.id);
                setIsSidebarOpen(false);
              }}
              className={`w-full flex items-center justify-between p-3.5 rounded-2xl transition-all cursor-pointer font-black uppercase text-xs tracking-wider group relative ${
                activeTab === item.id 
                  ? 'bg-gradient-to-r from-[#049444] to-emerald-600 text-white shadow-[0_0_25px_rgba(4,148,68,0.4)] border border-emerald-400/30' 
                  : 'text-slate-400 hover:bg-white/5 hover:text-white border border-transparent'
              }`}
            >
              <div className="flex items-center gap-3">
                <div className="shrink-0 group-hover:scale-110 transition-transform">
                  {item.icon}
                </div>
                <span>{item.label}</span>
              </div>

              {item.id === 'FINANCE' && pendingCount > 0 && (
                <span className="bg-amber-500 text-black text-[9px] font-extrabold px-2 py-0.5 rounded-full animate-bounce">
                  {pendingCount}
                </span>
              )}
            </button>
          ))}
        </nav>

        {/* EXIT BUTTON */}
        <div className="p-4 border-t border-white/10 bg-black/40">
          <button 
            onClick={() => {
              soundService.playUISelect();
              onBack();
            }} 
            className="w-full py-3.5 bg-red-500/10 hover:bg-red-500/20 border border-red-500/30 rounded-2xl text-red-400 font-black uppercase text-xs tracking-widest transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <LogOut className="w-4 h-4" />
            <span>Sair do Painel</span>
          </button>
        </div>
      </aside>

      {/* MAIN CONTENT WORKSPACE */}
      <main className="flex-1 flex flex-col min-w-0 h-full overflow-hidden">
        
        {/* HEADER BAR */}
        <header className="h-16 lg:h-20 bg-[#090e17]/80 backdrop-blur-xl border-b border-white/10 flex items-center justify-between px-4 lg:px-8 shrink-0">
          <div className="flex items-center gap-3">
            <button 
              className="lg:hidden p-2 text-slate-300 hover:text-white bg-white/5 rounded-xl border border-white/10 cursor-pointer"
              onClick={() => setIsSidebarOpen(true)}
            >
              <Sliders className="w-5 h-5" />
            </button>
            <div>
              <h2 className="text-sm lg:text-base font-black uppercase tracking-wider text-white flex items-center gap-2">
                <span>{menuItems.find(i => i.id === activeTab)?.label}</span>
              </h2>
              <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest hidden sm:block">
                Controlo em Tempo Real • Servidor Angola Cloud
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={loadData}
              disabled={isLoading}
              className="p-2.5 bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl text-slate-300 hover:text-white transition-all cursor-pointer flex items-center gap-2 text-xs font-bold"
              title="Atualizar Dados"
            >
              <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin text-emerald-400' : ''}`} />
              <span className="hidden sm:inline">Sincronizar</span>
            </button>

            <div className="px-3 py-1.5 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-[10px] font-black uppercase tracking-wider flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
              <span>SISTEMA ATIVO</span>
            </div>
          </div>
        </header>

        {/* WORKSPACE BODY SCROLL AREA */}
        <div className="flex-1 overflow-y-auto p-4 lg:p-8 space-y-6 no-scrollbar pb-24 lg:pb-12">
          
          {/* TAB 1: TELEMETRY DASHBOARD */}
          {activeTab === 'DASHBOARD' && (
            <div className="space-y-6 animate-in fade-in duration-300">
              
              {/* TOP SUMMARY METRICS GRID */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                
                <div className="bg-[#0e1622] p-5 rounded-3xl border border-emerald-500/30 shadow-xl relative overflow-hidden group hover:border-emerald-400 transition-all">
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-[10px] font-black text-emerald-400 uppercase tracking-widest">
                      Volume Bruto Depósitos
                    </span>
                    <div className="w-9 h-9 rounded-2xl bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
                      <ArrowUpRight className="w-5 h-5" />
                    </div>
                  </div>
                  <div className="text-2xl lg:text-3xl font-black font-mono tracking-tight text-white">
                    {approvedDeposits.toLocaleString('pt-AO')} <span className="text-xs font-sans text-emerald-400">Kz</span>
                  </div>
                  <p className="text-[9px] text-slate-400 font-semibold mt-2">
                    Depósitos liquidados na plataforma
                  </p>
                </div>

                <div className="bg-[#0e1622] p-5 rounded-3xl border border-red-500/30 shadow-xl relative overflow-hidden group hover:border-red-400 transition-all">
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-[10px] font-black text-red-400 uppercase tracking-widest">
                      Total Levantamentos Pagos
                    </span>
                    <div className="w-9 h-9 rounded-2xl bg-red-500/20 border border-red-500/30 flex items-center justify-center text-red-400">
                      <ArrowDownLeft className="w-5 h-5" />
                    </div>
                  </div>
                  <div className="text-2xl lg:text-3xl font-black font-mono tracking-tight text-white">
                    {approvedWithdrawals.toLocaleString('pt-AO')} <span className="text-xs font-sans text-red-400">Kz</span>
                  </div>
                  <p className="text-[9px] text-slate-400 font-semibold mt-2">
                    Pagamentos efetuados aos jogadores
                  </p>
                </div>

                <div className="bg-[#0e1622] p-5 rounded-3xl border border-yellow-500/30 shadow-xl relative overflow-hidden group hover:border-yellow-400 transition-all">
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-[10px] font-black text-yellow-400 uppercase tracking-widest">
                      Lucro Líquido Retido
                    </span>
                    <div className="w-9 h-9 rounded-2xl bg-yellow-500/20 border border-yellow-500/30 flex items-center justify-center text-yellow-400">
                      <DollarSign className="w-5 h-5" />
                    </div>
                  </div>
                  <div className="text-2xl lg:text-3xl font-black font-mono tracking-tight text-[#FFCC00]">
                    {(approvedDeposits - approvedWithdrawals).toLocaleString('pt-AO')} <span className="text-xs font-sans text-yellow-400">Kz</span>
                  </div>
                  <p className="text-[9px] text-slate-400 font-semibold mt-2">
                    Margem líquida da casa de aposta
                  </p>
                </div>

                <div className="bg-[#0e1622] p-5 rounded-3xl border border-purple-500/30 shadow-xl relative overflow-hidden group hover:border-purple-400 transition-all">
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-[10px] font-black text-purple-400 uppercase tracking-widest">
                      Usuários Registrados
                    </span>
                    <div className="w-9 h-9 rounded-2xl bg-purple-500/20 border border-purple-500/30 flex items-center justify-center text-purple-400">
                      <Users className="w-5 h-5" />
                    </div>
                  </div>
                  <div className="text-2xl lg:text-3xl font-black font-mono tracking-tight text-white">
                    {totalUsersCount} <span className="text-xs font-sans text-purple-400">Pilotos</span>
                  </div>
                  <p className="text-[9px] text-slate-400 font-semibold mt-2">
                    {totalBannedCount} usuários atualmente banidos
                  </p>
                </div>

              </div>

              {/* ACTION COMMAND CENTER */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                
                {/* QUICK SYSTEM CONTROLS */}
                <div className="bg-[#090e17] p-6 rounded-3xl border border-white/10 shadow-xl space-y-4">
                  <h3 className="text-sm font-black uppercase text-white flex items-center gap-2 border-b border-white/10 pb-3">
                    <Zap className="w-4 h-4 text-yellow-400" />
                    <span>Ações Rápidas de Emergência</span>
                  </h3>

                  <div className="space-y-3">
                    <div className="p-4 bg-white/5 rounded-2xl border border-white/5 flex items-center justify-between">
                      <div>
                        <h4 className="font-extrabold text-xs text-white">Modo de Manutenção Geral</h4>
                        <p className="text-[10px] text-slate-400">Bloqueia acesso a usuários normais</p>
                      </div>
                      <button
                        onClick={() => saveSettings({ ...settings, maintenanceMode: !settings.maintenanceMode })}
                        className={`px-4 py-2 rounded-xl text-xs font-black uppercase transition-all cursor-pointer ${
                          settings.maintenanceMode 
                            ? 'bg-red-500 text-white shadow-lg shadow-red-500/30' 
                            : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                        }`}
                      >
                        {settings.maintenanceMode ? 'ATIVADO' : 'DESATIVADO'}
                      </button>
                    </div>

                    <div className="p-4 bg-white/5 rounded-2xl border border-white/5 flex items-center justify-between">
                      <div>
                        <h4 className="font-extrabold text-xs text-white">Modo Isca (Baiting Mode)</h4>
                        <p className="text-[10px] text-slate-400">Aumenta taxa de ganho no modo demo</p>
                      </div>
                      <button
                        onClick={() => saveSettings({ ...settings, baitingMode: !settings.baitingMode })}
                        className={`px-4 py-2 rounded-xl text-xs font-black uppercase transition-all cursor-pointer ${
                          settings.baitingMode 
                            ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-600/30' 
                            : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                        }`}
                      >
                        {settings.baitingMode ? 'ON' : 'OFF'}
                      </button>
                    </div>

                    <div className="p-4 bg-white/5 rounded-2xl border border-white/5 flex items-center justify-between">
                      <div>
                        <h4 className="font-extrabold text-xs text-white">Ganhadores Fictícios na Home</h4>
                        <p className="text-[10px] text-slate-400">Exibe ticker de vitórias em tempo real</p>
                      </div>
                      <button
                        onClick={() => saveSettings({ ...settings, fakeWinnersEnabled: !settings.fakeWinnersEnabled })}
                        className={`px-4 py-2 rounded-xl text-xs font-black uppercase transition-all cursor-pointer ${
                          settings.fakeWinnersEnabled 
                            ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-600/30' 
                            : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                        }`}
                      >
                        {settings.fakeWinnersEnabled ? 'ON' : 'OFF'}
                      </button>
                    </div>
                  </div>
                </div>

                {/* ANNOUNCEMENT MESSAGE BANNER EDIT */}
                <div className="bg-[#090e17] p-6 rounded-3xl border border-white/10 shadow-xl space-y-4">
                  <h3 className="text-sm font-black uppercase text-white flex items-center gap-2 border-b border-white/10 pb-3">
                    <Megaphone className="w-4 h-4 text-blue-400" />
                    <span>Mensagem de Anúncio Global</span>
                  </h3>

                  <div className="space-y-3">
                    <textarea
                      value={settings.globalNotification || ''}
                      onChange={(e) => setSettings({ ...settings, globalNotification: e.target.value })}
                      placeholder="Ex: Bónus de 100% no primeiro depósito deste fim de semana!"
                      className="w-full bg-black/40 border border-white/10 rounded-2xl p-4 text-xs text-white outline-none focus:border-[#049444] h-28 no-scrollbar resize-none font-medium"
                    />

                    <button
                      onClick={() => saveSettings(settings)}
                      className="w-full py-3 bg-gradient-to-r from-[#049444] to-emerald-600 hover:from-emerald-500 hover:to-emerald-600 text-white font-black text-xs uppercase tracking-wider rounded-xl shadow-lg transition-all cursor-pointer"
                    >
                      Publicar Anúncio no Topo da Plataforma
                    </button>
                  </div>
                </div>

              </div>

            </div>
          )}

          {/* TAB 2: USERS & PILOTS MANAGEMENT */}
          {activeTab === 'USERS' && (
            <div className="space-y-6 animate-in fade-in duration-300">
              
              {/* MODAL / FORM FOR CREDIT BALANCE */}
              {selectedUserForCredit && (
                <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-[200] flex items-center justify-center p-4">
                  <div className="bg-[#0f1724] border border-white/20 rounded-3xl p-6 w-full max-w-md shadow-2xl space-y-4">
                    <div className="flex items-center justify-between border-b border-white/10 pb-3">
                      <h3 className="font-black text-sm uppercase text-white flex items-center gap-2">
                        <Wallet className="w-4 h-4 text-emerald-400" />
                        <span>Ajustar Saldo: {selectedUserForCredit.name}</span>
                      </h3>
                      <button onClick={() => setSelectedUserForCredit(null)} className="text-slate-400 hover:text-white">
                        <XCircle className="w-5 h-5" />
                      </button>
                    </div>

                    <div className="space-y-3">
                      <div>
                        <label className="text-[10px] font-black text-slate-400 uppercase block mb-1">
                          Valor (Positivo para adicionar / Negativo para deduzir)
                        </label>
                        <input
                          type="number"
                          value={creditAmount}
                          onChange={(e) => setCreditAmount(e.target.value)}
                          placeholder="Ex: 5000 ou -2000"
                          className="w-full bg-black/50 border border-white/10 rounded-xl px-4 py-3 text-white font-mono text-sm outline-none focus:border-emerald-500"
                        />
                      </div>

                      <div>
                        <label className="text-[10px] font-black text-slate-400 uppercase block mb-1">
                          Motivo / Descrição
                        </label>
                        <input
                          type="text"
                          value={creditReason}
                          onChange={(e) => setCreditReason(e.target.value)}
                          placeholder="Ex: Reembolso de aposta / Bónus VIP"
                          className="w-full bg-black/50 border border-white/10 rounded-xl px-4 py-3 text-white text-xs outline-none focus:border-emerald-500"
                        />
                      </div>

                      <div className="flex gap-2 pt-2">
                        <button
                          onClick={() => setSelectedUserForCredit(null)}
                          className="flex-1 py-3 bg-white/5 hover:bg-white/10 rounded-xl text-xs font-bold text-slate-300"
                        >
                          Cancelar
                        </button>
                        <button
                          onClick={handleManualCredit}
                          className="flex-1 py-3 bg-emerald-600 hover:bg-emerald-500 rounded-xl text-xs font-black text-white uppercase tracking-wider shadow-lg"
                        >
                          Confirmar Crédito
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* SEARCH & FILTER BAR */}
              <div className="bg-[#090e17] p-4 lg:p-6 rounded-3xl border border-white/10 flex flex-col md:flex-row items-center justify-between gap-4">
                <div className="relative w-full md:w-96">
                  <Search className="w-4 h-4 absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input
                    type="text"
                    value={searchUser}
                    onChange={(e) => setSearchUser(e.target.value)}
                    placeholder="Pesquisar por Nome, E-mail ou ID..."
                    className="w-full bg-black/40 border border-white/10 rounded-2xl pl-11 pr-4 py-2.5 text-xs font-semibold text-white outline-none focus:border-[#049444]"
                  />
                </div>

                <div className="text-xs text-slate-400 font-bold uppercase tracking-wider">
                  Total Registrados: <span className="text-emerald-400 font-black">{users.length}</span>
                </div>
              </div>

              {/* USERS TABLE */}
              <div className="bg-[#090e17] rounded-3xl border border-white/10 overflow-hidden shadow-2xl">
                <div className="overflow-x-auto no-scrollbar">
                  <table className="w-full text-left border-collapse min-w-[700px]">
                    <thead>
                      <tr className="bg-black/50 border-b border-white/10 text-[9px] font-black uppercase tracking-widest text-slate-400">
                        <th className="p-4">Status & ID</th>
                        <th className="p-4">Nome & Contato</th>
                        <th className="p-4">Papel / Função</th>
                        <th className="p-4">Saldo em Kwanza (Kz)</th>
                        <th className="p-4 text-right">Ações de Controlo</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-white/5 text-xs">
                      {users
                        .filter(u => 
                          !searchUser || 
                          u.name.toLowerCase().includes(searchUser.toLowerCase()) || 
                          u.email.toLowerCase().includes(searchUser.toLowerCase()) ||
                          u.id.toLowerCase().includes(searchUser.toLowerCase())
                        )
                        .map(u => (
                          <tr key={u.id} className="hover:bg-white/5 transition-colors">
                            <td className="p-4">
                              <div className="flex items-center gap-2">
                                <span className={`w-2.5 h-2.5 rounded-full ${u.isBanned ? 'bg-red-500 shadow-[0_0_10px_#ef4444]' : 'bg-emerald-500 shadow-[0_0_10px_#10b981]'}`} />
                                <span className="font-mono text-[10px] text-slate-400">#{u.id.substring(0, 8)}</span>
                              </div>
                            </td>

                            <td className="p-4">
                              <div className="font-bold text-white text-xs">{u.name}</div>
                              <div className="text-[10px] text-slate-400 font-mono">{u.email}</div>
                              {u.phone && <div className="text-[9px] text-emerald-400 font-mono">{u.phone}</div>}
                            </td>

                            <td className="p-4">
                              <button
                                onClick={() => handleToggleRole(u)}
                                className={`px-2.5 py-1 rounded-lg text-[9px] font-black uppercase tracking-wider border cursor-pointer ${
                                  u.role === 'ADMIN'
                                    ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                                    : 'bg-slate-800 text-slate-400 border-white/10 hover:text-white'
                                }`}
                              >
                                {u.role === 'ADMIN' ? '👑 ADMIN' : '👤 JOGADOR'}
                              </button>
                            </td>

                            <td className="p-4 font-mono font-black text-emerald-400 text-sm">
                              {u.balance.toLocaleString('pt-AO')} Kz
                            </td>

                            <td className="p-4 text-right">
                              <div className="flex items-center justify-end gap-2">
                                <button
                                  onClick={() => setSelectedUserForCredit(u)}
                                  className="px-3 py-1.5 bg-emerald-500/20 text-emerald-300 hover:bg-emerald-500 hover:text-white border border-emerald-500/30 rounded-xl text-[10px] font-black uppercase transition-all cursor-pointer"
                                >
                                  + Crédito
                                </button>

                                <button
                                  onClick={() => handleToggleBanUser(u)}
                                  className={`px-3 py-1.5 rounded-xl text-[10px] font-black uppercase border transition-all cursor-pointer ${
                                    u.isBanned
                                      ? 'bg-emerald-600 text-white border-emerald-400'
                                      : 'bg-red-500/20 text-red-400 hover:bg-red-500 hover:text-white border-red-500/30'
                                  }`}
                                >
                                  {u.isBanned ? 'Desbanir' : 'Banir'}
                                </button>
                              </div>
                            </td>
                          </tr>
                        ))}
                    </tbody>
                  </table>
                </div>
              </div>

            </div>
          )}

          {/* TAB 3: FINANCIAL & TRANSACTIONS APPROVAL */}
          {activeTab === 'FINANCE' && (
            <div className="space-y-6 animate-in fade-in duration-300">
              
              <div className="bg-[#090e17] p-6 rounded-3xl border border-white/10 flex items-center justify-between">
                <div>
                  <h3 className="font-black text-sm uppercase text-white flex items-center gap-2">
                    <Wallet className="w-5 h-5 text-amber-400" />
                    <span>Fila de Pedidos de Depósito & Levantamento</span>
                  </h3>
                  <p className="text-[10px] text-slate-400 font-semibold mt-0.5">
                    Aprovação imediata credita ou deduz o saldo no perfil do jogador
                  </p>
                </div>

                <div className="bg-amber-500/20 text-amber-300 border border-amber-500/30 font-black px-3.5 py-1.5 rounded-xl text-xs uppercase">
                  {transactions.filter(t => t.status === 'PENDING').length} Pendentes
                </div>
              </div>

              {/* TRANSACTIONS LIST */}
              <div className="space-y-3">
                {transactions.length === 0 ? (
                  <div className="py-16 text-center text-slate-500 font-bold text-xs uppercase tracking-widest bg-[#090e17] rounded-3xl border border-white/10">
                    Nenhuma transação registada até ao momento.
                  </div>
                ) : (
                  transactions.map(t => (
                    <div
                      key={t.id}
                      className={`p-5 rounded-3xl border transition-all flex flex-col md:flex-row items-center justify-between gap-4 ${
                        t.status === 'PENDING'
                          ? 'bg-[#0f1724] border-amber-500/40 shadow-[0_0_20px_rgba(245,158,11,0.15)]'
                          : t.status === 'APPROVED'
                          ? 'bg-[#090e17] border-emerald-500/20 opacity-80'
                          : 'bg-[#090e17] border-red-500/20 opacity-60'
                      }`}
                    >
                      <div className="flex items-center gap-4 w-full md:w-auto">
                        <div className={`w-12 h-12 rounded-2xl flex items-center justify-center text-xl shrink-0 font-bold ${
                          t.type === 'DEPOSIT' ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' : 'bg-red-500/20 text-red-400 border border-red-500/30'
                        }`}>
                          {t.type === 'DEPOSIT' ? '📥' : '📤'}
                        </div>

                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-extrabold text-sm text-white">{t.userName}</span>
                            <span className={`text-[9px] font-black px-2 py-0.5 rounded uppercase ${
                              t.type === 'DEPOSIT' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-red-500/20 text-red-400'
                            }`}>
                              {t.type}
                            </span>
                          </div>
                          <p className="text-[10px] text-slate-400 font-medium">
                            {t.method} • <span className="font-mono">{t.timestamp}</span>
                          </p>
                          {t.accountDetails && (
                            <p className="text-[9px] text-amber-300 font-mono mt-0.5">
                              Dados: {t.accountDetails}
                            </p>
                          )}
                        </div>
                      </div>

                      <div className="flex items-center justify-between md:justify-end gap-6 w-full md:w-auto">
                        <div className="text-right">
                          <span className="text-[9px] text-slate-400 uppercase font-black block">Valor Kz</span>
                          <span className="text-xl font-mono font-black text-white">
                            {t.amount.toLocaleString('pt-AO')} Kz
                          </span>
                        </div>

                        {t.status === 'PENDING' ? (
                          <div className="flex items-center gap-2">
                            <button
                              onClick={() => handleResolveTransaction(t.id, 'REJECTED')}
                              className="px-4 py-2 bg-red-500/20 hover:bg-red-500 text-red-300 hover:text-white border border-red-500/30 rounded-xl text-xs font-black uppercase transition-all cursor-pointer"
                            >
                              Rejeitar
                            </button>
                            <button
                              onClick={() => handleResolveTransaction(t.id, 'APPROVED')}
                              className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-black uppercase tracking-wider shadow-lg shadow-emerald-600/30 transition-all cursor-pointer"
                            >
                              Aprovar
                            </button>
                          </div>
                        ) : (
                          <span className={`px-3 py-1 rounded-xl text-[10px] font-black uppercase border ${
                            t.status === 'APPROVED' ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30' : 'bg-red-500/20 text-red-400 border-red-500/30'
                          }`}>
                            {t.status === 'APPROVED' ? '✓ APROVADO' : '✕ REJEITADO'}
                          </span>
                        )}
                      </div>
                    </div>
                  ))
                )}
              </div>

            </div>
          )}

          {/* TAB 4: PAYMENT METHODS & BANKING CONFIG */}
          {activeTab === 'PAYMENTS' && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 animate-in fade-in duration-300">
              
              {/* EDIT / CREATE METHOD FORM */}
              <div className="lg:col-span-5 bg-[#090e17] p-6 rounded-3xl border border-white/10 space-y-4">
                <h3 className="font-black text-sm uppercase text-white flex items-center gap-2 border-b border-white/10 pb-3">
                  <CreditCard className="w-4 h-4 text-purple-400" />
                  <span>Configurar Método de Pagamento</span>
                </h3>

                <div className="space-y-3 text-xs">
                  <div>
                    <label className="text-[10px] font-black text-slate-400 uppercase block mb-1">
                      Nome do Canal / Banco
                    </label>
                    <input
                      type="text"
                      value={editingMethod?.name || ''}
                      onChange={(e) => setEditingMethod({ ...editingMethod, name: e.target.value })}
                      placeholder="Ex: Multicaixa Express / Banco BAI"
                      className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-2.5 text-white outline-none focus:border-purple-500"
                    />
                  </div>

                  <div>
                    <label className="text-[10px] font-black text-slate-400 uppercase block mb-1">
                      Tipo de Canal
                    </label>
                    <select
                      value={editingMethod?.type || 'MOBILE_MONEY'}
                      onChange={(e) => setEditingMethod({ ...editingMethod, type: e.target.value as any })}
                      className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-2.5 text-white outline-none focus:border-purple-500 cursor-pointer"
                    >
                      <option value="MOBILE_MONEY">Mobile Money (Express / Unitel Money)</option>
                      <option value="BANK">Transferência Bancária (IBAN / BAI / BFA)</option>
                      <option value="CRYPTO">Criptomoeda (USDT TRC20 / BTC)</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-[10px] font-black text-slate-400 uppercase block mb-1">
                      Número de Telefone / IBAN / Wallet
                    </label>
                    <input
                      type="text"
                      value={editingMethod?.account || ''}
                      onChange={(e) => setEditingMethod({ ...editingMethod, account: e.target.value })}
                      placeholder="Ex: AO06 0040 0000 1234 5678 1015 4"
                      className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-2.5 text-white font-mono text-xs outline-none focus:border-purple-500"
                    />
                  </div>

                  <div>
                    <label className="text-[10px] font-black text-slate-400 uppercase block mb-1">
                      Instruções Adicionais
                    </label>
                    <input
                      type="text"
                      value={editingMethod?.details || ''}
                      onChange={(e) => setEditingMethod({ ...editingMethod, details: e.target.value })}
                      placeholder="Ex: Titular: CryptonBet Lda • Enviar talão"
                      className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-2.5 text-white text-xs outline-none focus:border-purple-500"
                    />
                  </div>

                  <button
                    onClick={handleSavePaymentMethod}
                    className="w-full py-3 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-black text-xs uppercase tracking-wider rounded-xl shadow-lg transition-all cursor-pointer mt-2"
                  >
                    Guardar Canal de Pagamento
                  </button>
                </div>
              </div>

              {/* ACTIVE METHODS LIST */}
              <div className="lg:col-span-7 bg-[#090e17] p-6 rounded-3xl border border-white/10 space-y-4">
                <h3 className="font-black text-sm uppercase text-white border-b border-white/10 pb-3">
                  Canais de Depósito Ativos
                </h3>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {settings.paymentMethods.map(m => (
                    <div key={m.id} className="p-4 bg-black/40 border border-white/10 rounded-2xl flex flex-col justify-between space-y-3">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-extrabold text-xs text-white">{m.name}</span>
                          <span className="text-[8px] bg-purple-500/20 text-purple-300 font-black px-1.5 py-0.2 rounded uppercase">
                            {m.type}
                          </span>
                        </div>
                        <p className="text-[10px] text-amber-300 font-mono mt-1 font-bold">
                          {m.account}
                        </p>
                        {m.details && (
                          <p className="text-[9px] text-slate-400 mt-1">
                            {m.details}
                          </p>
                        )}
                      </div>

                      <div className="flex gap-2">
                        <button
                          onClick={() => setEditingMethod(m)}
                          className="flex-1 py-1.5 bg-white/5 hover:bg-white/10 text-slate-300 rounded-lg text-[10px] font-bold uppercase transition-all"
                        >
                          Editar
                        </button>
                        <button
                          onClick={() => {
                            const filtered = settings.paymentMethods.filter(item => item.id !== m.id);
                            saveSettings({ ...settings, paymentMethods: filtered });
                          }}
                          className="p-1.5 bg-red-500/20 hover:bg-red-500 text-red-300 hover:text-white rounded-lg transition-all"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

            </div>
          )}

          {/* TAB 5: ENGINE & KERNEL SETTINGS (RTP & HOUSE ADVANTAGE) */}
          {activeTab === 'ENGINE' && (
            <div className="max-w-3xl mx-auto space-y-6 animate-in fade-in duration-300">
              
              <div className="bg-[#090e17] p-6 rounded-3xl border border-white/10 space-y-6">
                <h3 className="font-black text-sm uppercase text-white flex items-center gap-2 border-b border-white/10 pb-3">
                  <Cpu className="w-5 h-5 text-red-400" />
                  <span>Configuração de RTP e Algoritmo de Cassino</span>
                </h3>

                <div className="space-y-6">
                  
                  {/* RTP SLIDER */}
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="font-extrabold text-xs text-white">RTP Global (Return to Player)</span>
                      <span className="font-mono font-black text-emerald-400 text-lg">{settings.globalRtp}%</span>
                    </div>
                    <input
                      type="range"
                      min="30"
                      max="99"
                      value={settings.globalRtp}
                      onChange={(e) => setSettings({ ...settings, globalRtp: Number(e.target.value) })}
                      className="w-full accent-emerald-500 cursor-pointer"
                    />
                    <p className="text-[10px] text-slate-400">
                      Determina a percentagem média de retorno em jogos como Aviator, Minas, Slots e Roleta.
                    </p>
                  </div>

                  {/* HOUSE ADVANTAGE LEVEL */}
                  <div className="space-y-2">
                    <span className="font-extrabold text-xs text-white block">Nível de Agressividade da Casa</span>
                    <div className="grid grid-cols-3 gap-2">
                      {(['LOW', 'MEDIUM', 'EXTREME'] as const).map((level) => (
                        <button
                          key={level}
                          onClick={() => setSettings({ ...settings, houseAdvantageLevel: level })}
                          className={`py-2.5 rounded-xl text-xs font-black uppercase tracking-wider border transition-all cursor-pointer ${
                            settings.houseAdvantageLevel === level
                              ? 'bg-red-600 text-white border-red-400 shadow-lg shadow-red-600/30'
                              : 'bg-white/5 border-white/10 text-slate-400 hover:text-white'
                          }`}
                        >
                          {level === 'LOW' ? 'Baixo (Fácil)' : level === 'MEDIUM' ? 'Médio (Normal)' : 'Extremo (Hard)'}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* FORCED AVIATOR MULTIPLIER */}
                  <div className="space-y-2">
                    <label className="font-extrabold text-xs text-white block">
                      Multiplicador Forçado no Aviator (Opcional)
                    </label>
                    <input
                      type="number"
                      step="0.01"
                      value={settings.forcedAviatorMultiplier || ''}
                      onChange={(e) => setSettings({
                        ...settings,
                        forcedAviatorMultiplier: e.target.value ? Number(e.target.value) : null
                      })}
                      placeholder="Ex: 100.0 (Deixe em branco para aleatório)"
                      className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-2.5 text-xs text-white font-mono outline-none focus:border-red-500"
                    />
                  </div>

                  <button
                    onClick={() => saveSettings(settings)}
                    className="w-full py-3.5 bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-500 hover:to-rose-500 text-white font-black text-xs uppercase tracking-wider rounded-xl shadow-xl transition-all cursor-pointer"
                  >
                    Salvar Parâmetros do Kernel
                  </button>

                </div>
              </div>

            </div>
          )}

        </div>
      </main>
    </div>
  );
};

export default AdminView;
