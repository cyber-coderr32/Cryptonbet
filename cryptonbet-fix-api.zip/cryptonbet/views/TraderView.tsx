import React, { useState, useEffect, useRef } from 'react';
import { soundService } from '../services/soundService';
import { userService } from '../services/userService';
import { plisioService } from '../services/plisioService';
import { 
  TrendingUp, 
  TrendingDown, 
  Clock, 
  ArrowLeft, 
  Timer, 
  ChevronDown, 
  Coins, 
  Flame, 
  CheckCircle2, 
  XCircle, 
  HelpCircle,
  HelpCircle as HelpIcon,
  BadgeAlert,
  Trash2,
  Sparkles,
  History,
  Info,
  Sliders,
  Settings
} from 'lucide-react';

interface TraderViewProps {
  balance: number;
  isDemo?: boolean;
  onUpdateBalance: (amount: number) => void;
  onBack: () => void;
}

interface Asset {
  id: string;
  name: string;
  symbol: string;
  price: number;
  payout: number; // e.g. 0.85 (85% profit)
  volatility: number;
  drift: number; // general upward/downward trend
}

interface Trade {
  id: string;
  assetId: string;
  assetName: string;
  direction: 'CALL' | 'PUT';
  entryPrice: number;
  amount: number;
  payoutRate: number;
  createdAt: number; // timestamp ms
  expiryAt: number; // timestamp ms
}

interface TradeHistory {
  id: string;
  assetName: string;
  direction: 'CALL' | 'PUT';
  entryPrice: number;
  exitPrice: number;
  amount: number;
  payout: number; // 0 for loss, amount * (1 + payoutRate) for win
  isWin: boolean;
  timestamp: number;
}

interface Candle {
  time: number;
  open: number;
  high: number;
  low: number;
  close: number;
}

const computeCandles = (ticks: { time: number; price: number }[], intervalSeconds: number): Candle[] => {
  if (ticks.length === 0) return [];
  const intervalMs = intervalSeconds * 1000;
  const bins: { [key: number]: number[] } = {};
  
  ticks.forEach(t => {
    const binTime = Math.floor(t.time / intervalMs) * intervalMs;
    if (!bins[binTime]) {
      bins[binTime] = [];
    }
    bins[binTime].push(t.price);
  });
  
  const sortedKeys = Object.keys(bins).map(Number).sort((a, b) => a - b);
  return sortedKeys.map(time => {
    const prices = bins[time];
    const open = prices[0];
    const close = prices[prices.length - 1];
    const high = Math.max(...prices);
    const low = Math.min(...prices);
    return { time, open, high, low, close };
  });
};

const calculateRSIValues = (ticks: { time: number; price: number }[], period: number = 14): number[] => {
  const rsiValues: number[] = Array(ticks.length).fill(50);
  if (ticks.length < period) return rsiValues;
  
  let gains = 0;
  let losses = 0;
  
  // First period
  for (let i = 1; i <= period; i++) {
    const diff = ticks[i].price - ticks[i - 1].price;
    if (diff > 0) gains += diff;
    else losses -= diff;
  }
  
  let avgGain = gains / period;
  let avgLoss = losses / period;
  rsiValues[period] = avgLoss === 0 ? 100 : 100 - (100 / (1 + avgGain / avgLoss));
  
  for (let i = period + 1; i < ticks.length; i++) {
    const diff = ticks[i].price - ticks[i - 1].price;
    const gain = diff > 0 ? diff : 0;
    const loss = diff < 0 ? -diff : 0;
    
    avgGain = (avgGain * (period - 1) + gain) / period;
    avgLoss = (avgLoss * (period - 1) + loss) / period;
    
    rsiValues[i] = avgLoss === 0 ? 100 : 100 - (100 / (1 + avgGain / avgLoss));
  }
  return rsiValues;
};

const ASSETS: Asset[] = [
  { id: 'BTC_USDT', name: 'BTC / USDT (Bitcoin)', symbol: '₿ BTC/USDT', price: 67450.00, payout: 0.90, volatility: 25.0, drift: 0.1 },
  { id: 'ETH_USDT', name: 'ETH / USDT (Ethereum)', symbol: 'Ξ ETH/USDT', price: 3480.00, payout: 0.88, volatility: 2.5, drift: 0.05 },
  { id: 'SOL_USDT', name: 'SOL / USDT (Solana)', symbol: '☀️ SOL/USDT', price: 178.20, payout: 0.87, volatility: 0.35, drift: 0.01 },
  { id: 'BNB_USDT', name: 'BNB / USDT (Binance)', symbol: '🟡 BNB/USDT', price: 585.00, payout: 0.85, volatility: 0.5, drift: 0.02 },
  { id: 'TRX_USDT', name: 'TRX / USDT (Tron)', symbol: '🔴 TRX/USDT', price: 0.136, payout: 0.83, volatility: 0.0008, drift: 0.00001 },
  { id: 'DOGE_USDT', name: 'DOGE / USDT (Dogecoin)', symbol: '🐶 DOGE/USDT', price: 0.128, payout: 0.82, volatility: 0.001, drift: 0.00002 },
  { id: 'EUR_USD', name: 'EUR / USD (Forex)', symbol: '💶 EUR/USD', price: 1.0854, payout: 0.85, volatility: 0.0004, drift: -0.00001 },
  { id: 'GBP_USD', name: 'GBP / USD (Forex)', symbol: '💷 GBP/USD', price: 1.2950, payout: 0.84, volatility: 0.0005, drift: 0.00001 }
];

const TIMEFRAMES = [
  { label: '30 seg', value: 30 },
  { label: '1 min', value: 60 },
  { label: '2 min', value: 120 },
  { label: '5 min', value: 300 },
];

const PRESET_BETS = [50, 100, 200, 500, 1000];

const TraderView: React.FC<TraderViewProps> = ({ balance, isDemo, onUpdateBalance, onBack }) => {
  const [selectedAsset, setSelectedAsset] = useState<Asset>(ASSETS[0]);
  const [assetPrices, setAssetPrices] = useState<{ [key: string]: number }>(
    ASSETS.reduce((acc, curr) => ({ ...acc, [curr.id]: curr.price }), {})
  );
  
  const [betAmount, setBetAmount] = useState<number>(100);
  const [selectedTimeframe, setSelectedTimeframe] = useState<number>(30); // in seconds
  const [activeTrades, setActiveTrades] = useState<Trade[]>([]);
  const [history, setHistory] = useState<TradeHistory[]>([]);
  const [activeLeftTab, setActiveLeftTab] = useState<'trades' | 'assets' | 'tools' | 'tutorial' | 'config' | null>(null);
  
  // Modal/Dropdowns
  const [showAssetSelector, setShowAssetSelector] = useState(false);
  const [showTutorial, setShowTutorial] = useState(false);

  // Technical Analysis & Advanced UI Controls
  const [chartType, setChartType] = useState<'LINE' | 'CANDLE'>('CANDLE');
  const [candleInterval, setCandleInterval] = useState<number>(5); // 5s, 10s, 15s, 30s
  const [showSMA7, setShowSMA7] = useState<boolean>(true);
  const [showSMA14, setShowSMA14] = useState<boolean>(false);
  const [showBB, setShowBB] = useState<boolean>(true);
  const [showRSI, setShowRSI] = useState<boolean>(true);
  const [isLineToolActive, setIsLineToolActive] = useState<boolean>(false);
  const [drawnLines, setDrawnLines] = useState<number[]>([]);

  // Chart References
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const priceHistoryRef = useRef<{ [key: string]: { time: number; price: number }[] }>({});
  const animationFrameId = useRef<number | null>(null);

  // Keep track of latest prices in ref to avoid closure issues in canvas animation
  const latestPricesRef = useRef<{ [key: string]: number }>({});
  latestPricesRef.current = assetPrices;

  const activeTradesRef = useRef<Trade[]>([]);
  activeTradesRef.current = activeTrades;

  // Refs for dynamic calculations in canvas drawing / clicking
  const mouseCoordsRef = useRef<{ x: number; y: number } | null>(null);
  const minPriceRef = useRef<number>(0);
  const maxPriceRef = useRef<number>(1);

  // Initialize price history & sync with Plisio API
  useEffect(() => {
    let isMounted = true;

    const syncPlisioRates = async () => {
      try {
        const rates = await plisioService.getCurrenciesRates('USD');
        if (!isMounted) return;

        setAssetPrices(prev => {
          const next = { ...prev };
          ASSETS.forEach(asset => {
            const coin = asset.id.split('_')[0];
            if (rates[coin] && rates[coin] > 0) {
              const livePrice = rates[coin];
              asset.price = livePrice;
              // If price is far off, anchor it to live price
              if (Math.abs(next[asset.id] - livePrice) / livePrice > 0.05) {
                next[asset.id] = livePrice;
              }
            }
          });
          return next;
        });
      } catch (e) {
        console.warn('Plisio rate fetch error:', e);
      }
    };

    syncPlisioRates();
    const plisioInterval = setInterval(syncPlisioRates, 8000);

    const now = Date.now();
    ASSETS.forEach(asset => {
      const historyArr: { time: number; price: number }[] = [];
      let tempPrice = asset.price;
      for (let i = 60; i >= 0; i--) {
        const change = (Math.random() - 0.5) * asset.volatility + asset.drift;
        tempPrice = Math.max(0.0001, tempPrice + change);
        historyArr.push({
          time: now - i * 1000,
          price: tempPrice
        });
      }
      priceHistoryRef.current[asset.id] = historyArr;
    });

    // Start simulation interval
    const priceInterval = setInterval(() => {
      setAssetPrices(prev => {
        const nextPrices = { ...prev };
        ASSETS.forEach(asset => {
          const currentPrice = prev[asset.id];
          
          // Realistic Brownian motion anchored to Plisio live price
          const rand = Math.random() - 0.5;
          const trendWeight = 0.05; // 5% weight on standard drift
          const meanReversion = (asset.price - currentPrice) * 0.003; // gently pull back to live Plisio price if it drifts
          
          const change = (rand * asset.volatility) + (asset.drift * trendWeight) + meanReversion;
          const nextPrice = Math.max(0.0001, currentPrice + change);
          nextPrices[asset.id] = nextPrice;

          // Push to history
          if (!priceHistoryRef.current[asset.id]) {
            priceHistoryRef.current[asset.id] = [];
          }
          priceHistoryRef.current[asset.id].push({
            time: Date.now(),
            price: nextPrice
          });
          // Limit to last 300 points
          if (priceHistoryRef.current[asset.id].length > 300) {
            priceHistoryRef.current[asset.id].shift();
          }
        });
        return nextPrices;
      });
    }, 300);

    return () => {
      isMounted = false;
      clearInterval(plisioInterval);
      clearInterval(priceInterval);
    };
  }, []);

  // Sync candleInterval automatically when selectedTimeframe changes to provide optimal proportions
  useEffect(() => {
    if (selectedTimeframe === 30) {
      setCandleInterval(5);
    } else if (selectedTimeframe === 60) {
      setCandleInterval(10);
    } else if (selectedTimeframe === 120) {
      setCandleInterval(15);
    } else if (selectedTimeframe === 300) {
      setCandleInterval(30);
    }
  }, [selectedTimeframe]);

  // Sync selected asset reference
  const currentAssetPrice = assetPrices[selectedAsset.id] || selectedAsset.price;

  // Real-time canvas drawing
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let width = canvas.width;
    let height = canvas.height;

    // Handle high DPI screens
    const resizeCanvas = () => {
      const rect = canvas.getBoundingClientRect();
      canvas.width = rect.width * window.devicePixelRatio;
      canvas.height = rect.height * window.devicePixelRatio;
      width = canvas.width;
      height = canvas.height;
      ctx.scale(window.devicePixelRatio, window.devicePixelRatio);
    };

    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);

    const render = () => {
      const w = width / window.devicePixelRatio;
      const h = height / window.devicePixelRatio;

      // Clear Canvas
      ctx.clearRect(0, 0, w, h);

      // Dark background gradient
      const bgGrad = ctx.createLinearGradient(0, 0, 0, h);
      bgGrad.addColorStop(0, '#090d16');
      bgGrad.addColorStop(1, '#05070a');
      ctx.fillStyle = bgGrad;
      ctx.fillRect(0, 0, w, h);

      const historyData = priceHistoryRef.current[selectedAsset.id] || [];
      if (historyData.length === 0) {
        animationFrameId.current = requestAnimationFrame(render);
        return;
      }

      // Calculate indicators lists for the historyData
      const sma7List: (number | null)[] = [];
      const sma14List: (number | null)[] = [];
      const bbList: ({ upper: number; middle: number; lower: number } | null)[] = [];

      for (let i = 0; i < historyData.length; i++) {
        // SMA 7
        if (i >= 6) {
          let sum = 0;
          for (let j = 0; j < 7; j++) sum += historyData[i - j].price;
          sma7List.push(sum / 7);
        } else {
          sma7List.push(null);
        }

        // SMA 14
        if (i >= 13) {
          let sum = 0;
          for (let j = 0; j < 14; j++) sum += historyData[i - j].price;
          sma14List.push(sum / 14);
        } else {
          sma14List.push(null);
        }

        // Bollinger Bands (20, 2)
        if (i >= 19) {
          let sum20 = 0;
          for (let j = 0; j < 20; j++) sum20 += historyData[i - j].price;
          const middle = sum20 / 20;

          let varSum = 0;
          for (let j = 0; j < 20; j++) {
            const diff = historyData[i - j].price - middle;
            varSum += diff * diff;
          }
          const stdDev = Math.sqrt(varSum / 20);
          bbList.push({
            middle,
            upper: middle + 2 * stdDev,
            lower: middle - 2 * stdDev
          });
        } else {
          bbList.push(null);
        }
      }

      // Find min and max price for scaling
      const prices = historyData.map(d => d.price);
      let minPrice = Math.min(...prices);
      let maxPrice = Math.max(...prices);

      // Include custom drawn lines in calculation to keep them framed
      drawnLines.forEach(linePrice => {
        minPrice = Math.min(minPrice, linePrice);
        maxPrice = Math.max(maxPrice, linePrice);
      });

      let priceDiff = maxPrice - minPrice;
      // Dynamic minimum allowed vertical window based directly on the currency's own volatility
      const minAllowedDiff = selectedAsset.volatility * 1.5;
      if (priceDiff < minAllowedDiff) {
        const centerPrice = (maxPrice + minPrice) / 2;
        minPrice = centerPrice - minAllowedDiff / 2;
        maxPrice = centerPrice + minAllowedDiff / 2;
        priceDiff = maxPrice - minPrice;
      }
      
      // 15% breathing room at the top and bottom so price lines / candles are always beautiful and visible
      const padding = priceDiff * 0.15;

      minPrice -= padding;
      maxPrice += padding;

      minPriceRef.current = minPrice;
      maxPriceRef.current = maxPrice;

      // Dynamic heights depending on RSI panel state
      const rsiPanelHeight = showRSI ? 60 : 0;
      const chartBottom = h - 40 - rsiPanelHeight;
      const chartHeight = chartBottom - 40;

      // Draw horizontal grid lines
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.03)';
      ctx.lineWidth = 1;
      const gridLinesCount = 5;
      for (let i = 0; i <= gridLinesCount; i++) {
        const gridY = 40 + chartHeight * (i / gridLinesCount);
        const gridPrice = maxPrice - (maxPrice - minPrice) * (i / gridLinesCount);
        ctx.beginPath();
        ctx.moveTo(0, gridY);
        ctx.lineTo(w - 70, gridY);
        ctx.stroke();

        // Draw price text in gutter
        ctx.fillStyle = 'rgba(255, 255, 255, 0.35)';
        ctx.font = '9px monospace';
        ctx.textAlign = 'right';
        ctx.fillText(gridPrice.toFixed(selectedAsset.price < 5 ? 4 : 2), w - 5, gridY + 3);
      }

      // X scale mapped to latest time with a future offset space on the right of the screen
      // This leaves an unobstructed view for the birth of new candles, preventing any overlay overlaps.
      const latestTime = historyData[historyData.length - 1].time;
      const timeWindow = 45 * 1000; // 45 seconds shown on chart
      const futureOffset = 18 * 1000; // 18 seconds of blank future space on the right of the screen
      const startTime = latestTime - (timeWindow - futureOffset);

      const getX = (time: number) => {
        return ((time - startTime) / timeWindow) * (w - 80);
      };

      const getY = (price: number) => {
        const ratio = (price - minPrice) / (maxPrice - minPrice);
        return chartBottom - ratio * chartHeight;
      };

      // Draw Bollinger Bands (underneath candlesticks/price lines)
      if (showBB) {
        // Fill channel between upper and lower band
        ctx.beginPath();
        let firstBB = true;
        historyData.forEach((d, idx) => {
          const x = getX(d.time);
          const bb = bbList[idx];
          if (bb && x >= 0 && x <= w - 80) {
            const y = getY(bb.upper);
            if (firstBB) {
              ctx.moveTo(x, y);
              firstBB = false;
            } else {
              ctx.lineTo(x, y);
            }
          }
        });

        // Backward for the lower band
        for (let idx = historyData.length - 1; idx >= 0; idx--) {
          const d = historyData[idx];
          const x = getX(d.time);
          const bb = bbList[idx];
          if (bb && x >= 0 && x <= w - 80) {
            const y = getY(bb.lower);
            ctx.lineTo(x, y);
          }
        }
        ctx.closePath();
        ctx.fillStyle = 'rgba(139, 92, 246, 0.03)';
        ctx.fill();

        // Draw upper band line
        ctx.beginPath();
        ctx.strokeStyle = 'rgba(167, 139, 250, 0.35)';
        ctx.lineWidth = 1;
        firstBB = true;
        historyData.forEach((d, idx) => {
          const x = getX(d.time);
          const bb = bbList[idx];
          if (bb && x >= 0 && x <= w - 80) {
            const y = getY(bb.upper);
            if (firstBB) {
              ctx.moveTo(x, y);
              firstBB = false;
            } else {
              ctx.lineTo(x, y);
            }
          }
        });
        ctx.stroke();

        // Draw lower band line
        ctx.beginPath();
        ctx.strokeStyle = 'rgba(167, 139, 250, 0.35)';
        ctx.lineWidth = 1;
        firstBB = true;
        historyData.forEach((d, idx) => {
          const x = getX(d.time);
          const bb = bbList[idx];
          if (bb && x >= 0 && x <= w - 80) {
            const y = getY(bb.lower);
            if (firstBB) {
              ctx.moveTo(x, y);
              firstBB = false;
            } else {
              ctx.lineTo(x, y);
            }
          }
        });
        ctx.stroke();
      }

      // Volume Bars Simulation at the bottom-most area of the main chart
      historyData.forEach((d, idx) => {
        const x = getX(d.time);
        if (x >= 0 && x <= w - 80) {
          const prevPrice = historyData[idx - 1] ? historyData[idx - 1].price : d.price;
          const delta = Math.abs(d.price - prevPrice);
          const isUp = d.price >= prevPrice;
          
          const volHeight = Math.min(15, 2 + delta * (selectedAsset.price < 5 ? 15000 : 15));
          const volY = chartBottom - volHeight;
          
          ctx.fillStyle = isUp ? 'rgba(16, 185, 129, 0.12)' : 'rgba(239, 68, 68, 0.12)';
          ctx.fillRect(x - 1, volY, 2, volHeight);
        }
      });

      // DRAW MAIN PRICES (LINE OR CANDLESTICK / VELAS)
      if (chartType === 'CANDLE') {
        const candles = computeCandles(historyData, candleInterval);
        // Fixed uniform candle width (between 5px and 9px) so changing interval never inflates candle size
        const rawWidth = ((candleInterval * 1000) / timeWindow) * (w - 80) * 0.72;
        const candleWidth = Math.min(9, Math.max(5, rawWidth));

        candles.forEach(candle => {
          const midTime = candle.time + (candleInterval * 1000) / 2;
          const x = getX(midTime);

          if (x >= -candleWidth && x <= w - 80 + candleWidth) {
            const yOpen = getY(candle.open);
            const yClose = getY(candle.close);
            const yHigh = getY(candle.high);
            const yLow = getY(candle.low);

            const isBullish = candle.close >= candle.open;
            const color = isBullish ? '#10b981' : '#ef4444';

            ctx.strokeStyle = color;
            ctx.lineWidth = 1.5;

            // Wick (low to high)
            ctx.beginPath();
            ctx.moveTo(x, yHigh);
            ctx.lineTo(x, yLow);
            ctx.stroke();

            // Body
            ctx.fillStyle = color;
            const bodyHeight = Math.max(1.5, Math.abs(yClose - yOpen));
            const bodyY = Math.min(yOpen, yClose);

            ctx.fillRect(x - candleWidth / 2, bodyY, candleWidth, bodyHeight);

            // Subtle border for premium design
            ctx.strokeStyle = 'rgba(255, 255, 255, 0.1)';
            ctx.lineWidth = 0.5;
            ctx.strokeRect(x - candleWidth / 2, bodyY, candleWidth, bodyHeight);
          }
        });
      } else {
        // Draw area gradient under line chart
        ctx.beginPath();
        let firstPoint = true;
        historyData.forEach(d => {
          const x = getX(d.time);
          const y = getY(d.price);
          if (x >= 0 && x <= w - 80) {
            if (firstPoint) {
              ctx.moveTo(x, chartBottom);
              ctx.lineTo(x, y);
              firstPoint = false;
            } else {
              ctx.lineTo(x, y);
            }
          }
        });
        const lastVisibleIdx = historyData.findIndex(d => getX(d.time) > w - 80);
        const endX = lastVisibleIdx !== -1 ? getX(historyData[lastVisibleIdx].time) : w - 80;
        ctx.lineTo(endX, chartBottom);
        ctx.closePath();

        const areaGrad = ctx.createLinearGradient(0, 0, 0, h);
        areaGrad.addColorStop(0, 'rgba(4, 148, 68, 0.15)');
        areaGrad.addColorStop(1, 'rgba(4, 148, 68, 0.0)');
        ctx.fillStyle = areaGrad;
        ctx.fill();

        // Draw Main Price Line
        ctx.beginPath();
        ctx.strokeStyle = '#049444';
        ctx.lineWidth = 2.5;
        ctx.lineCap = 'round';
        ctx.lineJoin = 'round';

        firstPoint = true;
        historyData.forEach(d => {
          const x = getX(d.time);
          const y = getY(d.price);
          if (x >= 0 && x <= w - 80) {
            if (firstPoint) {
              ctx.moveTo(x, y);
              firstPoint = false;
            } else {
              ctx.lineTo(x, y);
            }
          }
        });
        ctx.stroke();
      }

      // Draw SMAs (Simple Moving Averages) over main price representation
      if (showSMA7) {
        ctx.beginPath();
        ctx.strokeStyle = '#FFCC00';
        ctx.lineWidth = 1.5;
        let firstSMA = true;
        historyData.forEach((d, idx) => {
          const x = getX(d.time);
          const val = sma7List[idx];
          if (val !== null && x >= 0 && x <= w - 80) {
            const y = getY(val);
            if (firstSMA) {
              ctx.moveTo(x, y);
              firstSMA = false;
            } else {
              ctx.lineTo(x, y);
            }
          }
        });
        ctx.stroke();
      }

      if (showSMA14) {
        ctx.beginPath();
        ctx.strokeStyle = '#00e5ff';
        ctx.lineWidth = 1.5;
        let firstSMA = true;
        historyData.forEach((d, idx) => {
          const x = getX(d.time);
          const val = sma14List[idx];
          if (val !== null && x >= 0 && x <= w - 80) {
            const y = getY(val);
            if (firstSMA) {
              ctx.moveTo(x, y);
              firstSMA = false;
            } else {
              ctx.lineTo(x, y);
            }
          }
        });
        ctx.stroke();
      }

      // Draw Support & Resistance custom lines
      drawnLines.forEach(linePrice => {
        const lineY = getY(linePrice);
        if (lineY >= 40 && lineY <= chartBottom) {
          ctx.beginPath();
          ctx.strokeStyle = '#3b82f6';
          ctx.lineWidth = 1.2;
          ctx.setLineDash([4, 4]);
          ctx.moveTo(0, lineY);
          ctx.lineTo(w - 80, lineY);
          ctx.stroke();
          ctx.setLineDash([]);

          // Custom horizontal line badge
          ctx.fillStyle = '#3b82f6';
          ctx.fillRect(w - 78, lineY - 7, 75, 14);
          ctx.fillStyle = '#ffffff';
          ctx.font = 'bold 8px monospace';
          ctx.textAlign = 'center';
          ctx.fillText(linePrice.toFixed(selectedAsset.price < 5 ? 4 : 2), w - 40, lineY + 3);
        }
      });

      // Draw active trade entry lines and countdown indicators
      activeTrades.forEach(trade => {
        if (trade.assetId !== selectedAsset.id) return;

        const entryX = getX(trade.createdAt);
        const entryY = getY(trade.entryPrice);
        const currentPrice = latestPricesRef.current[trade.assetId] || trade.entryPrice;
        
        const isWinning = trade.direction === 'CALL' 
          ? currentPrice > trade.entryPrice 
          : currentPrice < trade.entryPrice;

        const tradeColor = isWinning ? 'rgba(16, 185, 129, 0.8)' : 'rgba(239, 68, 68, 0.8)';
        
        // Horizontal dashed entry level line
        ctx.beginPath();
        ctx.strokeStyle = tradeColor;
        ctx.lineWidth = 1.5;
        ctx.setLineDash([5, 5]);
        ctx.moveTo(0, entryY);
        ctx.lineTo(w - 80, entryY);
        ctx.stroke();
        ctx.setLineDash([]);

        // Draw indicator label on the entry line
        ctx.fillStyle = tradeColor;
        ctx.fillRect(5, entryY - 9, 65, 18);
        ctx.fillStyle = '#ffffff';
        ctx.font = 'bold 8px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(`${trade.direction} @$${trade.amount.toFixed(2)}`, 37, entryY + 3);

        // Expiration Vertical Line (if visible inside chart bounds)
        const expiryX = getX(trade.expiryAt);
        if (expiryX >= 0 && expiryX <= w - 80) {
          ctx.beginPath();
          ctx.strokeStyle = 'rgba(255, 204, 0, 0.6)';
          ctx.lineWidth = 1;
          ctx.setLineDash([3, 3]);
          ctx.moveTo(expiryX, 20);
          ctx.lineTo(expiryX, chartBottom);
          ctx.stroke();
          ctx.setLineDash([]);

          // Expiration icon or label
          ctx.fillStyle = 'rgba(255, 204, 0, 0.9)';
          ctx.font = 'bold 8px sans-serif';
          ctx.fillText('EXPIRAÇÃO', expiryX, 15);
        }
      });

      // Draw dynamic pulse glow on the latest price indicator
      const lastPoint = historyData[historyData.length - 1];
      const pulseX = getX(lastPoint.time);
      const pulseY = getY(lastPoint.price);

      if (pulseX >= 0 && pulseX <= w - 80) {
        const prevPoint = historyData[historyData.length - 2];
        const isUp = prevPoint ? lastPoint.price >= prevPoint.price : true;
        const color = isUp ? '#10b981' : '#ef4444';

        // Outer pulse circle
        const scale = 1 + (Date.now() % 1000) / 1000;
        ctx.beginPath();
        ctx.arc(pulseX, pulseY, 6 * scale, 0, 2 * Math.PI);
        ctx.fillStyle = isUp ? 'rgba(16, 185, 129, 0.25)' : 'rgba(239, 68, 68, 0.25)';
        ctx.fill();

        // Inner solid circle
        ctx.beginPath();
        ctx.arc(pulseX, pulseY, 4, 0, 2 * Math.PI);
        ctx.fillStyle = color;
        ctx.fill();

        // Horizontal line of the current price
        ctx.beginPath();
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.1)';
        ctx.lineWidth = 1;
        ctx.moveTo(pulseX, pulseY);
        ctx.lineTo(w - 70, pulseY);
        ctx.stroke();

        // Draw Right Price Tag overlay in the gutter
        ctx.fillStyle = color;
        ctx.beginPath();
        ctx.moveTo(w - 75, pulseY);
        ctx.lineTo(w - 70, pulseY - 8);
        ctx.lineTo(w, pulseY - 8);
        ctx.lineTo(w, pulseY + 8);
        ctx.lineTo(w - 70, pulseY + 8);
        ctx.closePath();
        ctx.fill();

        ctx.fillStyle = '#ffffff';
        ctx.font = 'bold 9px monospace';
        ctx.textAlign = 'center';
        ctx.fillText(lastPoint.price.toFixed(selectedAsset.price < 5 ? 4 : 2), w - 35, pulseY + 3);
      }

      // Draw separate RSI panel at the bottom (if enabled)
      if (showRSI) {
        const rsiTop = chartBottom + 15;
        const rsiBottom = rsiTop + rsiPanelHeight - 15;

        // Panel background
        ctx.fillStyle = '#070a12';
        ctx.fillRect(0, rsiTop, w - 80, rsiPanelHeight - 15);
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.05)';
        ctx.strokeRect(0, rsiTop, w - 80, rsiPanelHeight - 15);

        // Limit bands at 30, 50, and 70
        const rsiY70 = rsiBottom - (70 / 100) * (rsiBottom - rsiTop);
        const rsiY30 = rsiBottom - (30 / 100) * (rsiBottom - rsiTop);
        const rsiY50 = rsiBottom - (50 / 100) * (rsiBottom - rsiTop);

        ctx.strokeStyle = 'rgba(239, 68, 68, 0.15)'; // Overbought band
        ctx.beginPath();
        ctx.setLineDash([3, 3]);
        ctx.moveTo(0, rsiY70);
        ctx.lineTo(w - 80, rsiY70);
        ctx.stroke();

        ctx.strokeStyle = 'rgba(16, 185, 129, 0.15)'; // Oversold band
        ctx.beginPath();
        ctx.moveTo(0, rsiY30);
        ctx.lineTo(w - 80, rsiY30);
        ctx.stroke();

        ctx.strokeStyle = 'rgba(255, 255, 255, 0.05)'; // Centerline
        ctx.beginPath();
        ctx.moveTo(0, rsiY50);
        ctx.lineTo(w - 80, rsiY50);
        ctx.stroke();
        ctx.setLineDash([]);

        // Horizontal markings
        ctx.fillStyle = 'rgba(239, 68, 68, 0.5)';
        ctx.font = '8px monospace';
        ctx.fillText('70', w - 75, rsiY70 + 3);
        ctx.fillStyle = 'rgba(16, 185, 129, 0.5)';
        ctx.fillText('30', w - 75, rsiY30 + 3);

        // Plot RSI
        const rsiList = calculateRSIValues(historyData, 14);
        ctx.beginPath();
        ctx.strokeStyle = '#a855f7';
        ctx.lineWidth = 1.5;

        let rsiFirst = true;
        historyData.forEach((d, idx) => {
          const x = getX(d.time);
          const rsiVal = rsiList[idx];
          const rsiY = rsiBottom - (rsiVal / 100) * (rsiBottom - rsiTop);

          if (x >= 0 && x <= w - 80) {
            if (rsiFirst) {
              ctx.moveTo(x, rsiY);
              rsiFirst = false;
            } else {
              ctx.lineTo(x, rsiY);
            }
          }
        });
        ctx.stroke();

        const latestRSI = rsiList[rsiList.length - 1];
        if (latestRSI !== undefined) {
          ctx.fillStyle = '#a855f7';
          ctx.font = 'bold 8px sans-serif';
          ctx.textAlign = 'left';
          ctx.fillText(`RSI(14): ${latestRSI.toFixed(1)}`, 10, rsiTop + 10);
        }
      }

      // Draw crosshair Guidelines
      const mouse = mouseCoordsRef.current;
      if (mouse) {
        const mx = mouse.x;
        const my = mouse.y;

        if (mx >= 0 && mx <= w - 80 && my >= 40 && my <= chartBottom) {
          ctx.beginPath();
          ctx.strokeStyle = 'rgba(255, 255, 255, 0.15)';
          ctx.lineWidth = 0.5;
          ctx.setLineDash([2, 2]);

          // Horizontal guide
          ctx.moveTo(0, my);
          ctx.lineTo(w - 80, my);

          // Vertical guide
          ctx.moveTo(mx, 40);
          ctx.lineTo(mx, chartBottom);
          ctx.stroke();
          ctx.setLineDash([]);

          // Price tooltip
          const ratio = (chartBottom - my) / chartHeight;
          const priceAtMouse = minPrice + ratio * (maxPrice - minPrice);

          ctx.fillStyle = '#3b82f6';
          ctx.fillRect(w - 78, my - 8, 75, 16);
          ctx.fillStyle = '#ffffff';
          ctx.font = 'bold 8px monospace';
          ctx.textAlign = 'center';
          ctx.fillText(priceAtMouse.toFixed(selectedAsset.price < 5 ? 4 : 2), w - 40, my + 3);
        }
      }

      animationFrameId.current = requestAnimationFrame(render);
    };

    render();

    return () => {
      window.removeEventListener('resize', resizeCanvas);
      if (animationFrameId.current) {
        cancelAnimationFrame(animationFrameId.current);
      }
    };
  }, [selectedAsset, activeTrades, currentAssetPrice, chartType, candleInterval, showSMA7, showSMA14, showBB, showRSI, drawnLines, isLineToolActive, activeLeftTab]);

  // Monitor trades expiration
  useEffect(() => {
    const checkTradesInterval = setInterval(() => {
      const now = Date.now();
      const currentTrades = activeTradesRef.current;
      
      const expired = currentTrades.filter(t => now >= t.expiryAt);
      const nonExpired = currentTrades.filter(t => now < t.expiryAt);

      if (expired.length > 0) {
        // Set state to only include non-expired ones first
        setActiveTrades(nonExpired);

        // Process expired ones outside of any state updater to avoid multi-component updates during render
        expired.forEach(trade => {
          const finalPrice = latestPricesRef.current[trade.assetId] || trade.entryPrice;
          const isWin = trade.direction === 'CALL' 
            ? finalPrice > trade.entryPrice 
            : finalPrice < trade.entryPrice;

          const profit = isWin ? Math.floor(trade.amount * (1 + trade.payoutRate)) : 0;

          if (isWin) {
            soundService.playWin();
            onUpdateBalance(profit); // Safe parent update outside of render/updater callback
          } else {
            soundService.playLoss();
          }

          // Save trade to history
          const record: TradeHistory = {
            id: trade.id,
            assetName: trade.assetName,
            direction: trade.direction,
            entryPrice: trade.entryPrice,
            exitPrice: finalPrice,
            amount: trade.amount,
            payout: profit,
            isWin,
            timestamp: Date.now()
          };

          setHistory(prev => [record, ...prev].slice(0, 50));

          // Log to firestore if not demo
          if (!isDemo) {
            userService.logGameResult({
              gameId: 'TRADER',
              asset: trade.assetName,
              direction: trade.direction,
              betAmount: trade.amount,
              winAmount: profit,
              entryPrice: trade.entryPrice,
              exitPrice: finalPrice,
              outcome: isWin ? 'WIN' : 'LOSS'
            });
          }
        });
      }
    }, 500);

    return () => clearInterval(checkTradesInterval);
  }, [onUpdateBalance, isDemo]);

  // Mouse and Line Drawing Interactions
  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    mouseCoordsRef.current = { x, y };
  };

  const handleMouseLeave = () => {
    mouseCoordsRef.current = null;
  };

  const handleCanvasClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isLineToolActive) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const clickY = e.clientY - rect.top;
    
    const minP = minPriceRef.current;
    const maxP = maxPriceRef.current;
    const h = rect.height;
    
    const rsiH = showRSI ? 60 : 0;
    const chartBottom = h - 40 - rsiH;
    const chartHeight = chartBottom - 40;
    
    if (clickY >= 40 && clickY <= chartBottom) {
      const ratio = (chartBottom - clickY) / chartHeight;
      const price = minP + ratio * (maxP - minP);
      setDrawnLines(prev => [...prev, price]);
      setIsLineToolActive(false);
      soundService.playUISelect();
    }
  };

  const handleClearLines = () => {
    soundService.playUISelect();
    setDrawnLines([]);
  };

  // Open trade handler
  const handleOpenTrade = (direction: 'CALL' | 'PUT') => {
    if (balance < betAmount) {
      alert("Saldo insuficiente para realizar esta operação.");
      return;
    }

    soundService.playChip();
    
    // Deduct bet amount immediately
    onUpdateBalance(-betAmount);

    const now = Date.now();
    const expiry = now + selectedTimeframe * 1000;

    const newTrade: Trade = {
      id: Math.random().toString(36).substring(2, 11),
      assetId: selectedAsset.id,
      assetName: selectedAsset.name,
      direction,
      entryPrice: currentAssetPrice,
      amount: betAmount,
      payoutRate: selectedAsset.payout,
      createdAt: now,
      expiryAt: expiry
    };

    setActiveTrades(prev => [...prev, newTrade]);
  };

  return (
    <div className="flex-1 flex flex-col bg-[#05070a] text-white overflow-hidden font-sans h-full w-full relative">
      
      {/* HEADER COMPACTO */}
      <header className="px-4 py-2.5 flex items-center justify-between bg-[#0e131f] border-b border-white/5 z-40 shadow-xl flex-shrink-0">
        <div className="flex items-center gap-3">
          <button 
            onClick={() => { soundService.playUISelect(); onBack(); }}
            className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-white transition-colors cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4 sm:w-5 h-5" />
          </button>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="text-emerald-500 font-extrabold uppercase text-[9px] tracking-widest bg-emerald-500/10 px-1.5 py-0.5 rounded">OPÇÕES BINÁRIAS</span>
              {isDemo && <span className="bg-[#FFCC00] text-black font-extrabold text-[8px] px-1 rounded">DEMO</span>}
            </div>
            <h1 className="text-sm sm:text-base font-black tracking-tight flex items-center gap-1">
              TRADER VIP <Flame className="w-3.5 h-3.5 text-orange-500 animate-pulse fill-orange-500" />
            </h1>
          </div>
        </div>

        {/* Balance Display */}
        <div className="flex items-center gap-2 bg-[#05070a]/80 px-3 py-1.5 rounded-full border border-white/5 shadow-inner">
          <Coins className="w-4 h-4 text-[#FFCC00]" />
          <span className="text-xs sm:text-sm font-black font-mono tracking-tight text-[#FFCC00]">
            $ {balance.toFixed(2)} USDT
          </span>
        </div>
      </header>

      {/* WORKSPACE PRINCIPAL */}
      <div className="flex-1 flex flex-col lg:flex-row overflow-hidden relative">
        
        {/* SLIM LEFT DOCK (DOCK LATERAL DE ABAS) */}
        <div className="w-full lg:w-16 bg-[#090d16] border-b lg:border-b-0 lg:border-r border-white/5 flex lg:flex-col items-center justify-around lg:justify-start py-2 lg:py-6 gap-2 lg:gap-6 flex-shrink-0 z-30 shadow-2xl">
          {/* Tab: Posições & Histórico */}
          <button
            onClick={() => {
              soundService.playUISelect();
              setActiveLeftTab(prev => prev === 'trades' ? null : 'trades');
            }}
            className={`relative p-3 rounded-xl flex flex-col items-center justify-center transition-all cursor-pointer ${
              activeLeftTab === 'trades' 
                ? 'bg-[#049444]/20 text-[#049444] border border-[#049444]/30' 
                : 'text-slate-400 hover:text-white hover:bg-white/5 border border-transparent'
            }`}
            title="Minhas Operações (Histórico & Ativas)"
          >
            <History className="w-5 h-5" />
            <span className="text-[9px] font-bold mt-1 hidden lg:block">Painel</span>
            {activeTrades.length > 0 && (
              <span className="absolute top-1 right-1 bg-emerald-500 text-black font-black text-[8px] w-4 h-4 rounded-full flex items-center justify-center animate-pulse">
                {activeTrades.length}
              </span>
            )}
          </button>

          {/* Tab: Ferramentas de Análise */}
          <button
            onClick={() => {
              soundService.playUISelect();
              setActiveLeftTab(prev => prev === 'tools' ? null : 'tools');
            }}
            className={`p-3 rounded-xl flex flex-col items-center justify-center transition-all cursor-pointer ${
              activeLeftTab === 'tools' 
                ? 'bg-[#049444]/20 text-[#049444] border border-[#049444]/30' 
                : 'text-slate-400 hover:text-white hover:bg-white/5 border border-transparent'
            }`}
            title="Ferramentas Técnicas & Indicadores"
          >
            <Sliders className="w-5 h-5 text-purple-400" />
            <span className="text-[9px] font-bold mt-1 hidden lg:block">Indicadores</span>
          </button>

          {/* Tab: Tutorial / Ajuda */}
          <button
            onClick={() => {
              soundService.playUISelect();
              setActiveLeftTab(prev => prev === 'tutorial' ? null : 'tutorial');
            }}
            className={`p-3 rounded-xl flex flex-col items-center justify-center transition-all cursor-pointer ${
              activeLeftTab === 'tutorial' 
                ? 'bg-[#049444]/20 text-[#049444] border border-[#049444]/30' 
                : 'text-slate-400 hover:text-white hover:bg-white/5 border border-transparent'
            }`}
            title="Guia & Dicas de Negociação"
          >
            <Info className="w-5 h-5 text-blue-400" />
            <span className="text-[9px] font-bold mt-1 hidden lg:block">Como Jogar</span>
          </button>
        </div>

        {/* SIDEBAR EXPANSÍVEL DO LADO ESQUERDO */}
        {activeLeftTab && (
          <div className="absolute lg:relative left-0 right-0 lg:right-auto top-[56px] lg:top-0 bottom-0 lg:h-full z-30 w-full lg:w-80 bg-[#0c101d] border-r border-white/5 flex flex-col shadow-2xl overflow-hidden backdrop-blur-md">
            {/* Header do painel */}
            <div className="p-4 border-b border-white/5 flex items-center justify-between bg-[#13192a]">
              <h3 className="text-xs font-black uppercase tracking-wider text-white">
                {activeLeftTab === 'trades' && 'MINHAS OPERAÇÕES'}
                {activeLeftTab === 'assets' && 'SELECIONAR ATIVO'}
                {activeLeftTab === 'tools' && 'FERRAMENTAS & INDICADORES'}
                {activeLeftTab === 'tutorial' && 'GUIA TRADER VIP'}
              </h3>
              <button
                onClick={() => { soundService.playUISelect(); setActiveLeftTab(null); }}
                className="text-xs text-slate-400 hover:text-white px-2 py-1 rounded bg-white/5 cursor-pointer"
              >
                Fechar ✕
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-4 space-y-4 no-scrollbar">
              {/* CONTEÚDO TAB: TRADES (ATIVOS E HISTÓRICO) */}
              {activeLeftTab === 'trades' && (
                <div className="space-y-4">
                  {/* Seção 1: Ativas */}
                  <div>
                    <div className="text-[9px] font-black text-emerald-400 uppercase tracking-widest mb-2.5 flex items-center gap-1.5 bg-emerald-500/5 px-2 py-1 rounded border border-emerald-500/10">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                      <span>NEGOCIAÇÕES EM CURSO ({activeTrades.length})</span>
                    </div>
                    <div className="space-y-2">
                      {activeTrades.length === 0 ? (
                        <div className="text-center p-6 bg-white/5 rounded-2xl border border-white/5">
                          <Clock className="w-5 h-5 text-slate-500 mx-auto mb-1 opacity-60" />
                          <span className="text-[10px] text-slate-400 block font-bold">NENHUMA ORDEM ATIVA</span>
                          <span className="text-[9px] text-slate-500 block mt-0.5">Use os botões de SUBIDA/DESCIDA para abrir posições.</span>
                        </div>
                      ) : (
                        activeTrades.map(trade => {
                          const currentPrice = assetPrices[trade.assetId] || trade.entryPrice;
                          const isWinning = trade.direction === 'CALL' 
                            ? currentPrice > trade.entryPrice 
                            : currentPrice < trade.entryPrice;
                          const timeLeft = Math.max(0, Math.ceil((trade.expiryAt - Date.now()) / 1000));
                          const targetAsset = ASSETS.find(a => a.id === trade.assetId);
                          const decimals = (targetAsset && targetAsset.price < 5) ? 4 : 2;

                          return (
                            <div 
                              key={trade.id} 
                              className={`p-3 rounded-2xl border flex items-center justify-between transition-all ${
                                isWinning 
                                  ? 'bg-emerald-500/10 border-emerald-500/20 shadow-md shadow-emerald-500/5' 
                                  : 'bg-red-500/10 border-red-500/20 shadow-md shadow-red-500/5'
                              }`}
                            >
                              <div className="space-y-1">
                                <div className="flex items-center gap-1.5">
                                  {trade.direction === 'CALL' ? (
                                    <TrendingUp className="w-3.5 h-3.5 text-emerald-400" />
                                  ) : (
                                    <TrendingDown className="w-3.5 h-3.5 text-red-400" />
                                  )}
                                  <span className="text-xs font-black text-white">{trade.assetId.replace('_', '/')}</span>
                                </div>
                                <div className="text-[9px] text-slate-400 font-bold font-mono">
                                  {trade.entryPrice.toFixed(decimals)} ➜ {currentPrice.toFixed(decimals)}
                                </div>
                              </div>

                              <div className="text-right space-y-1">
                                <div className="text-[10px] font-bold flex items-center gap-1 justify-end text-slate-300">
                                  <Clock className="w-3 h-3 text-[#FFCC00]" />
                                  <span className="font-mono text-[#FFCC00] font-black">{timeLeft}s</span>
                                </div>
                                <div className={`text-xs font-black font-mono ${isWinning ? 'text-emerald-400' : 'text-red-400'}`}>
                                  {isWinning ? `+${Math.floor(trade.payoutRate * 100)}%` : `-$ ${(trade.amount || 0).toFixed(2)} USDT`}
                                </div>
                              </div>
                            </div>
                          );
                        })
                      )}
                    </div>
                  </div>

                  {/* Seção 2: Histórico de Fechados */}
                  <div>
                    <div className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-2.5 flex items-center gap-1.5 bg-white/5 px-2 py-1 rounded border border-white/5">
                      <History className="w-3 h-3 text-slate-400" />
                      <span>HISTÓRICO DE EXPIRAÇÕES ({history.length})</span>
                    </div>
                    <div className="space-y-2 max-h-[300px] overflow-y-auto no-scrollbar">
                      {history.length === 0 ? (
                        <div className="text-center py-8 text-slate-500 text-[10px] italic">
                          As suas posições terminadas serão listadas aqui.
                        </div>
                      ) : (
                        history.map(record => (
                          <div 
                            key={record.id} 
                            className={`p-3 rounded-2xl border flex items-center justify-between bg-[#13192a]/50 ${
                              record.isWin 
                                ? 'border-emerald-500/20 text-emerald-400' 
                                : 'border-red-500/20 text-red-400'
                            }`}
                          >
                            <div className="space-y-0.5">
                              <div className="flex items-center gap-1.5">
                                <span className="text-[10px] font-black text-white">{record.assetName.split(' ')[0]}</span>
                                <span className="text-[8px] font-bold uppercase font-sans px-1 rounded bg-black/30 text-slate-300">
                                  {record.direction}
                                </span>
                              </div>
                              <div className="text-[9px] text-slate-400 font-mono">
                                Preço: {record.exitPrice.toFixed(record.exitPrice < 5 ? 4 : 2)}
                              </div>
                            </div>
                            <div className="text-right space-y-0.5">
                              <div className={`text-xs font-black font-mono ${record.isWin ? 'text-emerald-400' : 'text-red-400'}`}>
                                {record.isWin ? `+$ ${(record.payout - record.amount).toFixed(2)} USDT` : `-$ ${(record.amount || 0).toFixed(2)} USDT`}
                              </div>
                              <div className="text-[8px] text-slate-500">
                                {new Date(record.timestamp).toLocaleTimeString('pt-AO', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                              </div>
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                  </div>
                </div>
              )}

              {/* CONTEÚDO TAB: FERRAMENTAS & INDICADORES */}
              {activeLeftTab === 'tools' && (
                <div className="space-y-4">
                  <div className="p-3 bg-white/5 border border-white/5 rounded-2xl">
                    <h4 className="text-[10px] font-black text-slate-300 uppercase tracking-widest mb-3 flex items-center gap-1.5">
                      📊 ESTILO DO GRÁFICO
                    </h4>
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        onClick={() => {
                          soundService.playUISelect();
                          setChartType('LINE');
                        }}
                        className={`py-2 px-3 text-xs font-bold rounded-xl transition-all uppercase flex items-center justify-center gap-1.5 cursor-pointer border ${
                          chartType === 'LINE'
                            ? 'bg-purple-600/20 text-purple-400 border-purple-500/30 font-black'
                            : 'bg-white/5 text-slate-400 border-transparent hover:text-white'
                        }`}
                      >
                        📈 Linha (Área)
                      </button>
                      <button
                        onClick={() => {
                          soundService.playUISelect();
                          setChartType('CANDLE');
                        }}
                        className={`py-2 px-3 text-xs font-bold rounded-xl transition-all uppercase flex items-center justify-center gap-1.5 cursor-pointer border ${
                          chartType === 'CANDLE'
                            ? 'bg-purple-600/20 text-purple-400 border-purple-500/30 font-black'
                            : 'bg-white/5 text-slate-400 border-transparent hover:text-white'
                        }`}
                      >
                        🕯️ Velas (Candles)
                      </button>
                    </div>
                  </div>

                  {chartType === 'CANDLE' && (
                    <div className="p-3 bg-white/5 border border-white/5 rounded-2xl">
                      <h4 className="text-[10px] font-black text-slate-300 uppercase tracking-widest mb-3 flex items-center gap-1.5">
                        ⏱️ INTERVALO DE TEMPO DA VELA
                      </h4>
                      <div className="grid grid-cols-4 gap-1.5">
                        {[5, 10, 15, 30].map(sec => (
                          <button
                            key={sec}
                            onClick={() => {
                              soundService.playUISelect();
                              setCandleInterval(sec);
                              if (sec === 5) setSelectedTimeframe(30);
                              else if (sec === 10) setSelectedTimeframe(60);
                              else if (sec === 15) setSelectedTimeframe(120);
                              else if (sec === 30) setSelectedTimeframe(300);
                            }}
                            className={`py-2 text-xs font-bold rounded-xl transition-all cursor-pointer ${
                              candleInterval === sec
                                ? 'bg-purple-600 text-white shadow-md font-black'
                                : 'bg-white/5 text-slate-400 hover:text-white hover:bg-white/10'
                            }`}
                          >
                            {sec}s
                          </button>
                        ))}
                      </div>
                    </div>
                  )}

                  <div className="p-3 bg-white/5 border border-white/5 rounded-2xl">
                    <h4 className="text-[10px] font-black text-slate-300 uppercase tracking-widest mb-3 flex items-center gap-1.5">
                      🛠️ INDICADORES TÉCNICOS
                    </h4>
                    <div className="space-y-2">
                      {/* Bollinger Bands */}
                      <button
                        onClick={() => {
                          soundService.playUISelect();
                          setShowBB(prev => !prev);
                        }}
                        className={`w-full flex items-center justify-between p-3 rounded-xl transition-all cursor-pointer border ${
                          showBB 
                            ? 'bg-purple-600/20 border-purple-500/30 text-white font-black' 
                            : 'bg-white/5 border-transparent text-slate-300 hover:bg-white/10'
                        }`}
                      >
                        <span className="text-xs">Bandas de Bollinger (BB)</span>
                        <span className={`text-[8px] font-bold px-1.5 py-0.5 rounded uppercase ${showBB ? 'bg-purple-500 text-white font-black' : 'bg-white/10 text-slate-400'}`}>
                          {showBB ? 'ATIVADO' : 'DESATIVADO'}
                        </span>
                      </button>

                      {/* Média Móvel SMA 7 */}
                      <button
                        onClick={() => {
                          soundService.playUISelect();
                          setShowSMA7(prev => !prev);
                        }}
                        className={`w-full flex items-center justify-between p-3 rounded-xl transition-all cursor-pointer border ${
                          showSMA7 
                            ? 'bg-yellow-500/10 border-yellow-500/30 text-white font-black' 
                            : 'bg-white/5 border-transparent text-slate-300 hover:bg-white/10'
                        }`}
                      >
                        <span className="text-xs text-yellow-400 font-bold">Média Móvel SMA (7)</span>
                        <span className={`text-[8px] font-bold px-1.5 py-0.5 rounded uppercase ${showSMA7 ? 'bg-yellow-500 text-[#090d16] font-black' : 'bg-white/10 text-slate-400'}`}>
                          {showSMA7 ? 'ATIVADO' : 'DESATIVADO'}
                        </span>
                      </button>

                      {/* Média Móvel SMA 14 */}
                      <button
                        onClick={() => {
                          soundService.playUISelect();
                          setShowSMA14(prev => !prev);
                        }}
                        className={`w-full flex items-center justify-between p-3 rounded-xl transition-all cursor-pointer border ${
                          showSMA14 
                            ? 'bg-cyan-400/10 border-cyan-400/30 text-white font-black' 
                            : 'bg-white/5 border-transparent text-slate-300 hover:bg-white/10'
                        }`}
                      >
                        <span className="text-xs text-cyan-400 font-bold">Média Móvel SMA (14)</span>
                        <span className={`text-[8px] font-bold px-1.5 py-0.5 rounded uppercase ${showSMA14 ? 'bg-cyan-400 text-[#090d16] font-black' : 'bg-white/10 text-slate-400'}`}>
                          {showSMA14 ? 'ATIVADO' : 'DESATIVADO'}
                        </span>
                      </button>

                      {/* Oscilador RSI */}
                      <button
                        onClick={() => {
                          soundService.playUISelect();
                          setShowRSI(prev => !prev);
                        }}
                        className={`w-full flex items-center justify-between p-3 rounded-xl transition-all cursor-pointer border ${
                          showRSI 
                            ? 'bg-fuchsia-600/20 border-fuchsia-500/30 text-white font-black' 
                            : 'bg-white/5 border-transparent text-slate-300 hover:bg-white/10'
                        }`}
                      >
                        <span className="text-xs">Oscilador RSI (14)</span>
                        <span className={`text-[8px] font-bold px-1.5 py-0.5 rounded uppercase ${showRSI ? 'bg-fuchsia-600 text-white font-black' : 'bg-white/10 text-slate-400'}`}>
                          {showRSI ? 'ATIVADO' : 'DESATIVADO'}
                        </span>
                      </button>
                    </div>
                  </div>

                  <div className="p-3 bg-white/5 border border-white/5 rounded-2xl">
                    <h4 className="text-[10px] font-black text-slate-300 uppercase tracking-widest mb-3 flex items-center gap-1.5">
                      ✏️ DESENHAR NO GRÁFICO
                    </h4>
                    <div className="space-y-2">
                      <button
                        onClick={() => {
                          soundService.playUISelect();
                          setIsLineToolActive(prev => !prev);
                        }}
                        className={`w-full flex items-center justify-center gap-2 p-3 rounded-xl transition-all cursor-pointer border text-xs font-bold ${
                          isLineToolActive 
                            ? 'bg-blue-600 text-white border-blue-500 font-black animate-pulse' 
                            : 'bg-white/5 border-transparent text-slate-300 hover:bg-white/10'
                        }`}
                      >
                        ✏️ {isLineToolActive ? 'CLIQUE NO GRÁFICO PARA TRAÇAR' : 'TRAÇAR SUPORTE/RESISTÊNCIA'}
                      </button>

                      {drawnLines.length > 0 && (
                        <button
                          onClick={() => {
                            soundService.playUISelect();
                            handleClearLines();
                          }}
                          className="w-full flex items-center justify-center gap-2 p-3 rounded-xl bg-red-500/10 border border-red-500/20 hover:bg-red-500/20 text-red-400 font-bold transition-all cursor-pointer text-xs"
                        >
                          <Trash2 className="w-4 h-4" /> APAGAR TODAS AS LINHAS ({drawnLines.length})
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              )}

              {/* CONTEÚDO TAB: TUTORIAL / GUIA */}
              {activeLeftTab === 'tutorial' && (
                <div className="space-y-4 text-xs leading-relaxed text-slate-300 font-sans font-medium">
                  <div className="bg-blue-500/10 border border-blue-500/10 p-3 rounded-2xl text-blue-400 font-bold text-center">
                    🎯 PREVISÃO EM 3 PASSOS SIMPLES
                  </div>
                  <div className="space-y-3.5">
                    <div className="flex gap-2.5">
                      <span className="bg-[#FFCC00] text-black w-5 h-5 rounded-full flex items-center justify-center font-black shrink-0 text-[10px]">1</span>
                      <div>
                        <strong className="text-white">Escolha o seu Ativo:</strong> Use a aba <strong className="text-emerald-400">Ativos</strong> ou o seletor superior para trocar para Dólar, Euro, Bitcoin ou USDT.
                      </div>
                    </div>
                    <div className="flex gap-2.5">
                      <span className="bg-[#FFCC00] text-black w-5 h-5 rounded-full flex items-center justify-center font-black shrink-0 text-[10px]">2</span>
                      <div>
                        <strong className="text-white">Tempo & Valor:</strong> No painel direito, insira o seu valor em USDT (Mín: $ 1.00 USDT) e defina o tempo de expiração do gráfico (30s até 5min).
                      </div>
                    </div>
                    <div className="flex gap-2.5">
                      <span className="bg-[#FFCC00] text-black w-5 h-5 rounded-full flex items-center justify-center font-black shrink-0 text-[10px]">3</span>
                      <div>
                        <strong className="text-white">Defina a Direção:</strong>
                        <ul className="list-disc pl-4 mt-1 space-y-1">
                          <li>Se acha que o preço vai <strong className="text-emerald-400">SUBIR</strong>, clique em <strong className="text-emerald-400">SUBIDA (CALL)</strong>.</li>
                          <li>Se acha que o preço vai <strong className="text-red-400">CAIR</strong>, clique em <strong className="text-red-400">DESCIDA (PUT)</strong>.</li>
                        </ul>
                      </div>
                    </div>
                  </div>
                  <div className="p-3 bg-white/5 border border-white/5 rounded-2xl mt-2 text-[10px] text-slate-400">
                    💡 <strong>Dica do Pro:</strong> Ative os indicadores <strong>Bollinger Bands (BB)</strong> ou <strong>Média Móvel (SMA7)</strong> na barra de ferramentas técnica para analisar tendências e aumentar sua taxa de acerto!
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* LADO DIREITO: ÁREA DO GRÁFICO (CENTRAL) */}
        <div className="flex-1 flex flex-col relative min-h-[350px] lg:h-full bg-[#05070a]">
          
          {/* BARRA SUPERIOR DE ATIVOS & DADOS */}
          <div className="absolute top-3 left-3 right-3 flex justify-between items-center z-20 gap-2">
            {/* Seletor de Ativos rápido */}
            <div className="relative">
              <button 
                onClick={() => { soundService.playUISelect(); setShowAssetSelector(!showAssetSelector); }}
                className="flex items-center gap-2 px-3 py-2 bg-[#0e131f]/90 hover:bg-[#141b2c] rounded-xl border border-white/5 shadow-lg text-xs sm:text-sm font-bold tracking-tight text-white transition-all backdrop-blur cursor-pointer"
              >
                <span className="text-lg">{selectedAsset.symbol.split(' ')[0]}</span>
                <span>{selectedAsset.name}</span>
                <ChevronDown className="w-3.5 h-3.5 opacity-60" />
              </button>

              {/* Menu Dropdown de Ativos */}
              {showAssetSelector && (
                <div className="absolute left-0 mt-2 w-64 bg-[#0e131f] border border-white/10 rounded-2xl shadow-2xl overflow-hidden z-50">
                  <div className="p-2.5 bg-white/5 border-b border-white/5 text-[9px] font-bold text-slate-400 uppercase tracking-widest">
                    Selecione um Ativo para Negociar
                  </div>
                  <div className="max-h-60 overflow-y-auto divide-y divide-white/5">
                    {ASSETS.map(asset => {
                      const currentPrice = assetPrices[asset.id] || asset.price;
                      return (
                        <button
                          key={asset.id}
                          onClick={() => {
                            soundService.playUISelect();
                            setSelectedAsset(asset);
                            setShowAssetSelector(false);
                          }}
                          className={`w-full flex items-center justify-between px-3.5 py-3 hover:bg-white/5 transition-all text-left cursor-pointer ${selectedAsset.id === asset.id ? 'bg-white/10' : ''}`}
                        >
                          <div>
                            <div className="font-extrabold text-xs flex items-center gap-1">
                              <span>{asset.symbol}</span>
                            </div>
                            <div className="text-[10px] text-slate-400 font-medium">{asset.name}</div>
                          </div>
                          <div className="text-right">
                            <div className="font-mono font-bold text-xs">
                              {currentPrice.toFixed(asset.price < 5 ? 4 : 2)}
                            </div>
                            <div className="text-[10px] text-emerald-400 font-black">
                              +{Math.floor(asset.payout * 100)}% Lucro
                            </div>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>

            {/* LIVE TRADE BADGE AT THE TOP */}
            {activeTrades.length > 0 && (
              (() => {
                const activeTrade = activeTrades[0];
                const currentPrice = assetPrices[activeTrade.assetId] || activeTrade.entryPrice;
                const isWinning = activeTrade.direction === 'CALL' 
                  ? currentPrice > activeTrade.entryPrice 
                  : currentPrice < activeTrade.entryPrice;
                const timeLeft = Math.max(0, Math.ceil((activeTrade.expiryAt - Date.now()) / 1000));
                return (
                  <div className="flex items-center gap-2 px-3 py-1.5 bg-[#0e131f]/95 border border-[#FFCC00]/20 rounded-xl shadow-lg backdrop-blur animate-pulse">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#FFCC00] animate-ping" />
                    <span className="text-[10px] font-black tracking-wider text-slate-300 font-mono">
                      ORDEM: <span className="text-white font-extrabold">{timeLeft}s</span>
                    </span>
                    <span className={`text-[9px] font-extrabold px-1.5 py-0.5 rounded ${
                      isWinning ? 'bg-emerald-500/10 text-emerald-400' : 'bg-red-500/10 text-red-400'
                    }`}>
                      {isWinning ? 'GANHANDO 🟢' : 'PERDENDO 🔴'}
                    </span>
                  </div>
                );
              })()
            )}

          </div>

          {/* CANVAS DO GRÁFICO */}
          <div className="flex-1 relative w-full h-full overflow-hidden">
            <canvas 
              ref={canvasRef} 
              onMouseMove={handleMouseMove}
              onMouseLeave={handleMouseLeave}
              onClick={handleCanvasClick}
              className={`absolute inset-0 w-full h-full block ${isLineToolActive ? 'cursor-crosshair' : 'cursor-default'}`} 
            />

            {/* FLOATING ACTION PANEL OVER CHART */}
            {activeTrades.length === 0 && (
              <div className="absolute right-4 top-16 z-20 flex flex-col gap-3 bg-[#0c101d]/95 p-3.5 rounded-2xl border border-white/10 backdrop-blur shadow-2xl w-44 sm:w-48">
                {/* Tempo de Expiração */}
                <div className="space-y-1">
                  <span className="text-[8px] font-black text-slate-400 uppercase tracking-widest block">Expiração</span>
                  <select
                    value={selectedTimeframe}
                    onChange={(e) => {
                      soundService.playUISelect();
                      setSelectedTimeframe(parseInt(e.target.value));
                    }}
                    className="w-full bg-[#05070a]/90 border border-white/10 rounded-xl px-2 py-1.5 text-xs font-bold text-[#FFCC00] focus:outline-none cursor-pointer"
                  >
                    {TIMEFRAMES.map(tf => (
                      <option key={tf.value} value={tf.value} className="bg-[#0e131f] text-white">
                        {tf.label}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Valor de Entrada */}
                <div className="space-y-1">
                  <div className="flex justify-between items-center">
                    <span className="text-[8px] font-black text-slate-400 uppercase tracking-widest">Valor</span>
                    <span className="text-[7px] text-slate-500 font-bold">Min: $1 USDT</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => {
                        soundService.playUISelect();
                        setBetAmount(prev => Math.max(10, prev - 50));
                      }}
                      className="px-2 py-1 bg-white/5 hover:bg-white/10 rounded-lg text-slate-300 font-black text-xs cursor-pointer select-none"
                    >
                      -
                    </button>
                    <input
                      type="number"
                      value={betAmount || ''}
                      onChange={(e) => {
                        const val = Math.max(10, parseInt(e.target.value) || 0);
                        setBetAmount(val);
                      }}
                      className="w-full bg-[#05070a]/90 border border-[#FFCC00]/20 rounded-xl py-1 text-center font-bold font-mono text-xs text-[#FFCC00] focus:outline-none"
                    />
                    <button
                      onClick={() => {
                        soundService.playUISelect();
                        setBetAmount(prev => prev + 50);
                      }}
                      className="px-2 py-1 bg-white/5 hover:bg-white/10 rounded-lg text-slate-300 font-black text-xs cursor-pointer select-none"
                    >
                      +
                    </button>
                  </div>
                </div>

                {/* Rendimento / Retorno */}
                <div className="text-center pt-1.5 border-t border-white/5 space-y-0.5">
                  <span className="text-[8px] font-black text-slate-400 uppercase tracking-widest block">Retorno Estimado</span>
                  <span className="text-emerald-400 font-mono font-extrabold text-xs block">
                    $ {(betAmount * (1 + selectedAsset.payout)).toFixed(2)} USDT
                  </span>
                </div>

                {/* Botões de Entrada */}
                <div className="flex flex-col gap-2 pt-1 border-t border-white/5">
                  <button
                    onClick={() => handleOpenTrade('CALL')}
                    className="flex flex-col items-center justify-center py-2.5 rounded-xl bg-gradient-to-b from-emerald-500 to-green-600 hover:from-emerald-400 hover:to-green-500 text-white font-black uppercase tracking-wider text-[10px] shadow-lg shadow-emerald-500/10 transition-all hover:scale-[1.02] active:scale-[0.98] cursor-pointer border border-emerald-400/20 gap-0.5"
                  >
                    <TrendingUp className="w-3.5 h-3.5 animate-pulse" />
                    <span>SUBIDA</span>
                  </button>

                  <button
                    onClick={() => handleOpenTrade('PUT')}
                    className="flex flex-col items-center justify-center py-2.5 rounded-xl bg-gradient-to-b from-red-500 to-rose-600 hover:from-red-400 hover:to-rose-500 text-white font-black uppercase tracking-wider text-[10px] shadow-lg shadow-red-500/10 transition-all hover:scale-[1.02] active:scale-[0.98] cursor-pointer border border-red-400/20 gap-0.5"
                  >
                    <TrendingDown className="w-3.5 h-3.5 animate-pulse" />
                    <span>DESCIDA</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>

      </div>

      {/* DIÁLOGO / MODAL DE TUTORIAL */}
      {showTutorial && (
        <div className="absolute inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-[#0e1320] border border-white/10 p-6 rounded-3xl max-w-md w-full space-y-4 shadow-2xl relative">
            <h2 className="text-base sm:text-lg font-black text-white uppercase tracking-tight flex items-center gap-1.5">
              <HelpCircle className="w-5 h-5 text-[#FFCC00]" /> COMO JOGAR TRADER VIP?
            </h2>
            <div className="space-y-3 text-slate-300 text-xs leading-relaxed font-sans font-medium">
              <p>
                O <strong className="text-white">Trader VIP</strong> é um jogo de previsão financeira super dinâmico (estilo opções binárias / Crypton Option):
              </p>
              <ol className="list-decimal list-inside space-y-2">
                <li>
                  <strong className="text-white">Escolha um Ativo</strong>: No menu superior esquerdo (ex: Bitcoin, Ouro, EUR/USD).
                </li>
                <li>
                  <strong className="text-white">Configure o Tempo</strong>: Defina o tempo de expiração da sua ordem (ex: 30 segundos).
                </li>
                <li>
                  <strong className="text-white">Insira o Valor</strong>: Insira o quanto quer investir na previsão.
                </li>
                <li>
                  <strong className="text-white">Selecione o Rumor</strong>:
                  <ul className="list-disc list-inside pl-4 mt-1 space-y-1">
                    <li>Se prevê que o preço <strong className="text-emerald-400">SUBIRÁ</strong>, clique em <strong className="text-emerald-400">SUBIDA (CALL)</strong>.</li>
                    <li>Se prevê que o preço <strong className="text-red-400">CAIRÁ</strong>, clique em <strong className="text-red-400">DESCIDA (PUT)</strong>.</li>
                  </ul>
                </li>
                <li>
                  <strong className="text-white">Resultado</strong>: Ao término do tempo escolhido, se a sua direção se confirmar, você ganha o investimento de volta mais o bónus do multiplicador (ex: <strong className="text-emerald-400">88% de lucro líquido!</strong>).
                </li>
              </ol>
            </div>
            <button
              onClick={() => { soundService.playUISelect(); setShowTutorial(false); }}
              className="w-full bg-[#049444] hover:bg-[#037235] text-white font-black py-3 rounded-xl transition-all cursor-pointer uppercase text-xs tracking-widest mt-2"
            >
              Compreendi, Jogar!
            </button>
          </div>
        </div>
      )}

    </div>
  );
};

export default TraderView;
