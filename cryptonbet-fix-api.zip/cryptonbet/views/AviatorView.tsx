
import React, { useState, useEffect, useCallback, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { GameStatus, Bet, RoundHistory, GlobalSettings } from '../types';
import HistoryBar from '../components/HistoryBar';
import GameCanvas from '../components/GameCanvas';
import BetPanel from '../components/BetPanel';
import { getGameCommentary } from '../services/geminiService';
import { soundService } from '../services/soundService';

interface AviatorViewProps {
  balance: number;
  isDemo?: boolean;
  onUpdateBalance: (amount: number) => void;
  onBack: () => void;
}

const BETTING_TIME = 12; 

const AviatorView: React.FC<AviatorViewProps> = ({ balance, isDemo, onUpdateBalance, onBack }) => {
  const [status, setStatus] = useState<GameStatus>(GameStatus.IDLE);
  const [multiplier, setMultiplier] = useState(1.00);
  const [history, setHistory] = useState<RoundHistory[]>([]);
  const [bet, setBet] = useState<Bet>({
    amount: 10,
    autoCashout: null,
    cashedOut: false,
    winAmount: 0,
    multiplierAtCashout: null
  });
  const [hasActiveBet, setHasActiveBet] = useState(false);
  const [bettingTimer, setBettingTimer] = useState(0);
  const [aiMessage, setAiMessage] = useState("Sistemas em check...");
  const [isMilestone, setIsMilestone] = useState(false);
  const [isHistoryModalOpen, setIsHistoryModalOpen] = useState(false);

  const crashPointRef = useRef(0);
  const multiplierRef = useRef(1.00);
  const lastMilestoneRef = useRef(1);
  const intervalRef = useRef<number | null>(null);

  const [isDesktop, setIsDesktop] = useState(window.innerWidth >= 786);

  // Refs para valores mutáveis em tempo real (evita stale closures)
  const statusRef = useRef<GameStatus>(status);
  const hasActiveBetRef = useRef(hasActiveBet);
  const betRef = useRef(bet);
  const onUpdateBalanceRef = useRef(onUpdateBalance);

  useEffect(() => {
    statusRef.current = status;
    hasActiveBetRef.current = hasActiveBet;
    betRef.current = bet;
    onUpdateBalanceRef.current = onUpdateBalance;
  }, [status, hasActiveBet, bet, onUpdateBalance]);

  useEffect(() => {
    const handleResize = () => setIsDesktop(window.innerWidth >= 786);
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const handleCrash = useCallback((finalMultiplier: number) => {
    if (intervalRef.current) clearInterval(intervalRef.current);
    soundService.playCrash();
    setStatus(GameStatus.CRASHED);
    setMultiplier(finalMultiplier);
    
    setHistory(prev => [{
      id: Math.random().toString(36).substr(2, 9),
      multiplier: finalMultiplier,
      timestamp: Date.now()
    }, ...prev].slice(0, 30)); 
    
    getGameCommentary(GameStatus.CRASHED, finalMultiplier).then(setAiMessage);
    setTimeout(() => setStatus(GameStatus.BETTING), 5000);
  }, []);

  const startFlight = useCallback(() => {
    setStatus(GameStatus.FLYING);
    soundService.playTakeoff();
    soundService.startEngine(1);
    
    let settings: any = {};
    try {
      settings = JSON.parse(localStorage.getItem('skyhigh_settings') || '{}');
    } catch (e) {
      console.warn("Could not parse skyhigh_settings, using defaults.", e);
    }
    if (settings.forcedAviatorMultiplier) {
      crashPointRef.current = settings.forcedAviatorMultiplier;
    } else {
      const rtp = settings.globalRtp || 95;
      const rtpFactor = rtp / 100;
      const rand = Math.random();
      
      // HOUSE PROTECTION LAYER & BAITING STRATEGY
      if (isDemo) {
        // DEMO MODE: High rewards, low risk (Controlled by BaitingMode)
        const isBaiting = settings.baitingMode !== false;
        const demoRand = Math.random();
        if (isBaiting && demoRand < 0.15) {
            // High multiplier bait
            crashPointRef.current = 15 + Math.random() * 85;
        } else {
            crashPointRef.current = 1.3 + Math.random() * 4.7;
        }
      } else {
        // REAL MODE: Aggressive protection based on houseAdvantageLevel
        const advLevel = settings.houseAdvantageLevel || 'MEDIUM';
        const instaCrashThreshold = advLevel === 'EXTREME' ? 0.15 : advLevel === 'MEDIUM' ? 0.08 : 0.03;
        
        if (rand < instaCrashThreshold) {
          crashPointRef.current = 1.00;
        } else {
          const currentBetAmount = betRef.current.amount;
          let baseCrash = 0.98 / (1 - Math.random());
          
          // Apply dynamic caps based on advantage level
          const riskFactor = advLevel === 'EXTREME' ? 0.6 : advLevel === 'MEDIUM' ? 1.0 : 1.5;
          
          if (hasActiveBetRef.current && currentBetAmount >= 500) {
             const cap = (2.5 + Math.random() * 2.5) * riskFactor;
             if (baseCrash > cap) baseCrash = cap;
          } else if (hasActiveBetRef.current && currentBetAmount >= 2000) {
             const cap = (1.2 + Math.random() * 0.5) * riskFactor;
             if (baseCrash > cap) baseCrash = cap;
          }
          
          crashPointRef.current = Math.min(baseCrash, 500);
        }
      }
    }

    getGameCommentary(GameStatus.FLYING).then(setAiMessage);

    const startTime = Date.now();
    intervalRef.current = window.setInterval(() => {
      const elapsed = (Date.now() - startTime) / 1000;
      // Curva de crescimento inicial mais dinâmica e rápida: e^(0.15 * t) -> Ajustado para ser 2x mais rápido
      const newMultiplier = 1.0 + (elapsed * 0.2) + 2 * Math.pow(elapsed / 10, 2);
      
      if (newMultiplier >= crashPointRef.current) {
        handleCrash(crashPointRef.current);
      } else {
        setMultiplier(newMultiplier);
        multiplierRef.current = newMultiplier;
        
        const currentInteger = Math.floor(newMultiplier);
        if (currentInteger > lastMilestoneRef.current) {
          lastMilestoneRef.current = currentInteger;
          setIsMilestone(true);
          soundService.playTick(); 
          setTimeout(() => setIsMilestone(false), 400);
        }

        soundService.startEngine(newMultiplier);

        // Use refs here to check current bet state without stale closure
        if (hasActiveBetRef.current && !betRef.current.cashedOut && betRef.current.autoCashout && newMultiplier >= betRef.current.autoCashout) {
          const currentMult = newMultiplier;
          const win = betRef.current.amount * currentMult;
          onUpdateBalanceRef.current(win);
          setBet(prev => ({ ...prev, cashedOut: true, winAmount: win, multiplierAtCashout: currentMult }));
          soundService.playWin();
        }
      }
    }, 30);
  }, [handleCrash]);

  // 1. Inicialização do estado de aposta
  useEffect(() => {
    if (status === GameStatus.IDLE) {
      setStatus(GameStatus.BETTING);
      return;
    }

    if (status === GameStatus.BETTING) {
      soundService.stopEngine();
      setMultiplier(1.00);
      multiplierRef.current = 1.00;
      lastMilestoneRef.current = 1;
      setBettingTimer(BETTING_TIME);
      setHasActiveBet(false);
      setBet(prev => ({ ...prev, cashedOut: false, winAmount: 0, multiplierAtCashout: null }));
      getGameCommentary(GameStatus.BETTING).then(setAiMessage);
    }
  }, [status]);

  // 2. Countdown de Apostas
  useEffect(() => {
    if (status !== GameStatus.BETTING) return;

    const timer = setInterval(() => {
      setBettingTimer(prev => {
        if (prev <= 0.1) {
          clearInterval(timer);
          return 0;
        }
        return prev - 0.1;
      });
    }, 100);

    return () => clearInterval(timer);
  }, [status]);

  // 3. Gatilho de Voo (Decolagem)
  useEffect(() => {
    if (status === GameStatus.BETTING && bettingTimer <= 0) {
      startFlight();
    }
  }, [bettingTimer, status, startFlight]);

  // Removido o useEffect separado que causava o reinício instantâneo

  const placeBet = () => {
    if (status === GameStatus.BETTING && !hasActiveBet && balance >= bet.amount) {
      onUpdateBalance(-bet.amount);
      setHasActiveBet(true);
      soundService.playBet();
    }
  };

  const cashOut = () => {
    if (status === GameStatus.FLYING && hasActiveBet && !bet.cashedOut) {
      const currentMult = multiplierRef.current;
      const win = bet.amount * currentMult;
      onUpdateBalance(win);
      setBet(prev => ({ ...prev, cashedOut: true, winAmount: win, multiplierAtCashout: currentMult }));
      soundService.playWin();
    }
  };

  useEffect(() => {
    return () => { 
      if (intervalRef.current) clearInterval(intervalRef.current);
      soundService.stopEngine();
    };
  }, []);

  return (
    <div className="flex flex-col h-full bg-[#05070a] text-white overflow-hidden font-sans relative">
      
      {/* CABEÇALHO MOBILE / DESKTOP */}
      <div className="flex flex-col bg-[#131d27] border-b border-white/5 flex-shrink-0 z-[100]">
        <div className="flex justify-between items-center px-4 py-2 h-12 md:h-14">
          <button onClick={() => { soundService.playUISelect(); onBack(); }} className="text-[#FFCC00] font-black text-[10px] sm:text-xs uppercase tracking-widest flex items-center gap-1 active:scale-95 transition-transform group cursor-pointer">
            <svg className="w-4 h-4 group-hover:-translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M15 19l-7-7 7-7"/></svg>
            <span className={isDesktop ? 'block' : 'hidden'}>VOLTAR PARA O LOBBY</span>
            <span className={isDesktop ? 'hidden' : 'block'}>SAIR</span>
          </button>

          <div className="flex items-center gap-2 sm:gap-4">
             <button 
               onClick={() => { soundService.playUISelect(); setIsHistoryModalOpen(true); }}
               className="sm:hidden bg-[#049444]/20 border border-[#049444]/30 px-3 py-1.5 rounded-lg flex items-center gap-2 text-[10px] font-black uppercase tracking-tighter text-[#049444] active:scale-95 transition-all shadow-lg cursor-pointer"
             >
               <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
               HIST.
             </button>

             <div className="bg-black/40 px-3 py-1 rounded-lg border border-white/10 flex flex-col items-end leading-none">
              <span className="text-[7px] font-black text-slate-500 uppercase">Saldo</span>
              <span className="font-mono font-bold text-[#FFCC00] text-xs sm:text-sm">$ {balance.toFixed(2)} <span className="text-[8px] opacity-60">USDT</span></span>
            </div>
          </div>
        </div>
      </div>

      {isHistoryModalOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 animate-in fade-in duration-300">
           <div className="absolute inset-0 bg-black/80 backdrop-blur-md" onClick={() => setIsHistoryModalOpen(false)} />
           <div className="bg-[#131d27] w-full max-w-sm rounded-[2.5rem] border border-white/10 shadow-2xl relative z-10 overflow-hidden flex flex-col max-h-[70vh]">
              <div className="p-6 border-b border-white/5 flex justify-between items-center bg-black/20">
                 <h3 className="font-black italic uppercase text-sm tracking-widest text-white">Histórico de <span className="text-[#049444]">Rondas</span></h3>
                 <button onClick={() => setIsHistoryModalOpen(false)} className="p-2 text-slate-500 hover:text-white transition-colors">
                    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"/></svg>
                 </button>
              </div>
              <div className="flex-1 overflow-y-auto p-4 space-y-2 custom-vertical-scrollbar bg-black/10">
                 {history.length === 0 ? (
                   <div className="py-20 text-center opacity-20 flex flex-col items-center gap-3">
                      <span className="text-4xl">📡</span>
                      <p className="text-[10px] font-black uppercase tracking-widest">Sem dados</p>
                   </div>
                 ) : (
                   history.map((round) => (
                    <div key={round.id} className="flex justify-between items-center bg-white/5 p-4 rounded-2xl border border-white/5">
                      <div className="flex flex-col">
                        <span className="text-[8px] font-black text-slate-500 uppercase leading-none mb-1">Tempo</span>
                        <span className="text-[11px] font-mono text-slate-300 font-bold">{new Date(round.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit', second: '2-digit'})}</span>
                      </div>
                      <div className={`px-4 py-2 rounded-xl font-mono font-black text-sm shadow-lg ${round.multiplier < 2 ? 'bg-[#3498db]/20 text-[#3498db] border border-[#3498db]/30' : 'bg-[#9b59b6]/20 text-[#9b59b6] border border-[#9b59b6]/30'}`}>
                        {round.multiplier.toFixed(2)}x
                      </div>
                    </div>
                   ))
                 )}
              </div>
              <div className="p-4 bg-black/20 border-t border-white/5 text-center">
                 <button onClick={() => setIsHistoryModalOpen(false)} className="w-full py-3.5 bg-white/5 rounded-xl text-[10px] font-black uppercase tracking-[0.2em] text-slate-400">Fechar</button>
              </div>
           </div>
        </div>
      )}

      <div className={`flex-1 flex flex-col ${isDesktop ? 'flex-row' : ''} overflow-hidden min-h-0`}>
        {/* SIDEBAR DE APOSTAS (SÓ DESKTOP) */}
        {isDesktop && (
          <aside className="flex flex-col w-64 xl:w-72 bg-[#0b1219] border-r border-white/5 z-20 shadow-2xl flex-shrink-0 h-full overflow-hidden">
            <div className="p-4 bg-[#131d27] border-b border-white/5 flex items-center justify-between flex-shrink-0">
              <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-500">APOSTAS AO VIVO</h3>
            </div>
            <div className="flex-1 min-h-0 overflow-y-auto p-3 space-y-2 bg-black/10 custom-vertical-scrollbar">
              {history.length === 0 ? (
                <div className="h-full flex items-center justify-center opacity-20">
                  <span className="text-[8px] font-black uppercase text-center tracking-widest">Aguardando Apostas</span>
                </div>
              ) : (
                history.map((round) => (
                  <div key={round.id} className="flex justify-between items-center bg-black/40 p-3 rounded-xl border border-white/5 flex-shrink-0">
                    <div className="flex flex-col">
                      <span className="text-[8px] font-black text-slate-600 uppercase leading-none mb-1">Valor</span>
                      <span className="text-[10px] font-mono text-slate-400 font-bold">$ 1.20 USDT</span>
                    </div>
                    <div className={`px-3 py-1 rounded-lg font-mono font-black text-xs ${round.multiplier < 1.5 ? 'text-[#3498db]' : 'text-white'}`}>
                      {round.multiplier.toFixed(2)}x
                    </div>
                  </div>
                ))
              )}
            </div>
            <div className="p-4 bg-[#131d27] border-t border-white/5 flex-shrink-0">
               <div className="text-[9px] font-mono text-slate-700 uppercase tracking-tighter text-center">CRYPTON-BET-AVIATOR-v1.2</div>
            </div>
          </aside>
        )}

        <div className="flex-1 flex flex-col relative min-h-0 overflow-hidden bg-[radial-gradient(circle_at_center,_#1a2c38_0%,_#05070a_100%)]">
          {/* HISTORY BAR NO TOPO DO JOGO */}
          <div className="flex-shrink-0 z-30">
             <HistoryBar history={history} />
          </div>

          <div className="flex-1 min-h-[220px] sm:min-h-[350px] md:min-h-[420px] relative flex flex-col group mt-2 sm:mt-4">
            <div className="absolute inset-0 z-0 text-white/5 pointer-events-none">
               <GameCanvas status={status} multiplier={multiplier} />
            </div>

            <div className="absolute inset-0 pointer-events-none z-10 p-2 sm:p-4 flex flex-col justify-between opacity-30 select-none">
              <div className="flex justify-between items-start">
                 <div className="flex flex-col gap-1">
                    <div className="text-[7px] sm:text-[8px] font-black text-slate-500 uppercase italic">Crypton Sky Arena</div>
                    <div className="flex gap-1 text-[10px] sm:text-xs">
                      <div className="w-1 h-3 bg-[#049444] rounded-full animate-pulse" />
                      <div className="w-1 h-3 bg-[#FFCC00] rounded-full animate-pulse delay-100" />
                    </div>
                 </div>
              </div>
              <div className="flex justify-center mb-6 sm:mb-12">
                 <div className="bg-black/60 px-3 py-1 sm:px-4 sm:py-2 rounded-xl sm:rounded-2xl border border-white/5 max-w-[160px] sm:max-w-[200px] text-center backdrop-blur-sm">
                    <p className="text-[8px] sm:text-[9px] font-mono font-bold text-[#FFCC00] italic">"{aiMessage}"</p>
                 </div>
              </div>
            </div>

            <div className="flex-1 flex items-center justify-center relative z-20 pointer-events-none">
              {status === GameStatus.BETTING ? (
                <div className="flex flex-col items-center animate-in zoom-in duration-500">
                  <div className={`rounded-full border-4 border-[#049444]/20 flex items-center justify-center relative shadow-[0_0_50px_rgba(4,148,68,0.1)] ${isDesktop ? 'w-48 h-48' : 'w-24 h-24 sm:w-32 sm:h-32'}`}>
                    <div className="absolute inset-0 rounded-full border-t-4 border-[#FFCC00] animate-spin" style={{animationDuration: '1s'}} />
                    <div className="flex flex-col items-center">
                      <span className={`${isDesktop ? 'text-6xl' : 'text-3xl sm:text-4xl'} font-black font-mono tracking-tighter text-white drop-shadow-xl`}>{bettingTimer.toFixed(1)}</span>
                      <span className="text-[7px] sm:text-[8px] font-black text-[#049444] uppercase tracking-widest mt-1">EM APOSTAS</span>
                    </div>
                  </div>
                </div>
              ) : (
                <div className={`text-center transition-all duration-300 ${isMilestone ? 'scale-110' : ''}`}>
                  <span className={`${isDesktop ? 'text-7xl sm:text-8xl md:text-[9rem]' : 'text-5xl sm:text-6xl'} font-black font-mono tracking-tighter leading-none block drop-shadow-[0_10px_20px_rgba(0,0,0,0.5)]
                    ${status === GameStatus.CRASHED ? 'text-red-500' : 'text-white shadow-[0_0_50px_rgba(255,255,255,0.1)]'}
                  `}>
                    {multiplier.toFixed(2)}<span className="text-[0.4em] ml-1">x</span>
                  </span>
                  {status === GameStatus.CRASHED && (
                    <motion.div 
                      initial={{ scale: 0.8 }}
                      animate={{ scale: 1 }}
                      className="mt-2 sm:mt-4 inline-block bg-red-600 px-4 py-1.5 sm:px-6 sm:py-2 rounded-lg shadow-2xl"
                    >
                      <span className="text-white font-black uppercase tracking-widest text-[10px] sm:text-sm italic">FLEW AWAY!</span>
                    </motion.div>
                  )}
                </div>
              )}
            </div>
          </div>

          {/* PAINEL DE APOSTAS FIXO NO RODAPÉ */}
          <div className="flex-shrink-0 z-40 bg-[#05070a]">
            <BetPanel 
              status={status} 
              bet={bet} 
              setBet={setBet} 
              hasActiveBet={hasActiveBet} 
              onPlaceBet={placeBet} 
              onCashOut={cashOut} 
              multiplier={multiplier} 
              balance={balance} 
            />
          </div>
        </div>
      </div>
      
      <style>{`
        .custom-vertical-scrollbar::-webkit-scrollbar {
          width: 4px;
        }
        .custom-vertical-scrollbar::-webkit-scrollbar-track {
          background: rgba(0, 0, 0, 0.2);
        }
        .custom-vertical-scrollbar::-webkit-scrollbar-thumb {
          background: rgba(244, 63, 94, 0.3);
          border-radius: 10px;
        }
      `}</style>
    </div>
  );
};

export default AviatorView;
