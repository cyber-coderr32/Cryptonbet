import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ChevronLeft, Wallet, TrendingUp, Sparkles, Zap, Trophy, Timer } from 'lucide-react';
import { soundService } from '../services/soundService';

interface CrashViewProps {
  balance: number;
  onUpdateBalance: (amount: number) => void;
  onBack: () => void;
}

const CrashView: React.FC<CrashViewProps> = ({ balance, onUpdateBalance, onBack }) => {
  const [betAmount, setBetAmount] = useState(10);
  const [autoCashout, setAutoCashout] = useState<number | string>('');
  const [multiplier, setMultiplier] = useState(1.0);
  const [status, setStatus] = useState<'WAITING' | 'RUNNING' | 'CRASHED'>('WAITING');
  const [countdown, setCountdown] = useState(5);
  const [isBetPlaced, setIsBetPlaced] = useState(false);
  const [hasCashedOut, setHasCashedOut] = useState(false);
  const [cashoutValue, setCashoutValue] = useState<number | null>(null);
  const [crashPoint, setCrashPoint] = useState<number | null>(null);
  const [history, setHistory] = useState<number[]>([]);

  const multiplierRef = useRef(1.0);
  const gameLoopRef = useRef<number | null>(null);

  // Sistema de Jogo Automático (Simulação de Round)
  useEffect(() => {
    let timer: any;
    if (status === 'WAITING') {
      if (countdown > 0) {
        timer = setTimeout(() => setCountdown(c => c - 1), 1000);
      } else {
        startRound();
      }
    }
    return () => clearTimeout(timer);
  }, [status, countdown]);

  const startRound = () => {
    setStatus('RUNNING');
    setMultiplier(1.0);
    multiplierRef.current = 1.0;
    setHasCashedOut(false);
    setCashoutValue(null);
    
    // Provably Fair Crash Point
    const random = Math.random();
    const point = Math.max(1, 99 / (1 - random) / 100);
    setCrashPoint(point);

    const step = () => {
      multiplierRef.current += 0.012 + (multiplierRef.current * 0.006); // Velocidade ligeiramente maior
      setMultiplier(multiplierRef.current);

      // Auto Cashout Logic
      const acValue = parseFloat(autoCashout.toString());
      if (acValue > 1 && multiplierRef.current >= acValue && isBetPlaced && !hasCashedOut) {
        handleCashout();
      }

      if (multiplierRef.current >= point) {
        crash();
      } else {
        gameLoopRef.current = requestAnimationFrame(step);
      }
    };

    gameLoopRef.current = requestAnimationFrame(step);
    soundService.playSpin();
  };

  const crash = () => {
    if (gameLoopRef.current) cancelAnimationFrame(gameLoopRef.current);
    setStatus('CRASHED');
    setHistory(prev => [multiplierRef.current, ...prev].slice(0, 10));
    setIsBetPlaced(false);
    soundService.playLoss();
    
    setTimeout(() => {
      setStatus('WAITING');
      setCountdown(5);
      setMultiplier(1.0);
      multiplierRef.current = 1.0;
    }, 3000);
  };

  const handlePlaceBet = () => {
    if (balance < betAmount || isBetPlaced || status !== 'WAITING') return;
    setIsBetPlaced(true);
    onUpdateBalance(-betAmount);
    soundService.playUISelect();
  };

  const handleCashout = () => {
    if (!isBetPlaced || status !== 'RUNNING' || hasCashedOut) return;
    
    const winAmount = betAmount * multiplier;
    onUpdateBalance(winAmount);
    setHasCashedOut(true);
    setCashoutValue(multiplier);
    soundService.playWin();
  };

  return (
    <div className="h-full w-full bg-[#0b0e11] flex flex-col font-sans overflow-hidden">
      <header className="p-4 flex items-center justify-between bg-[#131d27] border-b border-white/5 z-20">
        <button onClick={onBack} className="w-10 h-10 bg-white/5 hover:bg-white/10 rounded-xl flex items-center justify-center transition-all group">
          <ChevronLeft className="w-6 h-6 text-white group-hover:-translate-x-1" />
        </button>
        <div className="flex flex-col items-center">
           <span className="text-[10px] font-black text-[#FFCC00] uppercase tracking-[0.3em] mb-1">Crypton Crash</span>
           <div className="flex items-center gap-2 bg-black/40 px-3 py-1 rounded-full border border-white/5">
              <div className={`w-1.5 h-1.5 rounded-full ${status === 'RUNNING' ? 'bg-red-500 animate-pulse' : 'bg-[#049444]'}`} />
              <span className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">
                {status === 'WAITING' ? `Próximo Round: ${countdown}s` : status === 'RUNNING' ? 'Em Voo' : 'Crashed!'}
              </span>
           </div>
        </div>
        <div className="flex items-center gap-2 bg-white/5 px-4 py-2 rounded-2xl border border-white/10">
          <Wallet className="w-4 h-4 text-[#FFCC00]" />
          <span className="font-black text-white text-sm">$ {balance.toFixed(2)} USDT</span>
        </div>
      </header>

      <main className="flex-1 flex flex-col p-4 gap-4 overflow-hidden relative">
        {/* Histórico Superior */}
        <div className="flex gap-2 overflow-x-auto pb-2 no-scrollbar">
          {history.map((h, i) => (
             <div key={i} className={`px-4 py-2 rounded-xl font-black text-xs min-w-[70px] text-center border-b-2 shadow-lg transition-all ${h >= 2 ? 'bg-[#049444] text-white border-green-800' : 'bg-slate-800 text-slate-400 border-slate-900'}`}>
                {h.toFixed(2)}x
             </div>
          ))}
        </div>

        {/* Gráfico / Arena do Jogo */}
        <div className="flex-1 bg-[#131d27]/40 rounded-[2.5rem] border border-white/5 relative overflow-hidden flex flex-col items-center justify-center">
           {/* Grid Line Animation */}
           <div className="absolute inset-0 opacity-10 pointer-events-none bg-[linear-gradient(rgba(255,255,255,0.05)_1px,_transparent_1px),_linear-gradient(90deg,rgba(255,255,255,0.05)_1px,_transparent_1px)] bg-[size:40px_40px]" />
           
           <AnimatePresence mode="wait">
             {status === 'WAITING' ? (
                <motion.div 
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 1.1 }}
                  className="z-10 flex flex-col items-center gap-6"
                >
                   <div className="w-32 h-32 bg-white/5 rounded-[2.5rem] flex items-center justify-center border border-white/10 relative">
                      <Timer className="w-16 h-16 text-[#FFCC00]" />
                      <div className="absolute inset-0 border-4 border-[#FFCC00] rounded-[2.5rem] border-t-transparent animate-spin" />
                   </div>
                   <div className="text-center">
                      <h2 className="text-white font-black text-4xl italic tracking-tighter uppercase mb-2">Aceitando Apostas</h2>
                      <div className="flex items-center justify-center gap-2 text-[#FFCC00] font-black text-xl italic p-2 bg-black/40 rounded-full">
                         {countdown} SECONDS LEFT
                      </div>
                   </div>
                </motion.div>
             ) : (
                <div className="z-10 flex flex-col items-center gap-4">
                   <motion.div 
                     animate={status === 'CRASHED' ? { scale: [1, 1.2, 0.9], opacity: [1, 0.5, 0.2] } : {}}
                     className={`text-8xl md:text-[12rem] font-black italic tracking-tighter leading-none mb-4 flex items-end drop-shadow-2xl ${status === 'CRASHED' ? 'text-red-500' : 'text-[#049444]'}`}
                   >
                     {multiplier.toFixed(2)}<span className="text-4xl md:text-6xl ml-2 mb-4">X</span>
                   </motion.div>
                   
                   {hasCashedOut && status === 'RUNNING' && (
                      <motion.div 
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="bg-[#049444] px-10 py-4 rounded-full text-white font-black text-2xl uppercase tracking-widest shadow-2xl "
                      >
                         RETIRADO @ {cashoutValue?.toFixed(2)}x
                      </motion.div>
                   )}

                   {status === 'CRASHED' && (
                      <motion.div 
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        className="text-red-500 font-black text-4xl uppercase tracking-[0.2em] italic bg-red-500/10 px-8 py-3 rounded-2xl border border-red-500/20"
                      >
                         CABUM!
                      </motion.div>
                   )}
                </div>
             )}
           </AnimatePresence>

           {/* Curva de Ganho (Visual) */}
           {status === 'RUNNING' && (
             <svg className="absolute bottom-0 left-0 w-full h-[60%] pointer-events-none" viewBox="0 0 1000 600" preserveAspectRatio="none">
               <motion.path 
                 d={`M0 600 Q 100 600, ${Math.min(1000, (multiplier - 1) * 200)} ${600 - Math.min(550, (multiplier - 1) * 100)}`}
                 fill="none"
                 stroke="#049444"
                 strokeWidth="10"
                 strokeLinecap="round"
                 className="opacity-40"
               />
               <motion.circle 
                 cx={Math.min(950, (multiplier - 1) * 200)} 
                 cy={600 - Math.min(550, (multiplier - 1) * 100)} 
                 r="12" 
                 fill="#049444" 
                 className="shadow-[0_0_20px_#049444]"
               />
             </svg>
           )}
        </div>

        {/* Rodapé de Ação */}
        <div className="bg-[#131d27] p-5 rounded-[2.5rem] border border-white/5 flex flex-col md:flex-row gap-4 items-end">
           <div className="flex-1 w-full grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-black/40 p-3 rounded-2xl border border-white/5">
                 <div className="flex justify-between items-center mb-2 px-1">
                    <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Aposta (USDT)</span>
                    <div className="flex gap-1">
                       <button onClick={() => setBetAmount(Math.max(1, betAmount / 2))} className="px-2 py-1 bg-white/5 hover:bg-white/10 rounded-lg text-[9px] font-black text-white">1/2</button>
                       <button onClick={() => setBetAmount(betAmount * 2)} className="px-2 py-1 bg-white/5 hover:bg-white/10 rounded-lg text-[9px] font-black text-white">2x</button>
                    </div>
                 </div>
                 <input 
                   type="number"
                   value={betAmount}
                   onChange={(e) => setBetAmount(Number(e.target.value))}
                   className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-2 text-white font-black text-center focus:outline-none focus:border-[#049444]"
                 />
              </div>

              <div className="bg-black/40 p-3 rounded-2xl border border-white/5">
                 <div className="flex justify-between items-center mb-2 px-1">
                    <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Auto Cashout</span>
                    <span className="text-[9px] font-bold text-slate-600">OPCIONAL</span>
                 </div>
                 <div className="relative">
                    <input 
                      type="number"
                      step="0.1"
                      placeholder="Sem limite"
                      value={autoCashout}
                      onChange={(e) => setAutoCashout(e.target.value)}
                      className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-2 text-white font-black text-center focus:outline-none focus:border-[#049444]"
                    />
                    <span className="absolute right-4 top-1/2 -translate-y-1/2 text-xs font-black text-slate-600 italic">X</span>
                 </div>
              </div>
           </div>

           {status === 'RUNNING' && isBetPlaced && !hasCashedOut ? (
              <button 
                onClick={handleCashout}
                className="w-full md:w-64 py-5 bg-orange-500 hover:bg-orange-400 text-white rounded-3xl font-black text-2xl uppercase tracking-widest shadow-2xl shadow-orange-500/20 active:scale-95 transition-all border-b-8 border-orange-700"
              >
                 CASH OUT
                 <span className="block text-xs opacity-80 mt-1 font-bold">$ {(betAmount * multiplier).toFixed(2)} USDT</span>
              </button>
           ) : (
              <button 
                onClick={handlePlaceBet}
                disabled={status !== 'WAITING' || isBetPlaced || balance < betAmount}
                className={`w-full md:w-64 py-5 rounded-3xl font-black text-xl uppercase tracking-widest shadow-2xl transition-all active:scale-95 border-b-8 flex flex-col items-center justify-center
                  ${status !== 'WAITING' || isBetPlaced || balance < betAmount 
                    ? 'bg-slate-800 text-slate-500 border-slate-950 cursor-not-allowed opacity-50' 
                    : 'bg-[#049444] hover:bg-[#037235] text-white border-[#025628] shadow-[#049444]/20'}`}
              >
                 {isBetPlaced ? 'APOSTA FEITA' : 'APOSTAR'}
                 <span className="text-[10px] opacity-60 mt-1 uppercase font-black">PRÓXIMO ROUND</span>
              </button>
           )}
        </div>
      </main>

      {/* Background Glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-[#049444]/5 rounded-full blur-[120px] pointer-events-none" />
    </div>
  );
};

export default CrashView;
