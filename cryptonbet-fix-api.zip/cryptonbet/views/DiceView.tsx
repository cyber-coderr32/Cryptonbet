
import React, { useState } from 'react';
import { soundService } from '../services/soundService';

interface DiceViewProps {
  balance: number;
  onUpdateBalance: (amount: number) => void;
  onBack: () => void;
}

const DiceFace: React.FC<{ value: number; active?: boolean; size?: 'sm' | 'lg' }> = ({ value, active, size = 'sm' }) => {
  const dots = {
    1: [4],
    2: [0, 8],
    3: [0, 4, 8],
    4: [0, 2, 6, 8],
    5: [0, 2, 4, 6, 8],
    6: [0, 2, 3, 5, 6, 8],
  }[value as 1|2|3|4|5|6] || [];

  const sizeClass = size === 'lg' ? 'w-24 h-24 p-4' : 'w-full aspect-square p-2 max-w-[60px] mx-auto';
  const dotSize = size === 'lg' ? 'w-4 h-4' : 'w-2 h-2';

  return (
    <div className={`
      ${sizeClass} rounded-2xl border-2 grid grid-cols-3 grid-rows-3 gap-1 transition-all duration-300
      ${active 
        ? 'bg-purple-600 border-white shadow-[0_0_20px_rgba(168,85,247,0.6)] scale-105' 
        : 'bg-[#1a2c38] border-white/10 opacity-70 hover:opacity-100'}
    `}>
      {[...Array(9)].map((_, i) => (
        <div key={i} className="flex items-center justify-center">
          {dots.includes(i) && (
            <div className={`${dotSize} rounded-full bg-white shadow-sm`} />
          )}
        </div>
      ))}
    </div>
  );
};

const DiceView: React.FC<DiceViewProps> = ({ balance, onUpdateBalance, onBack }) => {
  const [bet, setBet] = useState(10);
  const [selectedFace, setSelectedFace] = useState<number | null>(null);
  const [result, setResult] = useState<number | null>(null);
  const [rolling, setRolling] = useState(false);
  
  const options = [1, 2, 3, 4, 5, 6];

  const handleSelectFace = (face: number) => {
    if (rolling) return;
    // Limpa o resultado anterior para evitar validação visual errada antes do novo roll
    setResult(null);
    setSelectedFace(face);
  };

  const roll = () => {
    if (balance < bet || rolling || selectedFace === null) {
      if (selectedFace === null && !rolling) {
        soundService.playCrash();
      }
      return;
    }

    setRolling(true);
    setResult(null); // Garante que o resultado visual é limpo ao iniciar
    onUpdateBalance(-bet);
    soundService.playTick();

    let currentTemp = 1;
    const interval = setInterval(() => {
      currentTemp = Math.floor(Math.random() * 6) + 1;
      setResult(currentTemp);
      soundService.playTick();
    }, 100);

    setTimeout(() => {
      clearInterval(interval);
      const finalResult = Math.floor(Math.random() * 6) + 1;
      setResult(finalResult);
      setRolling(false);

      if (finalResult === selectedFace) {
        const win = bet * 6;
        onUpdateBalance(win);
        soundService.playWin();
      } else {
        soundService.playCrash();
      }
    }, 1500);
  };

  return (
    <div className="h-full flex flex-col bg-[#0b0e11] text-white">
      {/* Header do Jogo */}
      <div className="p-4 flex bg-[#131d27] border-b border-white/5 items-center gap-4">
        <button onClick={onBack} className="p-2 hover:bg-white/5 rounded-full transition-colors">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
          </svg>
        </button>
        <div className="flex flex-col">
          <h2 className="font-black uppercase text-xs tracking-[0.2em] text-slate-500 leading-none">Jogo de</h2>
          <h2 className="font-black uppercase text-base tracking-tighter">Match <span className="text-purple-500">Dice</span></h2>
        </div>
        <div className="ml-auto bg-black/40 px-4 py-1.5 rounded-2xl border border-white/5 flex flex-col items-end">
          <span className="text-[8px] font-bold text-slate-500 uppercase leading-none mb-0.5">Saldo</span>
          <span className="font-mono font-bold text-green-400">{balance.toFixed(2)}€</span>
        </div>
      </div>

      <div className="flex-1 flex flex-col items-center justify-center p-3 sm:p-4 max-w-md mx-auto w-full gap-4 sm:gap-8 overflow-y-auto no-scrollbar">
        
        {/* O 5º Dado (Resultado / Dealer) */}
        <div className="flex flex-col items-center gap-2">
          <span className="text-[9px] font-black uppercase tracking-[0.3em] text-slate-600">Resultado do Sorteio</span>
          <div className={`${rolling ? 'animate-bounce' : ''}`}>
             <DiceFace value={(result || 1) as any} size={window.innerWidth < 640 ? 'sm' : 'lg'} active={!!result && result === selectedFace} />
          </div>
          <div className="h-4 flex items-center justify-center">
            {result !== null && !rolling && (
              <span className={`text-[10px] sm:text-sm font-black uppercase tracking-widest ${result === selectedFace ? 'text-green-500' : 'text-red-500'}`}>
                {result === selectedFace ? 'Acertaste em cheio!' : 'Não foi desta...'}
              </span>
            )}
          </div>
        </div>

        {/* Escolha do Usuário (6 Dados em Grelha) */}
        <div className="w-full space-y-2">
          <span className="text-[9px] font-black uppercase tracking-[0.3em] text-slate-600 text-center block italic">Faz a tua previsão</span>
          <div className="grid grid-cols-3 gap-2 w-full">
            {options.map((face) => (
              <button 
                key={face}
                onClick={() => handleSelectFace(face)}
                disabled={rolling}
                className="focus:outline-none w-full"
              >
                <DiceFace value={face as any} active={selectedFace === face} />
              </button>
            ))}
          </div>
        </div>

        {/* Controles de Aposta */}
        <div className="w-full bg-[#131d27] p-4 sm:p-5 rounded-[2rem] sm:rounded-[2.5rem] border border-white/5 shadow-2xl space-y-4 sm:space-y-5">
          <div className="flex flex-col gap-1.5">
            <span className="text-[10px] font-black uppercase tracking-widest text-slate-500 ml-2">Quantia</span>
            <div className="flex items-center gap-3 bg-black/40 p-2 rounded-2xl border border-white/5">
              <button 
                onClick={() => setBet(Math.max(1, bet - 5))} 
                className="w-10 h-10 bg-slate-800 rounded-xl font-black text-lg hover:bg-slate-700 active:scale-90 transition-all"
              >
                -
              </button>
              <div className="flex-1 text-center font-black text-2xl font-mono">{bet}€</div>
              <button 
                onClick={() => setBet(bet + 5)} 
                className="w-10 h-10 bg-slate-800 rounded-xl font-black text-lg hover:bg-slate-700 active:scale-90 transition-all"
              >
                +
              </button>
            </div>
          </div>

          <button 
            onClick={roll}
            disabled={rolling || selectedFace === null}
            className={`
              w-full h-16 rounded-2xl font-black uppercase tracking-widest shadow-xl transition-all active:scale-95
              ${rolling || selectedFace === null 
                ? 'bg-slate-800 text-slate-500 cursor-not-allowed border-b-0' 
                : 'bg-purple-600 hover:bg-purple-500 text-white border-b-4 border-purple-800'}
            `}
          >
            {rolling ? 'A Lançar...' : selectedFace === null ? 'Escolhe uma Face' : 'Confirmar Aposta'}
          </button>
        </div>
      </div>
      
      {/* Rodapé Informativo */}
      <div className="pb-8 text-center px-4">
        <p className="text-[9px] font-bold text-slate-600 uppercase tracking-[0.2em] leading-relaxed">
          Previsão exata de 1/6 paga <span className="text-purple-500">6x</span> o valor apostado
        </p>
      </div>
    </div>
  );
};

export default DiceView;
