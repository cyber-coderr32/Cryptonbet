
import React, { useState } from 'react';
import { soundService } from '../services/soundService';

interface Card {
  suit: string;
  value: string;
  weight: number;
}

const SUITS = ['♠', '♣', '♥', '♦'];
const VALUES = [
  { v: '2', w: 2 }, { v: '3', w: 3 }, { v: '4', w: 4 }, { v: '5', w: 5 }, { v: '6', w: 6 },
  { v: '7', w: 7 }, { v: '8', w: 8 }, { v: '9', w: 9 }, { v: '10', w: 10 },
  { v: 'J', w: 10 }, { v: 'Q', w: 10 }, { v: 'K', w: 10 }, { v: 'A', w: 11 }
];

// Added missing interface definition to fix compilation error for BlackjackView props
interface BlackjackViewProps {
  balance: number;
  onUpdateBalance: (amount: number) => void;
  onBack: () => void;
}

const BlackjackView: React.FC<BlackjackViewProps> = ({ balance, onUpdateBalance, onBack }) => {
  const [bet, setBet] = useState(10);
  const [playerHand, setPlayerHand] = useState<Card[]>([]);
  const [dealerHand, setDealerHand] = useState<Card[]>([]);
  const [status, setStatus] = useState<'IDLE' | 'PLAYING' | 'PLAYER_WIN' | 'DEALER_WIN' | 'PUSH'>('IDLE');

  const drawCard = () => {
    const s = SUITS[Math.floor(Math.random() * 4)];
    const v = VALUES[Math.floor(Math.random() * VALUES.length)];
    return { suit: s, value: v.v, weight: v.w };
  };

  const calculateScore = (hand: Card[]) => {
    let score = hand.reduce((acc, card) => acc + card.weight, 0);
    let aces = hand.filter(c => c.value === 'A').length;
    while (score > 21 && aces > 0) {
      score -= 10;
      aces -= 1;
    }
    return score;
  };

  const startGame = () => {
    if (balance < bet) return;
    onUpdateBalance(-bet);
    const p1 = drawCard(); const p2 = drawCard();
    const d1 = drawCard();
    setPlayerHand([p1, p2]);
    setDealerHand([d1]);
    setStatus('PLAYING');
    soundService.playCardShuffle();
  };

  const hit = () => {
    const newCard = drawCard();
    const newHand = [...playerHand, newCard];
    setPlayerHand(newHand);
    soundService.playCardShuffle();
    if (calculateScore(newHand) > 21) {
      setStatus('DEALER_WIN');
      soundService.playLoss();
    }
  };

  const stand = () => {
    let currentDealerHand = [...dealerHand];
    while (calculateScore(currentDealerHand) < 17) {
      currentDealerHand.push(drawCard());
    }
    setDealerHand(currentDealerHand);
    
    const pScore = calculateScore(playerHand);
    const dScore = calculateScore(currentDealerHand);

    if (dScore > 21 || pScore > dScore) {
      setStatus('PLAYER_WIN');
      onUpdateBalance(bet * 2);
      soundService.playWin();
    } else if (dScore > pScore) {
      setStatus('DEALER_WIN');
      soundService.playLoss();
    } else {
      setStatus('PUSH');
      onUpdateBalance(bet);
    }
  };

  return (
    <div className="h-full flex flex-col bg-[#0b0e11] text-white">
      <div className="p-4 flex bg-[#131d27] border-b border-white/5 items-center gap-4">
        <button onClick={onBack} className="p-2 hover:bg-white/5 rounded-full transition-colors text-slate-400">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" /></svg>
        </button>
        <h2 className="font-black uppercase text-xl italic tracking-tighter">BLACKJACK <span className="text-red-500">21</span></h2>
        <div className="ml-auto bg-black/40 px-4 py-2 rounded-xl border border-white/5 font-mono font-bold text-green-400">{balance.toFixed(2)}€</div>
      </div>

      <div className="flex-1 flex flex-col items-center justify-center p-4 sm:p-6 gap-6 sm:gap-12 bg-[radial-gradient(circle_at_center,_#1e293b_0%,_#0b0e11_100%)] overflow-y-auto no-scrollbar">
        {/* Dealer Area */}
        <div className="flex flex-col items-center gap-2 sm:gap-4">
          <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Dealer Hand ({calculateScore(dealerHand)})</span>
          <div className="flex gap-1.5 sm:gap-2">
            {dealerHand.map((c, i) => (
              <div key={i} className="w-12 h-18 sm:w-16 sm:h-24 bg-white rounded-lg flex flex-col items-center justify-center text-black font-black text-sm sm:text-xl shadow-xl">
                <span className={c.suit === '♥' || c.suit === '♦' ? 'text-red-600' : ''}>{c.value}{c.suit}</span>
              </div>
            ))}
            {status === 'PLAYING' && <div className="w-12 h-18 sm:w-16 sm:h-24 bg-slate-800 rounded-lg border-2 border-white/10 shadow-xl" />}
          </div>
        </div>

        {/* Status Message */}
        <div className="h-6 sm:h-8">
           {status !== 'PLAYING' && status !== 'IDLE' && (
             <div className={`text-lg sm:text-2xl font-black uppercase italic animate-bounce ${status === 'PLAYER_WIN' ? 'text-green-500' : status === 'PUSH' ? 'text-yellow-500' : 'text-red-500'}`}>
               {status === 'PLAYER_WIN' ? 'GANHASTE!' : status === 'PUSH' ? 'EMPATE' : 'O DEALER GANHOU'}
             </div>
           )}
        </div>

        {/* Player Area */}
        <div className="flex flex-col items-center gap-2 sm:gap-4">
          <div className="flex gap-1.5 sm:gap-2">
            {playerHand.map((c, i) => (
              <div key={i} className="w-12 h-18 sm:w-16 sm:h-24 bg-white rounded-lg flex flex-col items-center justify-center text-black font-black text-sm sm:text-xl shadow-xl">
                <span className={c.suit === '♥' || c.suit === '♦' ? 'text-red-600' : ''}>{c.value}{c.suit}</span>
              </div>
            ))}
          </div>
          <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest">A Tua Mão ({calculateScore(playerHand)})</span>
        </div>

        <div className="w-full max-w-sm bg-[#131d27] p-4 sm:p-6 rounded-[2rem] sm:rounded-[2.5rem] border border-white/5 shadow-2xl space-y-4">
           {status === 'PLAYING' ? (
             <div className="grid grid-cols-2 gap-3 sm:gap-4">
                <button onClick={hit} className="py-3 sm:py-4 bg-blue-600 hover:bg-blue-500 rounded-xl font-black uppercase text-[10px] sm:text-sm shadow-lg active:scale-95 transition-all">HIT</button>
                <button onClick={stand} className="py-3 sm:py-4 bg-red-600 hover:bg-red-500 rounded-xl font-black uppercase text-[10px] sm:text-sm shadow-lg active:scale-95 transition-all">STAND</button>
             </div>
           ) : (
             <div className="space-y-3 sm:space-y-4">
                <div className="flex items-center gap-2 sm:gap-4 bg-black/40 p-1.5 sm:p-2 rounded-2xl border border-white/5">
                  <button onClick={() => setBet(Math.max(10, bet - 10))} className="w-8 h-8 sm:w-10 sm:h-10 bg-slate-800 rounded-xl font-black text-sm sm:text-xl hover:bg-slate-700 transition-all">-</button>
                  <div className="flex-1 text-center font-black text-lg sm:text-2xl font-mono">{bet}€</div>
                  <button onClick={() => setBet(bet + 10)} className="w-8 h-8 sm:w-10 sm:h-10 bg-slate-800 rounded-xl font-black text-sm sm:text-xl hover:bg-slate-700 transition-all">+</button>
                </div>
                <button onClick={startGame} className="w-full py-4 sm:py-5 bg-slate-100 hover:bg-white text-black rounded-2xl font-black uppercase text-xs sm:text-sm tracking-widest shadow-xl border-b-4 sm:border-b-8 border-slate-400 active:scale-95 transition-all">Nova Mão</button>
             </div>
           )}
        </div>
      </div>
    </div>
  );
};

export default BlackjackView;
