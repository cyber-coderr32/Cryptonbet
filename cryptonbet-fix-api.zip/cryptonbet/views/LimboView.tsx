import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ChevronLeft, Wallet, Info, Trophy, Settings, TrendingUp, Zap } from 'lucide-react';
import { soundService } from '../services/soundService';

interface LimboViewProps {
  balance: number;
  onUpdateBalance: (amount: number) => void;
  onBack: () => void;
}

const LimboView: React.FC<LimboViewProps> = ({ balance, onUpdateBalance, onBack }) => {
  const [betAmount, setBetAmount] = useState(10);
  const [targetMultiplier, setTargetMultiplier] = useState(2.0);
  const [lastResults, setLastResults] = useState<number[]>([]);
  const [isSpinning, setIsSpinning] = useState(false);
  const [result, setResult] = useState<number | null>(null);
  const [winStatus, setWinStatus] = useState<'WIN' | 'LOSS' | null>(null);

  const calculateWinChance = (multiplier: number) => {
    return (99 / multiplier).toFixed(2);
  };

  const handlePlay = () => {
    if (balance < betAmount || isSpinning) return;

    soundService.playSpin();
    setIsSpinning(true);
    setWinStatus(null);
    onUpdateBalance(-betAmount);

    // Simulate Limbo logic (House edge ~1%)
    const random = Math.random();
    const outcome = 99 / (1 - random) / 100;
    const finalResult = Math.max(1, outcome);

    setTimeout(() => {
      setResult(finalResult);
      setIsSpinning(false);

      if (finalResult >= targetMultiplier) {
        setWinStatus('WIN');
        const winAmount = betAmount * targetMultiplier;
        onUpdateBalance(winAmount);
        soundService.playWin();
      } else {
        setWinStatus('LOSS');
        soundService.playLoss();
      }

      setLastResults(prev => [finalResult, ...prev].slice(0, 5));
    }, 800);
  };

  return (
    <div className="h-full w-full bg-[#0b0e11] flex flex-col font-sans overflow-hidden">
      <header className="p-4 flex items-center justify-between bg-[#131d27] border-b border-white/5 z-20">
        <button 
          onClick={onBack}
          className="w-10 h-10 bg-white/5 hover:bg-white/10 rounded-xl flex items-center justify-center transition-all group"
        >
          <ChevronLeft className="w-6 h-6 text-white group-hover:-translate-x-1" />
        </button>
        <div className="flex flex-col items-center">
           <span className="text-[10px] font-black text-[#FFCC00] uppercase tracking-[0.3em] mb-1">Crypton Limbo</span>
           <div className="flex items-center gap-2 bg-black/40 px-3 py-1 rounded-full border border-white/5">
              <div className="w-1.5 h-1.5 bg-[#049444] rounded-full animate-pulse" />
              <span className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">Provably Fair</span>
           </div>
        </div>
        <div className="flex items-center gap-2 bg-white/5 px-4 py-2 rounded-2xl border border-white/10">
          <Wallet className="w-4 h-4 text-[#FFCC00]" />
          <span className="font-black text-white text-sm">$ {balance.toFixed(2)} USDT</span>
        </div>
      </header>

      <main className="flex-1 flex flex-col md:flex-row p-4 gap-4 overflow-hidden">
        {/* Painel Esquerdo: Controles */}
        <div className="w-full md:w-80 flex flex-col gap-4">
          <div className="bg-[#131d27] p-5 rounded-[2rem] border border-white/5 space-y-6">
            <div>
              <div className="flex justify-between items-center mb-3">
                <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Valor da Aposta</span>
                <span className="text-[10px] font-black text-white uppercase opacity-50">$ {betAmount.toFixed(2)} USDT</span>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <button onClick={() => setBetAmount(Math.max(1, betAmount / 2))} className="py-2 bg-white/5 hover:bg-white/10 rounded-xl font-black text-xs text-white transition-all">½</button>
                <button onClick={() => setBetAmount(betAmount * 2)} className="py-2 bg-white/5 hover:bg-white/10 rounded-xl font-black text-xs text-white transition-all">2x</button>
              </div>
              <input 
                type="number"
                value={betAmount}
                onChange={(e) => setBetAmount(Number(e.target.value))}
                className="w-full mt-2 bg-black/40 border border-white/5 rounded-xl px-4 py-3 text-white font-black text-center focus:outline-none focus:border-[#049444]/50"
              />
            </div>

            <div>
              <div className="flex justify-between items-center mb-3">
                <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Multiplicador Alvo</span>
                <span className="text-[10px] font-black text-[#FFCC00] uppercase">{calculateWinChance(targetMultiplier)}% CHANCE</span>
              </div>
              <div className="relative">
                <input 
                  type="number"
                  step="0.1"
                  min="1.1"
                  value={targetMultiplier}
                  onChange={(e) => setTargetMultiplier(Math.max(1.1, Number(e.target.value)))}
                  className="w-full bg-black/40 border border-white/5 rounded-xl px-4 py-3 text-white font-black text-center focus:outline-none focus:border-[#FFCC00]/50"
                />
                <span className="absolute right-4 top-1/2 -translate-y-1/2 font-black text-slate-500 italic">X</span>
              </div>
            </div>

            <button 
              onClick={handlePlay}
              disabled={isSpinning || balance < betAmount}
              className={`w-full py-5 rounded-[1.5rem] font-black uppercase tracking-[0.2em] shadow-xl transition-all active:scale-95 border-b-8 flex flex-col items-center justify-center
                ${isSpinning || balance < betAmount 
                  ? 'bg-slate-800 text-slate-600 border-slate-950 cursor-not-allowed opacity-50' 
                  : 'bg-[#049444] hover:bg-[#037235] text-white border-[#025628] shadow-[#049444]/20'}`}
            >
              {isSpinning ? 'A PROCESSAR...' : 'APOSTAR'}
            </button>
          </div>

          <div className="bg-[#131d27] p-4 rounded-3xl border border-white/5 flex items-center justify-between">
            <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Histórico</span>
            <div className="flex gap-2">
              {lastResults.map((res, i) => (
                <div key={i} className={`px-2 py-1 rounded text-[10px] font-black ${res >= targetMultiplier ? 'bg-[#049444]/20 text-[#049444]' : 'bg-red-500/20 text-red-500'}`}>
                  {res.toFixed(2)}x
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Display Central do Resultado */}
        <div className="flex-1 bg-[#131d27]/50 rounded-[3rem] border border-white/5 flex items-center justify-center relative overflow-hidden">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_rgba(4,148,68,0.05)_0%,_transparent_70%)]" />
          
          <AnimatePresence mode="wait">
            <motion.div 
              key={isSpinning ? 'spinning' : (result || 'idle')}
              initial={{ opacity: 0, scale: 0.5, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 1.5, y: -20 }}
              className="z-10 flex flex-col items-center"
            >
              {isSpinning ? (
                <div className="flex flex-col items-center gap-4">
                   <div className="w-20 h-20 border-4 border-[#049444]/20 border-t-[#049444] rounded-full animate-spin" />
                   <span className="text-[#049444] font-black text-xl italic uppercase tracking-[0.3em] animate-pulse">Sorteando...</span>
                </div>
              ) : result !== null ? (
                <div className="text-center">
                  <motion.div 
                    initial={{ scale: 0.8 }}
                    animate={{ scale: 1 }}
                    className={`text-8xl md:text-[12rem] font-black italic tracking-tighter leading-none mb-4 ${winStatus === 'WIN' ? 'text-[#049444] drop-shadow-[0_0_50px_rgba(4,148,68,0.5)]' : 'text-slate-700'}`}
                  >
                    {result.toFixed(2)}<span className="text-4xl md:text-6xl ml-2">X</span>
                  </motion.div>
                  {winStatus === 'WIN' && (
                    <motion.div 
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="bg-[#049444] px-10 py-3 rounded-full text-white font-black text-2xl uppercase tracking-widest shadow-2xl"
                    >
                      GANHOU $ {(betAmount * targetMultiplier).toFixed(2)} USDT
                    </motion.div>
                  )}
                  {winStatus === 'LOSS' && (
                    <div className="text-red-500 font-black text-xl uppercase tracking-widest opacity-50">
                      TENTAR NOVAMENTE
                    </div>
                  )}
                </div>
              ) : (
                <div className="text-center space-y-4">
                  <div className="w-32 h-32 bg-white/5 rounded-[2.5rem] flex items-center justify-center border border-white/10 mx-auto">
                    <TrendingUp className="w-16 h-16 text-slate-700" />
                  </div>
                  <h3 className="text-slate-600 font-black text-2xl uppercase tracking-[0.2em] italic">Pronto para o Salto?</h3>
                </div>
              )}
            </motion.div>
          </AnimatePresence>

          {/* Background Sparks on Win */}
          {winStatus === 'WIN' && (
            <div className="absolute inset-0 pointer-events-none">
              {[...Array(20)].map((_, i) => (
                <motion.div
                  key={i}
                  initial={{ x: '50%', y: '50%', scale: 0 }}
                  animate={{ 
                    x: `${Math.random() * 100}%`, 
                    y: `${Math.random() * 100}%`,
                    scale: [0, 1, 0],
                  }}
                  transition={{ duration: 1 + Math.random() }}
                  className="absolute w-2 h-2 bg-[#FFCC00] rounded-full"
                />
              ))}
            </div>
          )}
        </div>
      </main>

      <footer className="p-4 bg-black/40 text-center flex items-center justify-center gap-8">
        <div className="flex items-center gap-2">
           <Zap className="w-3 h-3 text-[#FFCC00]" />
           <span className="text-[8px] font-black text-slate-700 uppercase tracking-widest">JOGO DE ALTA VELOCIDADE</span>
        </div>
        <div className="flex items-center gap-2">
           <Trophy className="w-3 h-3 text-[#049444]" />
           <span className="text-[8px] font-black text-slate-700 uppercase tracking-widest">MULTIPLICADOR MÁXIMO 1,000,000X</span>
        </div>
      </footer>
    </div>
  );
};

export default LimboView;
