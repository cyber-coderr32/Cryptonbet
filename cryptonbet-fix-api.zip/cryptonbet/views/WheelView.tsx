import React, { useState, useEffect } from 'react';
import { motion, useAnimation } from 'motion/react';
import { ChevronLeft, Wallet, Trophy, Target, Sparkles, Zap, Timer } from 'lucide-react';
import { soundService } from '../services/soundService';

interface WheelViewProps {
  balance: number;
  onUpdateBalance: (amount: number) => void;
  onBack: () => void;
}

const SECTORS = [
  { multiplier: 1.2, color: 'bg-emerald-500' },
  { multiplier: 0, color: 'bg-slate-800' },
  { multiplier: 1.5, color: 'bg-blue-500' },
  { multiplier: 0.1, color: 'bg-slate-900' },
  { multiplier: 1.2, color: 'bg-teal-500' },
  { multiplier: 0, color: 'bg-slate-800' },
  { multiplier: 2, color: 'bg-orange-500' },
  { multiplier: 0.5, color: 'bg-slate-700' },
  { multiplier: 1.1, color: 'bg-emerald-600' },
  { multiplier: 0, color: 'bg-slate-800' },
  { multiplier: 4, color: 'bg-purple-600' },
  { multiplier: 0, color: 'bg-slate-800' },
];

const WheelView: React.FC<WheelViewProps> = ({ balance, onUpdateBalance, onBack }) => {
  const [betAmount, setBetAmount] = useState(10);
  const [isSpinning, setIsSpinning] = useState(false);
  const [rotation, setRotation] = useState(0);
  const [result, setResult] = useState<typeof SECTORS[0] | null>(null);
  const [history, setHistory] = useState<number[]>([]);

  const spinWheel = () => {
    if (balance < betAmount || isSpinning) return;

    onUpdateBalance(-betAmount);
    setIsSpinning(true);
    soundService.playSpin();

    const spinRotations = 5 + Math.floor(Math.random() * 5); // 5-10 spins
    const sectorIndex = Math.floor(Math.random() * SECTORS.length);
    const sectorDegrees = 360 / SECTORS.length;
    const finalRotation = rotation + (spinRotations * 360) + (sectorIndex * sectorDegrees);
    
    setRotation(finalRotation);

    setTimeout(() => {
      const actualIndex = (SECTORS.length - (Math.floor(finalRotation / sectorDegrees) % SECTORS.length)) % SECTORS.length;
      const outcome = SECTORS[actualIndex];
      setResult(outcome);
      setIsSpinning(false);

      if (outcome.multiplier > 0) {
        onUpdateBalance(betAmount * outcome.multiplier);
        soundService.playWin();
      } else {
        soundService.playLoss();
      }

      setHistory(prev => [outcome.multiplier, ...prev].slice(0, 10));
    }, 5000);
  };

  return (
    <div className="h-full w-full bg-[#0b0e11] flex flex-col font-sans overflow-hidden">
      <header className="p-4 flex items-center justify-between bg-[#131d27] border-b border-white/5 z-20">
        <button onClick={onBack} className="w-10 h-10 bg-white/5 hover:bg-white/10 rounded-xl flex items-center justify-center transition-all group">
          <ChevronLeft className="w-6 h-6 text-white group-hover:-translate-x-1" />
        </button>
        <div className="flex flex-col items-center">
           <span className="text-[10px] font-black text-[#FFCC00] uppercase tracking-[0.3em] mb-1">Roda da Sorte</span>
           <div className="flex items-center gap-2 bg-black/40 px-3 py-1 rounded-full border border-white/5">
              <div className="w-1.5 h-1.5 bg-[#049444] rounded-full animate-pulse" />
              <span className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">Multiplicadores VIP</span>
           </div>
        </div>
        <div className="flex items-center gap-2 bg-white/5 px-4 py-2 rounded-2xl border border-white/10">
          <Wallet className="w-4 h-4 text-[#FFCC00]" />
          <span className="font-black text-white text-sm">$ {balance.toFixed(2)} USDT</span>
        </div>
      </header>

      <main className="flex-1 flex flex-col items-center justify-center p-4 sm:p-6 gap-4 sm:gap-8 relative min-h-0 overflow-hidden">
        {/* Histórico Inline */}
        <div className="flex gap-1 sm:gap-2 mb-2 sm:mb-4 overflow-x-auto no-scrollbar w-full justify-center">
           {history.map((h, i) => (
             <div key={i} className={`px-2 sm:px-3 py-1 rounded-lg font-black text-[8px] sm:text-[10px] shrink-0 ${h > 1 ? 'bg-[#049444] text-white' : 'bg-slate-800 text-slate-500'}`}>
                {h}x
             </div>
           ))}
        </div>

        {/* Wheel Container */}
        <div className="relative w-full max-w-[280px] sm:max-w-[340px] md:max-w-[440px] aspect-square flex items-center justify-center shrink-0">
           {/* Pointer */}
           <div className="absolute top-[-10px] sm:top-[-15px] left-1/2 -translate-x-1/2 z-30 drop-shadow-2xl">
              <div className="w-6 h-8 sm:w-8 sm:h-10 bg-white rounded-b-full flex items-center justify-center transition-transform">
                 <div className="w-3 h-3 sm:w-4 sm:h-4 bg-red-600 rounded-full animate-pulse" />
              </div>
              <div className="w-0 h-0 border-l-[10px] sm:border-l-[15px] border-l-transparent border-r-[10px] sm:border-r-[15px] border-r-transparent border-t-[15px] sm:border-t-[20px] border-t-white mx-auto shadow-xl" />
           </div>

           {/* The Wheel */}
           <motion.div 
             className="w-full h-full rounded-full relative border-[8px] sm:border-[12px] border-[#1e293b] shadow-[0_0_80px_rgba(0,0,0,0.8)] overflow-hidden"
             animate={{ rotate: rotation }}
             transition={{ duration: 5, ease: [0.15, 0, 0.2, 1] }}
           >
              {SECTORS.map((sector, idx) => (
                <div 
                  key={idx}
                  className={`absolute w-1/2 h-full left-1/2 top-0 origin-left border-l border-white/10 ${sector.color}`}
                  style={{ transform: `rotate(${idx * (360 / SECTORS.length)}deg)` }}
                >
                   <div 
                     className="absolute right-4 sm:right-8 top-1/2 -translate-y-1/2 rotate-90 text-white font-black text-xs sm:text-lg md:text-xl italic tracking-tighter"
                     style={{ transform: `translateY(-50%) rotate(90deg)` }}
                   >
                     {sector.multiplier}x
                   </div>
                </div>
              ))}
              
              {/* Inner Circle / Center */}
              <div className="absolute inset-[35%] bg-[#0b0e11] rounded-full border-[6px] sm:border-[8px] border-[#1e293b] flex items-center justify-center z-20 shadow-inner">
                 <div className="flex flex-col items-center">
                    <Sparkles className="w-6 h-6 sm:w-8 sm:h-8 text-[#FFCC00] mb-0.5 sm:mb-1" />
                    <span className="text-[8px] sm:text-[10px] font-black text-white uppercase tracking-widest hidden sm:block">Spin</span>
                 </div>
              </div>
           </motion.div>

           {/* Outer Glow */}
           <div className={`absolute inset-[-20px] rounded-full border-4 border-[#FFCC00]/20 animate-pulse ${isSpinning ? 'opacity-100' : 'opacity-0'}`} />
        </div>

        {/* Betting Controls */}
        <div className="w-full max-w-sm bg-[#131d27] p-6 rounded-[2.5rem] border border-white/5 shadow-2xl space-y-6">
           <div className="flex items-center gap-4 bg-black/60 p-2 rounded-2xl border border-white/5">
              <button 
                onClick={() => setBetAmount(Math.max(1, betAmount - 10))}
                className="w-12 h-12 bg-slate-800 rounded-xl font-black text-xl hover:bg-slate-700 transition"
              >-</button>
              <div className="flex-1 text-center">
                 <span className="block text-[8px] font-black text-slate-500 uppercase tracking-widest">Aposta</span>
                 <span className="font-black text-2xl text-white">$ {betAmount.toFixed(2)} USDT</span>
              </div>
              <button 
                onClick={() => setBetAmount(betAmount + 10)}
                className="w-12 h-12 bg-slate-800 rounded-xl font-black text-xl hover:bg-slate-700 transition"
              >+</button>
           </div>

           <button 
             onClick={spinWheel}
             disabled={isSpinning || balance < betAmount}
             className={`w-full py-5 rounded-2xl font-black uppercase tracking-[0.2em] shadow-xl transition-all active:scale-95 border-b-8 flex flex-col items-center justify-center
               ${isSpinning || balance < betAmount 
                 ? 'bg-slate-800 text-slate-600 border-slate-900 cursor-not-allowed opacity-50' 
                 : 'bg-[#FFCC00] hover:bg-[#FFD700] text-black border-[#ccaa00] shadow-[#FFCC00]/20'}`}
           >
              {isSpinning ? (
                <div className="flex items-center gap-2">
                   <div className="w-4 h-4 border-2 border-black/20 border-t-black rounded-full animate-spin" />
                   A GIRAR...
                </div>
              ) : (
                <>
                  GIRAR RODA
                  <span className="text-[10px] opacity-60 mt-1 uppercase">Sorte Grande</span>
                </>
              )}
           </button>
        </div>
      </main>

      <footer className="p-4 bg-black/40 text-center">
         <p className="text-[8px] font-black text-slate-700 uppercase tracking-widest">
            RNG Verificado • Multiplicador Máximo 10x • Retorno Justo
         </p>
      </footer>
    </div>
  );
};

export default WheelView;
