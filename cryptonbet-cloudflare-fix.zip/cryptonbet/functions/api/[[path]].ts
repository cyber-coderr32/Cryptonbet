// Cloudflare Pages Function — catch-all para /api/*
//
// Por que este ficheiro existe:
// O `api/[...path].ts` original foi escrito para o Vercel, que sabe pegar
// numa app Express e correr como função serverless Node. O Cloudflare Pages
// Functions NÃO faz isso automaticamente — cada função aqui tem de exportar
// um handler `onRequest` que recebe/devolve objetos `Request`/`Response`
// nativos da Fetch API (é o runtime dos Workers, não Node.js puro).
//
// Por isso esta versão reimplementa a mesma lógica do apiRoutes.ts, mas
// usando Request/Response em vez de req/res do Express. As rotas e o
// comportamento são idênticos aos originais.
//
// Variáveis de ambiente: configure-as no dashboard do Cloudflare Pages em
// Settings → Environment variables (Production e Preview), NÃO num ficheiro
// .env — esse ficheiro não é lido em produção pelas Pages Functions.
//   APISPORTS_KEY
//   GEMINI_API_KEY
//   PLISIO_SECRET_KEY

import { GoogleGenAI } from "@google/genai";

interface Env {
  APISPORTS_KEY?: string;
  GEMINI_API_KEY?: string;
  API_KEY?: string;
  PLISIO_SECRET_KEY?: string;
  PLISIO_API_KEY?: string;
}

function json(data: unknown, status = 200): Response {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json; charset=utf-8" },
  });
}

const SPORT_CONFIG: Record<string, { host: string; endpoint: string; alt?: string }> = {
  football: { host: "football.api-sports.io", endpoint: "fixtures", alt: "api-football.com" },
  basketball: { host: "basketball.api-sports.io", endpoint: "games", alt: "api-basketball.com" },
  f1: { host: "formula-1.api-sports.io", endpoint: "races", alt: "api-formula-1.com" },
  handball: { host: "handball.api-sports.io", endpoint: "games", alt: "api-handball.com" },
  hockey: { host: "hockey.api-sports.io", endpoint: "games", alt: "api-hockey.com" },
  mma: { host: "mma.api-sports.io", endpoint: "fights" },
  nfl: { host: "american-football.api-sports.io", endpoint: "games", alt: "api-american-football.com" },
  rugby: { host: "rugby.api-sports.io", endpoint: "games", alt: "api-rugby.com" },
  volleyball: { host: "volleyball.api-sports.io", endpoint: "games", alt: "api-volleyball.com" },
  tennis: { host: "api-tennis.com", endpoint: "games" },
};

async function handleProxyRequest(
  env: Env,
  sport: string,
  extraEndpoint?: string,
  extraQuery?: string
): Promise<Response> {
  const APISPORTS_KEY = env.APISPORTS_KEY || "be77ef991eaa21978a8112c3db8cfa43";
  const config = SPORT_CONFIG[sport] || SPORT_CONFIG["football"];

  const versions = sport === "football" ? ["v3"] : ["v1", "v2", "v3"];
  const possibleHosts: string[] = [];
  if (config.host) possibleHosts.push(config.host);
  if (config.alt) possibleHosts.push(config.alt);
  if (sport === "basketball") possibleHosts.push("nba.api-sports.io");

  let lastError: unknown = null;
  const triedHosts = new Set<string>();

  for (const baseHost of possibleHosts) {
    for (const v of versions) {
      const host = baseHost.startsWith("v") ? baseHost : `${v}.${baseHost}`;
      if (triedHosts.has(host)) continue;
      triedHosts.add(host);

      const endpoint = extraEndpoint || config.endpoint;
      let query = extraQuery;
      if (query === undefined || query === null) {
        if (sport === "f1" && endpoint === "races") {
          query = "season=2024";
        } else if (sport === "football" && (endpoint === "fixtures" || endpoint === "games")) {
          query = "live=all";
        } else if (sport === "mma" && endpoint === "fights") {
          query = "season=2024";
        } else if (endpoint === "fixtures" || endpoint === "games" || endpoint === "fights") {
          const today = new Date().toISOString().split("T")[0];
          query = `date=${today}`;
        } else {
          query = "";
        }
      }
      const apiUrl = `https://${host}/${endpoint}${query ? `?${query}` : ""}`;

      try {
        console.log(`Proxy attempt (${v}) for ${sport}: ${apiUrl}`);
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 10000);

        const response = await fetch(apiUrl, {
          method: "GET",
          headers: {
            "x-apisports-key": APISPORTS_KEY,
            Accept: "application/json",
            "User-Agent": "CryptonBet/1.0",
          },
          signal: controller.signal,
        });
        clearTimeout(timeoutId);

        if (response.ok) {
          const data: any = await response.json();

          const hasErrors =
            data.errors && (Object.keys(data.errors).length > 0 || (typeof data.errors === "string" && data.errors.length > 0));
          const hasLimitError = data.requests && typeof data.requests === "string" && data.requests.toLowerCase().includes("limit");
          const hasRateLimitError = data.rateLimit && typeof data.rateLimit === "string";

          if (hasErrors || hasLimitError || hasRateLimitError) {
            const errorPayload = data.errors || { requests: data.requests, rateLimit: data.rateLimit };
            const errorStr = JSON.stringify(errorPayload).toLowerCase();
            const isPlanRestricted = errorStr.includes("plan") || errorStr.includes("access");
            const isMinuteLimit = errorStr.includes("minute") || errorStr.includes("rate");
            const isGlobalLimit =
              errorStr.includes("limit") || errorStr.includes("requests") || (errorStr.includes("plan") && !errorStr.includes("date"));

            if (!isPlanRestricted && !isMinuteLimit && !isGlobalLimit) {
              console.warn(`API-Sports logic error for ${apiUrl}:`, JSON.stringify(errorPayload));
            } else {
              console.info(`API-Sports limit reached for ${apiUrl}: ${errorStr.substring(0, 100)}...`);
            }

            if (isPlanRestricted || isMinuteLimit || isGlobalLimit) {
              return json({
                ...data,
                _isQuotaExceeded: isGlobalLimit,
                _isPlanRestricted: isPlanRestricted,
                _isRateLimited: isMinuteLimit,
                errors: errorPayload,
              });
            }

            if (errorStr.includes("endpoint") || errorStr.includes("exist")) {
              continue;
            }
          }
          return json(data);
        }

        if (response.status === 404) continue;

        const errText = await response.text().catch(() => "Unknown Error");
        console.warn(`API Error ${response.status} for ${apiUrl}: ${errText}`);
        continue;
      } catch (error) {
        lastError = error;
        console.warn(`Fetch failure for ${apiUrl}: ${(error as Error).message}`);
        continue;
      }
    }

    if (!triedHosts.has(baseHost) && !baseHost.endsWith("api-sports.io")) {
      triedHosts.add(baseHost);
      const endpoint = extraEndpoint || config.endpoint;
      const query = extraQuery || "";
      const apiUrl = `https://${baseHost}/${endpoint}${query ? `?${query}` : ""}`;
      try {
        console.log(`Proxy attempt (direct) for ${sport}: ${apiUrl}`);
        const response = await fetch(apiUrl, {
          headers: { "x-apisports-key": APISPORTS_KEY, Accept: "application/json", "User-Agent": "CryptonBet/1.0" },
        });
        if (response.ok) {
          const data: any = await response.json();
          if (!(data.errors && Object.keys(data.errors).length > 0)) {
            return json(data);
          }
        }
      } catch (e) {
        console.warn(`Direct fetch failure for ${baseHost}: ${(e as Error).message}`);
      }
    }
  }

  return json({
    errors: [lastError ? (lastError as Error).message : "All attempts failed"],
    response: [],
    debug: { sport, lastError: String(lastError) },
  });
}

const SERVER_LOCAL_PHRASES: Record<string, string[]> = {
  BETTING: [
    "Façam as vossas apostas no estádio!",
    "O jogo vai começar!",
    "Preparem os vossos bilhetes!",
    "Boa sorte a todos os apostadores!",
  ],
  FLYING: [
    "As odds estão a subir!",
    "O multiplicador não para de crescer!",
    "Estamos na zona de lucro!",
    "Grande jogada em curso!",
  ],
  CRASHED: [
    "Final do jogo! Fiquem atentos ao próximo.",
    "Que partida emocionante! Prontos para a próxima?",
    "A sorte favorece os audazes!",
    "Tentem novamente, o prémio está perto!",
  ],
};

export const onRequest: PagesFunction<Env> = async (context) => {
  const { request, env } = context;
  const url = new URL(request.url);
  const path = url.pathname;
  const method = request.method;
  let m: RegExpMatchArray | null;

  try {
    // ---- Plisio ----
    const PLISIO_SECRET_KEY = env.PLISIO_SECRET_KEY || env.PLISIO_API_KEY;

    if (path === "/api/plisio/status" && method === "GET") {
      return json({
        configured: !!PLISIO_SECRET_KEY,
        message: PLISIO_SECRET_KEY
          ? "Plisio Secret Key configurada no servidor backend."
          : "PLISIO_SECRET_KEY não definida no servidor (.env).",
      });
    }

    if (path === "/api/plisio/currencies" && method === "GET") {
      try {
        const sourceCurrency = url.searchParams.get("sourceCurrency") || "USD";
        let plUrl = `https://plisio.net/api/v1/currencies/${sourceCurrency}`;
        if (PLISIO_SECRET_KEY) plUrl += `?api_key=${encodeURIComponent(PLISIO_SECRET_KEY)}`;
        const response = await fetch(plUrl);
        const data = await response.json();
        return json(data);
      } catch (err: any) {
        return json({ status: "error", message: err?.message || "Erro de servidor ao buscar moedas Plisio." }, 500);
      }
    }

    if (path === "/api/plisio/invoice/new" && method === "POST") {
      try {
        const body: any = await request.json();
        const { amount, currency, orderNumber, orderName, email } = body;
        const curr = currency || "USDT_TRX";

        if (!PLISIO_SECRET_KEY) {
          const txnId = "PLISIO_DEP_" + Date.now();
          const simulatedWallet = curr.includes("TRX")
            ? "T" + Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15)
            : "0x" + Math.random().toString(16).substring(2, 42);

          return json({
            status: "success",
            data: {
              txn_id: txnId,
              invoice_url: `https://plisio.net/invoice/${txnId}`,
              amount: Number(amount).toFixed(2),
              currency: curr,
              wallet_hash: simulatedWallet,
              expire_at_utc: Math.floor(Date.now() / 1000) + 3600,
            },
            isSimulated: true,
          });
        }

        const queryParams = new URLSearchParams({
          api_key: PLISIO_SECRET_KEY,
          currency: curr,
          amount: String(amount),
          order_number: String(orderNumber),
          order_name: String(orderName),
          source_currency: "USD",
        });
        if (email) queryParams.append("email", String(email));

        const response = await fetch(`https://plisio.net/api/v1/invoices/new?${queryParams.toString()}`);
        const data = await response.json();
        return json(data);
      } catch (err: any) {
        return json({ status: "error", message: err?.message || "Erro ao criar fatura no Plisio." }, 500);
      }
    }

    if (path === "/api/plisio/payout/insert" && method === "POST") {
      try {
        const body: any = await request.json();
        const { amount, currency, toWallet } = body;
        const curr = currency || "USDT_TRX";

        if (!PLISIO_SECRET_KEY) {
          const payoutId = "PLISIO_OUT_" + Date.now();
          return json({
            status: "success",
            data: {
              id: payoutId,
              amount: Number(amount).toFixed(2),
              currency: curr,
              status: "pending",
              tx_url: `https://tronscan.org/#/transaction/simulated_${payoutId}`,
            },
            isSimulated: true,
          });
        }

        const queryParams = new URLSearchParams({
          api_key: PLISIO_SECRET_KEY,
          currency: curr,
          amount: String(amount),
          to: String(toWallet),
          type: "cash_out",
        });

        const response = await fetch(`https://plisio.net/api/v1/payouts/insert?${queryParams.toString()}`);
        const data = await response.json();
        return json(data);
      } catch (err: any) {
        return json({ status: "error", message: err?.message || "Erro ao solicitar saque no Plisio." }, 500);
      }
    }

    if ((m = path.match(/^\/api\/plisio\/operations\/([^/]+)$/)) && method === "GET") {
      try {
        const id = decodeURIComponent(m[1]);
        if (!PLISIO_SECRET_KEY) {
          return json({ status: "success", data: { status: "completed" }, isSimulated: true });
        }
        const response = await fetch(`https://plisio.net/api/v1/operations/${id}?api_key=${encodeURIComponent(PLISIO_SECRET_KEY)}`);
        const data = await response.json();
        return json(data);
      } catch (err: any) {
        return json({ status: "error", message: err?.message }, 500);
      }
    }

    // ---- Gemini commentary ----
    if (path === "/api/gemini/commentary" && method === "POST") {
      const GEMINI_API_KEY = env.GEMINI_API_KEY || env.API_KEY;
      const body: any = await request.json().catch(() => ({}));
      const { status, multiplier } = body;
      const phrases = SERVER_LOCAL_PHRASES[status] || ["Boa sorte!"];
      const randomLocal = phrases[Math.floor(Math.random() * phrases.length)];

      if (!GEMINI_API_KEY) {
        return json({ text: randomLocal });
      }

      try {
        const ai = new GoogleGenAI({
          apiKey: GEMINI_API_KEY,
          httpOptions: { headers: { "User-Agent": "aistudio-build" } },
        });
        const response = await ai.models.generateContent({
          model: "gemini-3.6-flash",
          contents: `Status: ${status} ${multiplier ? `at ${Number(multiplier).toFixed(2)}x` : ""}. Give a 3-word commentary in Portuguese (PT-PT). No quotes.`,
          config: { maxOutputTokens: 20, temperature: 0.8 },
        });
        const text = response.text?.trim();
        return json({ text: text && text.length > 2 ? text : randomLocal });
      } catch (error) {
        console.warn("AI Status Warning: Failed to generate content via Gemini. Using local phrase.");
        return json({ text: randomLocal });
      }
    }

    // ---- Sports proxy routes ----
    if ((m = path.match(/^\/api\/sports\/live\/([^/]+)$/)) && method === "GET") {
      return await handleProxyRequest(env, m[1].toLowerCase());
    }

    if ((m = path.match(/^\/api\/sports\/scheduled\/([^/]+)\/([^/]+)$/)) && method === "GET") {
      const [, sport, date] = m;
      return await handleProxyRequest(env, sport.toLowerCase(), undefined, `date=${date}`);
    }

    if ((m = path.match(/^\/api\/sports\/odds\/([^/]+)$/)) && method === "GET") {
      return await handleProxyRequest(env, "football", "odds", `fixture=${m[1]}`);
    }

    if ((m = path.match(/^\/api\/sports\/countries\/([^/]+)$/)) && method === "GET") {
      return await handleProxyRequest(env, m[1].toLowerCase(), "countries", "");
    }

    if ((m = path.match(/^\/api\/sports\/leagues\/([^/]+)\/([^/]+)$/)) && method === "GET") {
      const [, sport, country] = m;
      return await handleProxyRequest(env, sport.toLowerCase(), "leagues", `country=${country}`);
    }

    if ((m = path.match(/^\/api\/sports\/team-fixtures\/([^/]+)\/([^/]+)$/)) && method === "GET") {
      const [, sport, teamId] = m;
      const requestedSeason = url.searchParams.get("season");
      const s = sport.toLowerCase();
      const config = SPORT_CONFIG[s] || SPORT_CONFIG["football"];
      const endpoint = config.endpoint;

      let season: string | number = requestedSeason || "";
      if (!season) {
        const now = new Date();
        const year = now.getFullYear();
        season = s === "football" ? (year > 2025 ? 2024 : now.getMonth() < 6 ? year - 1 : year) : year;
      }

      return await handleProxyRequest(env, s, endpoint, `team=${teamId}&season=${season}`);
    }

    if ((m = path.match(/^\/api\/sports\/search-teams\/([^/]+)\/([^/]+)$/)) && method === "GET") {
      const [, sport, q] = m;
      return await handleProxyRequest(env, sport.toLowerCase(), "teams", `search=${q}`);
    }

    return json({ error: "Not Found" }, 404);
  } catch (err: any) {
    return json({ error: err?.message || "Internal Server Error" }, 500);
  }
};
