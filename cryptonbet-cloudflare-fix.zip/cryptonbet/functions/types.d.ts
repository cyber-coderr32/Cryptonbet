// Fallback mínimo de tipos para Cloudflare Pages Functions (apenas para
// o editor/tsc local — o build do Cloudflare usa esbuild e ignora isto).
// Não precisa de instalar @cloudflare/workers-types para isto funcionar.

interface PagesFunctionContext<Env = unknown> {
  request: Request;
  env: Env;
  params: Record<string, string | string[]>;
  waitUntil: (promise: Promise<unknown>) => void;
  next: (input?: Request | string, init?: RequestInit) => Promise<Response>;
}

type PagesFunction<Env = unknown> = (context: PagesFunctionContext<Env>) => Response | Promise<Response>;
